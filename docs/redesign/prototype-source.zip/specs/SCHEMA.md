# Spec extraction schema (PowerCollect redesign)

Goal: describe every page, form/modal and confirmation dialog **exactly as the current code has it**, so a new design can
render each one with the same fields — no field added, none removed. Read the JSX (and the PHP controller / FormRequest
when options or validation live there). Never edit any project file.

Write ONE JSON file (UTF-8, valid JSON, no comments) with this shape:

```json
{
  "pages": [ PAGE, ... ],
  "forms": [ FORM, ... ],
  "confirms": [ CONFIRM, ... ]
}
```

## PAGE
```json
{
  "id": "inventory page id (given in your brief)",
  "file": "resources/js/Pages/....jsx",
  "title": "Arabic title shown on the page",
  "subtitle": "subtitle/description if any",
  "headerActions": [ { "label": "exact Arabic", "kind": "primary|secondary|menu|link", "opens": "form id or null", "permission": "can key if gated" } ],
  "kpis": [ { "label": "exact Arabic", "example": "realistic sample value", "note": "what it counts" } ],
  "tabs": [ "exact Arabic tab labels" ],
  "filters": [ { "label": "exact Arabic", "type": "search|select|multiselect|date|daterange|segmented|toggle|chips", "options": ["exact options, or a description like 'branches from DB'"], "default": "..." } ],
  "table": {
    "columns": [ { "label": "exact Arabic header", "type": "text|money|number|date|datetime|status|badge|person|account|progress|boolean|actions|icon", "note": "e.g. status values and their colours" } ],
    "rowActions": [ "exact Arabic labels (menu items / icon buttons)" ],
    "bulkActions": [ "exact Arabic labels" ],
    "selectable": true,
    "rowClick": "what clicking a row does",
    "pagination": "pages|load-more|infinite|none",
    "emptyText": "exact Arabic empty state",
    "sampleRows": [ [ "...", "..." ] ]
  },
  "otherSections": [ "short description of any other block: cards, charts, side panels, summaries" ]
}
```
If a page has several tables, put the main one in `table` and add the rest as `"tables": [ ...same shape with a "title" ]`.
`sampleRows`: 3–4 realistic rows (Arabic names, Gaza-area places, ₪ amounts, 2026 dates), one array per row, aligned to `columns`.

## FORM
```json
{
  "id": "inventory form id (given in your brief)",
  "file": "resources/js/...jsx",
  "title": "exact Arabic title (all variants, e.g. 'إنشاء مشترك / تعديل المشترك')",
  "kind": "modal|drawer|sheet|page|inline|popover",
  "size": "sm|md|lg|xl|full",
  "steps": [ "if it is a stepper: exact step titles, else []" ],
  "sections": [
    { "title": "exact Arabic section title or null",
      "fields": [
        { "label": "exact Arabic label", "name": "form key in code",
          "type": "text|number|money|tel|id|email|password|select|combobox|multiselect|date|datetime|time|switch|checkbox|radio|segmented|cards|textarea|file|color|readonly|table|currency|search",
          "options": ["exact options, or 'from DB: branches'"],
          "required": true, "default": "...", "showIf": "condition in words", "hint": "helper text", "unit": "₪ / ك.و / A ...",
          "validation": "rules in words (max length, digits, unique...)" } ] }
  ],
  "computed": [ "live previews / totals shown while typing, e.g. 'الرصيد بعد الدفعة'" ],
  "buttons": [ { "label": "exact Arabic", "role": "submit|cancel|danger|secondary|link" } ],
  "notes": "behaviour worth knowing: who can open it, what happens on submit, confirmations it triggers"
}
```

## CONFIRM
```json
{ "id": "short id", "file": "...", "title": "exact Arabic", "body": "exact Arabic text", "confirmLabel": "exact", "cancelLabel": "exact", "tone": "danger|warning|default", "requiresInput": "e.g. type the name / reason, or null" }
```

Rules
- Arabic text exactly as in the code (copy it). If a label is built from a variable, write it with `{...}`.
- Do not invent fields, columns, filters or buttons. If unsure, add `"uncertain": true` to that item.
- Keep it complete rather than short: every input in every form counts.
- Validate your file with `node -e "JSON.parse(require('fs').readFileSync(PATH,'utf8'))"` before finishing.
- Your final message: the file path, counts (pages/forms/confirms/fields) and anything you could not resolve.
