import base64, os, re

base = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(base, '..')
ROOT = '/home/user/powerCollect'
tpl = open(os.path.join(S, 'shell', 'template.html')).read()
data = open(os.path.join(S, 'inventory', 'data.js')).read()
dash_css = open(os.path.join(base, 'dash.css')).read() + open(os.path.join(base, 'modals.css')).read() + open(os.path.join(base, 'hover.css')).read() + open(os.path.join(base, 'brand.css')).read() + open(os.path.join(base, 'palette.css')).read() + open(os.path.join(base, 'kit.css')).read() + open(os.path.join(base, 'pages.css')).read()
dash_js = open(os.path.join(base, 'dashboard.js')).read()
import glob, json
SPECS = []
for fp in sorted(glob.glob(os.path.join(S, 'specs', '*.json'))):
    try:
        SPECS.append(json.load(open(fp)))
    except Exception as ex:
        print('skip spec', os.path.basename(fp), ex)
specs_js = 'const SPECS = ' + json.dumps(SPECS, ensure_ascii=False).replace('</', '<\\/') + ';\n'
modals_js = '\n'.join(open(os.path.join(base, f)).read() for f in ('pickers.js', 'kit.js', 'modals.js')) + '\n' + specs_js + '\n'.join(open(os.path.join(base, f)).read() for f in ('pages.js', 'views.js', 'statement.js', 'cashboxes.js'))


def rep(s, a, b, count=1):
    assert a in s, a[:80]
    return s.replace(a, b, count)


# 1. The site's own fonts (resources/css/fonts.css), embedded so the file works offline.
fonts_css = open(os.path.join(ROOT, 'resources/css/fonts.css')).read()
def embed(m):
    path = os.path.normpath(os.path.join(ROOT, 'resources/css', m.group(1)))
    return 'url(data:font/woff2;base64,' + base64.b64encode(open(path, 'rb').read()).decode() + ')'
fonts_css = re.sub(r'url\(([^)]+\.woff2)\)', embed, fonts_css)
html = re.sub(r'<link rel="preconnect"[^>]*>\s*<link rel="preconnect"[^>]*>\s*<link href="https://fonts.googleapis.com[^>]*>', '', tpl)

# 2. Font roles: body, headings, figures — all from the site's set.
html = html.replace("'IBM Plex Sans Arabic', system-ui, sans-serif", 'var(--f-body), system-ui, sans-serif')
html = html.replace("Inter, 'IBM Plex Sans Arabic', sans-serif", 'var(--f-num)')
html = re.sub(r"\bInter\b", 'var(--f-num)', html)
html = html.replace("'IBM Plex Sans Arabic'", 'var(--f-body)')
dash_css = re.sub(r"\bInter\b", 'var(--f-num)', dash_css).replace("'IBM Plex Sans Arabic'", 'var(--f-body)')
type_css = """
/* ═══ Typography — the site's fonts, set large and heavy for Arabic ═══ */
:root { --f-body: 'Zain'; --f-head: 'Zain'; --f-num: 'Zain'; --f-brand: 'Alexandria'; }
body { font-family: var(--f-body), system-ui, sans-serif; font-size: 15px; line-height: 1.75; }
h1, h2, h3, h4, h5, .org b, .fly-h b, .grp-h, .side-h, .balance, .done-amt, .tile .v, .mcard .nm, .sheet h3 { font-family: var(--f-head); letter-spacing: 0 !important; }
.ph h1 { font-size: 48px; font-weight: 800; line-height: 1.25; }
.ph p { font-size: 15.5px; }
.card-h h3 { font-size: 18px; font-weight: 700; }
.mh h2, .co-top h2 { font-size: 23px; font-weight: 800; }
.sheet h3 { font-size: 24px; font-weight: 800; }
.nav { font-size: 14.5px; } .fly-h b { font-size: 17px; font-weight: 800; }
.btn { font-weight: 700; } .ff > label { font-size: 13.5px; font-weight: 700; }
.balance { font-family: var(--f-num); font-weight: 800; letter-spacing: -.01em !important; }
.n, .amount-row input, .mini-amt input, .tile .v, .done-amt { font-family: var(--f-num) !important; }
"""

contrast_css = """
/* ═══ Contrast layer — every text colour reaches WCAG AA on solid and glass, light and dark ═══ */
:root { --muted: oklch(0.45 0.014 286); --accent-soft-fg: oklch(0.45 0.17 258);
  --danger-ink: oklch(0.47 0.18 27); --success-ink: oklch(0.45 0.12 152); --warning-ink: oklch(0.47 0.11 65);
  --accent-strong: oklch(0.53 0.2 258); --success-strong: oklch(0.52 0.14 152);
  --glass: color-mix(in oklab, var(--surface) 72%, transparent); }
:root[data-theme="dark"] { --muted: oklch(0.74 0.014 286); --accent-soft-fg: oklch(0.78 0.12 254);
  --danger-ink: oklch(0.75 0.15 22); --success-ink: oklch(0.8 0.15 152); --warning-ink: oklch(0.83 0.13 76);
  --accent-strong: oklch(0.55 0.2 258); --success-strong: oklch(0.55 0.14 152);
  --glass: color-mix(in oklab, var(--surface) 58%, transparent); }
.ff > label .req, .flab .req, .req { color: var(--danger-ink); }
"""
MA_SVG = open(os.path.join(ROOT, 'public/images/logo-ma.svg')).read()
MA_SVG = re.sub(r'<title>.*?</title>', '', MA_SVG).replace('<svg ', '<svg class="ma-mark" aria-hidden="true" focusable="false" ')
MA_SVG = MA_SVG.replace('fill="#2A2D34"', 'class="m"').replace('fill="#E2642A"', 'class="a"')

# 3. Styles.
html = rep(html, '</style>', fonts_css + type_css + dash_css + contrast_css + '\n</style>')

# Text tinted by mixing a status colour into the foreground becomes the matching ink token.
INK = r"color-mix\(in oklab, var\(--(danger|success|warning)\) \d+%, var\(--foreground\)\)"
html = re.sub(INK, lambda m: f'var(--{m.group(1)}-ink)', html)

# 4. Dashboard and modals.
a, b = html.index('function dashboard(p) {'), html.index('function fullscreen(p) {')
html = html[:a] + dash_js + '\n' + html[b:]
html = re.sub(INK, lambda m: f'var(--{m.group(1)}-ink)', html)
html = rep(html, "const h = location.hash.slice(1);", "const MA = `" + MA_SVG + "`;\nconst h = location.hash.slice(1);")
html = rep(html, "const h = location.hash.slice(1);", modals_js + "\nconst h = location.hash.slice(1);")

# 5. Wire the openers: top bar, floating button, section flyout, page action pills.
html = rep(html, '<button class="btn btn-primary" data-part="إجراء سريع">', '<button class="btn btn-primary" data-part="إجراء سريع" data-modal="quickPay">')
html = rep(html, '<button class="fab" aria-label="تحصيل سريع">', '<button class="fab" aria-label="تحصيل سريع" data-modal="quickPay">')
html = rep(html, '${q ? `<div class="fly-f"><button class="btn btn-primary btn-sm">', '${q ? `<div class="fly-f"><button class="btn btn-primary btn-sm" data-modal="${{ \'مشترك جديد\': \'subscriber\', \'تسجيل دفعة\': \'quickPay\' }[q[1]] || \'\'}">')
html = rep(html, "`<button class=\"btn ${i ? 'btn-secondary' : 'btn-primary'}\">${ic(iconFor(b), 'i i-sm')}${b}</button>`",
           "`<button class=\"btn ${i ? 'btn-secondary' : 'btn-primary'}\" data-modal=\"${({ 'تسجيل دفعة': 'quickPay', 'بحث عن مشترك': 'quickPay', 'مشترك جديد': 'subscriber', 'دفعة مقسّمة جديدة': 'split', 'دفعة مقسّمة': 'split', 'تحميل حركة': 'charge', 'خصم': 'discount' })[b] || ''}\">${ic(iconFor(b), 'i i-sm')}${b}</button>`")
html = rep(html, "const mtabFab = null;", "") if "const mtabFab = null;" in html else html
html = html.replace('`<button aria-label="تحصيل"><span class="mfab">', '`<button aria-label="تحصيل" data-modal="quickPay"><span class="mfab">')

# Sidebar head: the mark alone. Top bar: the name joins it once the page scrolls.
html = rep(html, """<div style="display:flex;align-items:center;gap:4px"><button class="org" data-part="الشركة والفرع"><span class="org-mark">${ic('zap', 'i i-lg')}</span><span><b>سوبر باور</b><small>كل الفروع · 5 فروع</small></span>${ic('chevrons-up-down', 'i i-sm')}</button>""",
           """<div class="brand-side" data-part="الشعار"><a href="#dashboard" data-go="dashboard" aria-label="مصعب العجل وأحمد الكفارنة للتجارة العامة، الرئيسية" style="display:contents">${MA}</a>""")
html = rep(html, '<header class="top" data-part="الشريط العلوي · Navbar">',
           '<header class="top" data-part="الشريط العلوي · Navbar">\n      <div class="brand-top" data-part="اسم الشركة (يظهر مع التمرير)" aria-hidden="true"><span class="mk"></span><b>مصعب العجل <span style="white-space:nowrap">وأحمد الكفارنة</span></b><small>للتجارة العامة</small></div>')
html = rep(html, "const h = location.hash.slice(1);", """$('.brand-top .mk').outerHTML = MA;
document.documentElement.dataset.brand = 'c'; /* Palette C: charcoal actions, orange for choice, focus and the hero. */
const onScroll = () => document.body.classList.toggle('scrolled', scrollY > 24);
addEventListener('scroll', onScroll, { passive: true }); onScroll();
const h = location.hash.slice(1);""")
html = html.replace('<title>PowerCollect Shell</title>', '<title>MA Trading</title>')

# 6. Preview tools: open each window, choose the fonts.
fonts = [('Zain', 'Zain'), ('Alexandria', 'Alexandria'), ('Cairo', 'Cairo'), ('Noto Kufi Arabic', 'Noto Kufi'), ('El Messiri', 'El Messiri'), ('Tajawal', 'Tajawal'), ('IBM Plex Sans Arabic', 'IBM Plex')]
sel = lambda id_, cur: f'<select id="{id_}" style="height:32px;border-radius:99px;border:0;padding:0 10px;background:var(--default);font:600 12px var(--f-body);color:var(--foreground)">' + ''.join(f'<option value="{v}" {"selected" if v == cur else ""}>{l}</option>' for v, l in fonts) + '</select>'
tools = f'''<span class="t">النوافذ</span>
  <div style="display:flex;flex-wrap:wrap;gap:4px;max-width:250px"><button class="btn btn-secondary btn-sm" data-modal="quickPay">تسجيل دفعة</button><button class="btn btn-secondary btn-sm" data-modal="subscriber">مشترك جديد</button><button class="btn btn-secondary btn-sm" data-modal="charge" data-who="خالد منصور">تحميل حركة</button><button class="btn btn-secondary btn-sm" data-modal="discount" data-who="خالد منصور">خصم</button><button class="btn btn-secondary btn-sm" data-modal="split">دفعة مقسّمة</button></div>
  <span class="t">الخطوط (من موقعك)</span>
  <div style="display:flex;gap:6px;align-items:center;font-size:12px;color:var(--muted)">العناوين {sel('fHead', 'Zain')}</div>
  <div style="display:flex;gap:6px;align-items:center;font-size:12px;color:var(--muted)">النص {sel('fBody', 'Zain')}</div>
  <span class="t">المعاينة</span>'''
html = rep(html, '<span class="t">المعاينة</span>', tools)
html = rep(html, "const h = location.hash.slice(1);", """['fHead', 'fBody'].forEach((id) => $('#' + id).addEventListener('change', (e) => { const v = `'${e.target.value}'`; if (id === 'fHead') { document.documentElement.style.setProperty('--f-head', v); document.documentElement.style.setProperty('--f-num', v); } else document.documentElement.style.setProperty('--f-body', v); }));
$('.pv').insertAdjacentHTML('afterbegin', '<button class="btn btn-ghost btn-sm" id="pvMin" style="align-self:flex-end">إخفاء الأدوات</button>');
const pvToggle = () => { const pv = $('.pv'); const min = pv.classList.toggle('min'); $$('.pv > :not(#pvMin)').forEach((n) => { n.style.display = min ? 'none' : ''; }); $('#pvMin').textContent = min ? 'أدوات المعاينة ▴' : 'إخفاء الأدوات'; };
$('#pvMin').addEventListener('click', pvToggle); pvToggle();
const h = location.hash.slice(1);""")

# The collection chart follows the theme colour (it is the hero of the dashboard).
html = rep(html, '<stop offset="0" stop-color="oklch(0.6204 0.195 253.83)" stop-opacity=".35"/><stop offset="1" stop-color="oklch(0.6204 0.195 253.83)" stop-opacity="0"/>', '<stop offset="0" style="stop-color:var(--accent)" stop-opacity=".35"/><stop offset="1" style="stop-color:var(--accent)" stop-opacity="0"/>')
html = rep(html, '<path d="${d}" fill="none" stroke="oklch(0.6204 0.195 253.83)" stroke-width="2.5"/>', '<path d="${d}" fill="none" style="stroke:var(--accent)" stroke-width="2.5"/>')

html = rep(html, "const h = location.hash.slice(1); if (P[h]) current = h;", "const h = location.hash.slice(1); if (P[h] || VIEWS[h]) current = h;")
html = rep(html, '<span class="t">النوافذ</span>', '<span class="t">النوافذ</span>\n  <a class="btn btn-primary btn-sm" href="#kit" data-go="kit" style="justify-content:center">مكتبة المكونات وكل النوافذ</a>')
html = rep(html, "const h = location.hash.slice(1); if (P[h] || VIEWS[h]) current = h;", "window.PC = { SP, openForm, openConfirm, closeModal, closePop, BESPOKE_FORMS, go: (id) => { current = id; render(); } }; /* hooks for the preview's own audits */\nconst h = location.hash.slice(1); if (P[h] || VIEWS[h]) current = h;")
html = rep(html, "<p>${sub || p[5]}</p>${actionPills(p)}</div>", "<p>${sub || p[5]}</p>${title === undefined ? actionPills(p) : ''}</div>")  # designed pages bring their own buttons
# Page dispatch: bespoke views first, then pages drawn from the extracted specs, then the old placeholder.
html = rep(html, "$('#page').innerHTML = current === 'dashboard' ? dashboard(p) :", "$('#page').innerHTML = VIEWS[current] ? VIEWS[current](p) : current !== 'dashboard' && SP.pages[current] ? listPage(p, SP.pages[current]) : current === 'dashboard' ? dashboard(p) :")
html = rep(html, "  renderSide(); drawChart(); renderTab();", "  renderSide(); drawChart(); renderTab(); tblDrawAll();")

# 7. Icons.
icons = os.path.join(S, 'lucide', 'package', 'icons')
cands = set(re.findall(r'#i-([a-z0-9-]+)', html)) | set(re.findall(r"'([a-z0-9]+(?:-[a-z0-9]+)*)'", html)) | {'sun', 'moon'}
names = sorted(n for n in cands if os.path.exists(os.path.join(icons, n + '.svg')))
syms = []
for n in names:
    inner = re.search(r'<svg[^>]*>(.*)</svg>', open(os.path.join(icons, n + '.svg')).read(), re.S).group(1)
    syms.append(f'<symbol id="i-{n}" viewBox="0 0 24 24">{" ".join(re.sub(r"<!--.*?-->", "", inner, flags=re.S).split())}</symbol>')
html = html.replace('<!--SPRITE-->', '<svg width="0" height="0" style="position:absolute" aria-hidden="true">' + ''.join(syms) + '</svg>')
html = html.replace('/*DATA*/', data)
html = html.replace('<title>PowerCollect Shell</title>', '<title>PowerCollect Dashboard</title>')
out = os.path.join(base, 'powercollect-dashboard.html')
open(out, 'w').write(html)
print(len(names), 'icons |', len(html) // 1024, 'KB')
