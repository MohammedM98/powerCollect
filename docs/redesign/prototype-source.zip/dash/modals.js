
/* ═══ Money flows: spotlight → checkout, onboarding, charge, discount, split ═══
   Fields are exactly the ones in the current forms (see the inventory); only the layout is new. */
const SUBS = [
  { n: 'خالد منصور', a: '202600148', box: 'الطبلون 14، حي الزيتون', br: 'الفرع الشمالي', bal: 640, last: '13 أيلول، ₪ 320', brk: '10A' },
  { n: 'سعاد ناصر', a: '202600118', box: 'الطبلون 21، الصناعة', br: 'الفرع الشرقي', bal: 1940, last: '2 تموز، ₪ 200', brk: '6A' },
  { n: 'محمود داود', a: '202600204', box: 'الطبلون 3، المدرسة', br: 'فرع الوسط', bal: 214.5, last: '2 تشرين الثاني', brk: '10A' },
  { n: 'هبة يوسف', a: '202600367', box: 'الطبلون 9، السوق', br: 'الفرع الشمالي', bal: 120, last: '—', brk: '16A' },
  { n: 'عمر الشريف', a: '202600311', box: 'الطبلون 14، حي الزيتون', br: 'الفرع الشمالي', bal: 95, last: 'اليوم، $ 50', brk: '20A' },
  { n: 'نادية عيسى', a: '202600092', box: 'الطبلون 9، السوق', br: 'الفرع الجنوبي', bal: 0, last: 'اليوم، حوالة', brk: '16A' },
  { n: 'ليلى حسن', a: '202600057', box: 'الطبلون 3، المدرسة', br: 'فرع الوسط', bal: 0, last: '1 آب', brk: '6A' },
];
const subBy = (name) => SUBS.find((s) => s.n === name) || SUBS[0];
const money = (n) => (Math.round((+n || 0) * 100) / 100).toLocaleString('en', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const num = (v) => parseFloat(String(v ?? '').replace(/,/g, '')) || 0;
const CUR = { ILS: ['₪', 'شيكل', 1], USD: ['$', 'دولار', 3.7], JOD: ['د.أ', 'دينار', 5.22], EUR: ['€', 'يورو', 4.01] };
const BANKS = [['بنك فلسطين', 'BOP', 'oklch(0.47 0.13 150)'], ['محفظة بالباي', 'PP', 'oklch(0.5 0.13 55)'], ['جوال باي', 'JP', 'oklch(0.5 0.2 300)'], ['البنك الإسلامي الفلسطيني', 'PIB', 'oklch(0.46 0.1 175)'], ['البنك الإسلامي العربي', 'AIB', 'oklch(0.46 0.1 210)'], ['بنك القدس', 'QB', 'oklch(0.47 0.16 25)', 'sender']];
const esc2 = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let MO = null;

function mount(cls, html) {
  $('.mback')?.remove();
  const back = document.createElement('div'); back.className = 'mback';
  back.innerHTML = `<div class="modal ${cls}" role="dialog" aria-modal="true" style="position:relative">${html}<div class="sheet-host"></div></div>`;
  document.body.append(back);
  back.addEventListener('mousedown', (e) => { if (e.target === back) tryClose(); });
  return back.querySelector('.modal');
}
function closeModal() { $('.mback')?.remove(); MO = null; }
function tryClose() {
  if (!MO) return closeModal();
  if (MO.sheet) { MO.sheet = false; $('.sheet-host', MO.el).innerHTML = ''; return; }
  if (MO.dirty && !MO.done && MO.discard) return sheet(`<div class="cf"><div class="ic warn">${ic('triangle-alert', 'i i-lg')}</div></div><h3>${MO.discard}</h3><p>ما أدخلته لم يُحفظ بعد.</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">متابعة التعديل</button><button class="btn btn-primary" style="background:var(--danger)" data-act="close">تجاهل</button></div>`);
  closeModal();
}
function sheet(html) { MO.sheet = true; $('.sheet-host', MO.el).innerHTML = `<div class="sheet">${html}</div>`; }
function success(title, amount, sub, actions) {
  MO.done = true;
  sheet(`<div class="done-ic"><svg viewBox="0 0 56 56"><circle cx="28" cy="28" r="25"/><path d="M17 29l7 7 15-16"/></svg></div><h3>${title}</h3>${amount ? `<div class="done-amt n">${amount}</div>` : ''}<p>${sub}</p><div class="btns">${actions}</div>`);
}
const closeBtn = `<button class="btn btn-ghost btn-icon" data-act="close" aria-label="إغلاق (Esc)" title="إغلاق (Esc)">${ic('x')}</button>`;
const subCtx = (s) => `<div class="ctx"><span class="av2">${s.n[0]}</span><div><b>${s.n}</b><small>${s.a}، ${s.box}</small></div><div class="bal"><small>الرصيد الحالي</small><b class="n">₪ ${money(s.bal)}</b></div></div>`;

/* ── 1. Spotlight: find the subscriber (تسجيل دفعة — البحث عن المشترك) ── */
function openQuickPay() {
  const el = mount('spot', `<div class="spot-in">${ic('search', 'i i-lg')}<input id="sq" placeholder="ابحث عن المشترك بالاسم أو رقم الحساب أو الجوال" autocomplete="off"><span class="kbd">Esc</span></div><div class="spot-list" id="sl"></div><div class="spot-foot"><span><span class="kbd">↑</span><span class="kbd">↓</span> تنقل</span><span><span class="kbd">↵</span> تسجيل دفعة</span><span style="margin-inline-start:auto">${SUBS.length} مشتركين مطابقين</span></div>`);
  MO = { el, id: 'quickPay', i: 0 };
  const draw = () => {
    const q = $('#sq').value.trim();
    const list = SUBS.filter((s) => !q || s.n.includes(q) || s.a.includes(q));
    MO.list = list; MO.i = Math.min(MO.i, Math.max(0, list.length - 1));
    const hl = (t) => q ? t.replace(q, `<mark>${q}</mark>`) : t;
    $('#sl').innerHTML = list.length ? `<div class="grp-t">المشتركون المطابقون</div>${list.map((s, i) => `<button class="spot-item ${i === MO.i ? 'on' : ''}" data-act="pick" data-who="${s.n}"><span class="av2">${s.n[0]}</span><span class="t"><b>${hl(s.n)}</b><small>${hl(s.a)}، ${s.box}</small></span><span class="bal"><b class="n" style="${s.bal ? 'color:color-mix(in oklab, var(--danger) 78%, var(--foreground))' : ''}">₪ ${money(s.bal)}</b><small>${s.bal ? 'عليه' : 'مسدّد'}</small></span>${ic('arrow-left', 'i i-sm go')}</button>`).join('')}` : `<div style="padding:40px;text-align:center;color:var(--muted)">لا يوجد مشترك مطابق</div>`;
  };
  $('#sq').addEventListener('input', () => { MO.i = 0; draw(); });
  $('#sq').addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); MO.i = (MO.i + (e.key === 'ArrowDown' ? 1 : -1) + MO.list.length) % MO.list.length; draw(); }
    if (e.key === 'Enter' && MO.list[MO.i]) openPayment(MO.list[MO.i].n);
  });
  draw(); $('#sq').focus();
}

/* ── 2. Checkout: تسجيل دفعة ── */
function openPayment(who) {
  const s = subBy(who);
  const RECV = BANKS.filter((b) => b[3] !== 'sender');
  const el = mount('co', `<div class="co-grid">
    <section class="co-main">
      <div class="co-top"><span class="tile-ic" data-tone="pay" style="width:46px;height:46px;border-radius:16px;display:grid;place-items:center;background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)">${ic('hand-coins', 'i i-lg')}</span><div><h2>تسجيل دفعة</h2><p>${s.n}، حساب ${s.a}</p></div><div class="end">${closeBtn}</div></div>
      <div class="amount"><small>المبلغ المستلم</small>
        <div class="amount-row"><div class="cur" id="cur"><button type="button" data-act="cur-toggle" aria-label="عملة الدفع"><span id="curSym">₪</span>${ic('chevron-down', 'i i-sm')}</button><div class="cur-menu">${Object.entries(CUR).map(([k, [sym, name]]) => `<button type="button" data-act="cur" data-cur="${k}"><span>${name} (${k})</span><b>${sym}</b></button>`).join('')}</div></div><input id="amt" inputmode="decimal" placeholder="0.00" autocomplete="off" aria-label="المبلغ المستلم"></div>
        <div class="conv" id="conv"></div>
        <div class="quick">${s.bal > 0 ? `<button type="button" class="fill-link" data-act="fill">تسديد كامل الدين، ₪ ${money(s.bal)}</button>` : ''}${[50, 100, 200].map((v) => `<button type="button" class="qchip" data-act="pm-quick" data-v="${v}">${v}</button>`).join('')}</div>
        <div class="notice" id="over" hidden></div>
      </div>
      <div><div class="fs"><h4>طريقة الدفع</h4></div>
        <div class="methods" role="radiogroup">
          <button class="method" role="radio" aria-checked="true" data-act="method" data-m="transfer"><span class="art bank">${ic('landmark', 'i i-lg')}</span><span><b>تحويل بنكي أو محفظة</b><small>${RECV.slice(0, 3).map((b) => b[0]).join('، ')}…</small></span><span class="tick">${ic('check', 'i i-sm')}</span><span class="kbd key">1</span></button>
          <button class="method" role="radio" aria-checked="false" data-act="method" data-m="cash"><span class="art cash">${ic('banknote', 'i i-lg')}</span><span><b>نقد</b><small>استُلم المبلغ نقدًا</small></span><span class="tick">${ic('check', 'i i-sm')}</span><span class="kbd key">2</span></button>
        </div></div>
      <div class="reveal on" id="xfer"><div><div class="inner">
        <div class="ff w6"><label>البنك المستلم <span class="req">*</span></label><div class="banks">${RECV.map(([n, c, col]) => `<button class="bank" type="button" role="radio" aria-checked="false" data-act="bank" data-bank="${n}"><span class="lg" style="background:${col}">${c}</span>${n}</button>`).join('')}</div></div>
        <div class="fg">
          <div class="ff"><label>البنك المرسل</label>${pickBtn('sbank', '', ['غير محدد', ...BANKS.map((b) => b[0])], { icon: 'landmark', ph: 'اختر البنك أو المحفظة المحوّل منها' })}</div>
          <div class="ff"><label>تاريخ وصول الحوالة إلى البنك <span class="opt">اختياري</span></label>${dateBtn('xdate', '')}<span class="hint">اتركه فارغًا إن لم تتأكد منه. تُسجّل الحركة بتاريخ تسجيلها في النظام.</span></div>
          <div class="ff"><div class="flab">اسم المحوِّل <span class="req">*</span><label class="lbl-sw"><input type="checkbox" data-f="self" checked>المشترك نفسه</label></div><div class="fc ro" id="senderBox">${ic('user', 'i i-sm')}<input data-f="sender" value="${s.n}" disabled aria-label="اسم المحوِّل"></div></div>
          <div class="ff"><label>الرقم المرجعي <span class="req">*</span></label><div class="fc" id="refBox">${ic('hash', 'i i-sm')}<input data-f="ref" placeholder="مثال: TRX-48213" data-ltr aria-label="الرقم المرجعي"></div><span class="hint" id="refHint">من إشعار الحوالة</span></div>
        </div>
        <label class="ack" id="dupAck" hidden><input type="checkbox" class="cb" data-f="dupOk"><span>أؤكد تسجيل الدفعة بالرقم نفسه</span></label>
      </div></div></div>
      <div><div class="extras"><button class="extra on" data-act="extra" data-x="paper">${ic('plus', 'i i-sm')}رقم السند اليدوي</button><button class="extra on" data-act="extra" data-x="note">${ic('plus', 'i i-sm')}ملاحظة</button></div>
        <div class="reveal" id="x-paper"><div><div class="inner"><div class="ff w6"><div class="flab">رقم السند اليدوي <span class="opt">رقم الوصل الورقي، اختياري</span><button type="button" class="lbl-act" data-act="extra-hide" data-x="paper" aria-label="إخفاء الحقل">${ic('eye-off', 'i i-sm')}إخفاء</button></div><div class="fc">${ic('receipt', 'i i-sm')}<input data-f="paper" placeholder="مثال: 00412" data-ltr maxlength="50"></div></div></div></div></div>
        <div class="reveal on" id="x-note"><div><div class="inner"><div class="ff w6"><div class="flab">ملاحظة <span class="opt">اختياري</span><button type="button" class="lbl-act" data-act="extra-hide" data-x="note" aria-label="إخفاء الحقل">${ic('eye-off', 'i i-sm')}إخفاء</button></div><div class="fc">${ic('sticky-note', 'i i-sm')}<input data-f="note" placeholder="أي تفصيل يُحفظ مع الدفعة" maxlength="1000"></div></div></div></div></div>
      </div>
      <button class="btn btn-tone solid cta" data-tone="pay" id="cta" data-act="pay-review" disabled>${ic('lock', 'i i-sm')}<span id="ctaT">أدخل المبلغ المستلم</span></button>
      <div class="cta-sub">${ic('shield-check', 'i i-sm')}يُسجّل في صندوقك C-418 ويُطبع الوصل بعد التأكيد، <span class="kbd">Ctrl</span><span class="kbd">↵</span></div>
    </section>
    <aside class="co-receipt">
      <div class="paper"><div class="pt"><span class="mk">${MA}</span><div class="co"><b>مصعب العجل وأحمد الكفارنة</b><small>للتجارة العامة</small></div><div class="no"><b>وصل قبض</b><span class="n">V-08813، 16/11/2026</span></div></div>
        <div class="who"><b>${s.n}</b><small>حساب ${s.a}، ${s.box}</small></div>
        <div class="ln"><span>الرصيد الحالي</span><b>₪ ${money(s.bal)} <small class="dir">${s.bal > 0 ? 'عليه' : 'له'}</small></b></div>
        <div class="ln pay"><span>هذه الدفعة <small id="rMethod" class="dir">تحويل</small></span><b id="rPay">− ₪ 0.00</b></div>
        <div class="tot"><span>الرصيد بعدها</span><b id="rAfter">₪ ${money(s.bal)}</b></div>
        <div class="cover"><div class="kv"><span>تغطية المستحق</span><b class="n" id="rCov">0%</b></div><span class="bar"><i id="rCovBar" style="width:0"></i></span></div>
        <div class="qr"></div>
        <div class="stamp"><span>C-418، أحمد سالم</span><span>${s.br}</span></div></div>
      <div class="rc-meta"><div>${ic('clock', 'i i-sm')}آخر دفعة: ${s.last}</div><div>${ic('printer', 'i i-sm')}يُطبع تلقائيًا بعد التسجيل</div></div>
    </aside></div>`);
  MO = { el, id: 'payment', s, cur: 'ILS', method: 'transfer', bank: null, f: { self: true, sender: s.n }, discard: 'تجاهل الدفعة؟' };
  const upd = () => {
    const a = num($('#amt').value), [sym, name, rate] = CUR[MO.cur], ils = a * rate, after = s.bal - ils, xfer = MO.method === 'transfer';
    $('#curSym').textContent = sym;
    $('#conv').textContent = MO.cur !== 'ILS' ? `سعر الصرف المعتمد: 1 ${name} = ${rate} شيكل${a ? `، القيمة المسجلة على حساب المشترك: ${money(ils)} شيكل.` : ''}` : '';
    // Overpayment: a credit note when a little above, a required confirmation when far above.
    const far = s.bal >= 0 && ils > s.bal * 2 + 200, over = ils > s.bal && a > 0;
    $('#over').hidden = !over;
    $('#over').className = 'notice ' + (far ? 'bad' : 'warn');
    $('#over').innerHTML = far ? `${ic('triangle-alert', 'i i-sm')}<div><b>المبلغ أكبر بكثير من المستحق (₪ ${money(s.bal)}). تأكد أنك لم تكتب رقمًا زائدًا بالخطأ.</b><label class="ack" style="margin-top:8px"><input type="checkbox" class="cb" data-f="overOk" ${MO.f.overOk ? 'checked' : ''}><span>أؤكد أن المبلغ ${money(a)} ${name} صحيح</span></label></div>` : `${ic('info', 'i i-sm')}<div>المبلغ أكبر من المستحق على المشترك (₪ ${money(s.bal)})، وسيبقى له رصيد دائن قدره ₪ ${money(ils - s.bal)}.</div>`;
    $('#x-paper').classList.toggle('on', !xfer && !MO.paperHidden); $$('[data-x="paper"].extra', el).forEach((b) => b.classList.toggle('on', xfer || !MO.paperHidden));
    $('#rPay').textContent = `− ₪ ${money(ils)}`;
    $('#rMethod').textContent = xfer ? (MO.bank ? `تحويل، ${MO.bank}` : 'تحويل') : 'نقد';
    $('#rAfter').textContent = after < 0 ? `₪ ${money(-after)} له` : after === 0 ? 'مسدّد ✓' : `₪ ${money(after)} عليه`;
    $('#rAfter').classList.toggle('ok', after <= 0);
    const cov = s.bal > 0 ? Math.min(100, Math.round(ils / s.bal * 100)) : 100; $('#rCov').textContent = cov + '%'; $('#rCovBar').style.width = cov + '%';
    // Sender: the subscriber by default; switching «المشترك نفسه» off makes the name editable and empty.
    const sb = $('[data-f="sender"]'); sb.disabled = !!MO.f.self; $('#senderBox').classList.toggle('ro', !!MO.f.self); if (MO.f.self) sb.value = s.n;
    const ref = (MO.f.ref || '').trim(), used = /^TRX-48213$/i.test(ref);
    $('#refHint').className = 'hint ' + (ref ? (used ? 'warn' : 'ok') : ''); $('#refHint').textContent = ref ? (used ? 'الرقم المرجعي مكرر: مسجَّل مسبقًا في السند V-08790، سعاد ناصر' : '✓ الرقم المرجعي متاح.') : 'من إشعار الحوالة';
    $('#dupAck').hidden = !used; $('#refBox').classList.toggle('warnb', used);
    const sender = MO.f.self ? s.n : (MO.f.sender || '').trim();
    const ok = a > 0 && (!far || MO.f.overOk) && (!xfer || (MO.bank && ref && sender && (!used || MO.f.dupOk)));
    $('#cta').disabled = !ok;
    $('#ctaT').textContent = !a ? 'أدخل المبلغ المستلم' : far && !MO.f.overOk ? 'أكّد المبلغ أولًا' : xfer && !MO.bank ? 'اختر البنك المستلم' : xfer && !sender ? 'أدخل اسم المحوِّل' : xfer && !ref ? 'أدخل الرقم المرجعي' : xfer && used && !MO.f.dupOk ? 'أكّد الرقم المكرر أولًا' : `تسجيل ${money(a)} ${MO.cur === 'ILS' ? '₪' : MO.cur}`;
    MO.dirty = a > 0 || ['ref', 'paper', 'note'].some((k) => MO.f[k]);
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) MO.f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; if (k === 'self' && !e.target.checked) { MO.f.sender = ''; $('[data-f="sender"]').value = ''; setTimeout(() => $('[data-f="sender"]').focus(), 0); } upd(); });
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'amt' && !$('#cta').disabled) $('#cta').click(); if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !$('#cta').disabled) { e.preventDefault(); $('#cta').click(); } if (!e.target.closest('input, textarea') && (e.key === '1' || e.key === '2')) $(`[data-m="${e.key === '1' ? 'transfer' : 'cash'}"]`, el).click(); });
  el.addEventListener('click', (e) => {
    const q = e.target.closest('[data-act="pm-quick"]'); if (q) { $('#amt').value = q.dataset.v; upd(); return $('#amt').focus(); }
    if (e.target.closest('[data-act="extra-hide"][data-x="paper"]')) MO.paperHidden = true;
    if (e.target.closest('[data-act="extra"][data-x="paper"]')) MO.paperHidden = false;
    if (e.target.closest('[data-act="method"]')) setTimeout(upd, 0);
  });
  el.addEventListener('pick', (e) => { if (e.detail.key === 'sbank') MO.f.sbank = e.detail.value; if (e.detail.key === 'xdate') MO.f.date = e.detail.value; });
  upd(); $('#amt').focus();
}

/* ── 3. إنشاء مشترك — SubscriptionModal.jsx: five sections in one scrolling form, the side index follows the scroll ── */
const OB_SECTIONS = [['user', 'بيانات المشترك', 'الاسم والهوية والجوال والحالة'], ['gauge', 'نوع الاشتراك والقاطع', 'المحاسبة والتعرفة والقاطع والحد الأدنى'], ['map-pin', 'الموقع والعداد', 'الفرع والمنطقة والطبلون'], ['calendar-clock', 'معلومات الاشتراك', 'القراءة والرسوم والتاريخ'], ['notebook-pen', 'معلومات إضافية', 'العنوان وأي معلومة أخرى']];
const TARIFFS = [['house', 'منزلي', '1.50'], ['store', 'تجاري', '1.80']];
const BREAKERS = [['6', 20], ['10', 30], ['16', 45], ['20', 60], ['32', 90], ['63', 160]];
const BRANCH_AREA = { 'الفرع الشمالي': 'الشجاعية', 'الفرع الجنوبي': 'رفح', 'فرع الوسط': 'دير البلح', 'الفرع الشرقي': 'التفاح', 'الفرع الغربي': 'الدرج' };
const AREA_SUBS = { 'الشجاعية': ['حي الزيتون', 'السوق', 'المدرسة', 'الشجاعية الشرقية'], 'التفاح': ['التفاح'], 'الدرج': ['الدرج'], 'رفح': ['الصناعة'], 'دير البلح': ['الصناعة'] };
const BOXES = [['الطبلون 14', 'حي الزيتون', 38, 40], ['الطبلون 9', 'السوق', 41, 50], ['الطبلون 3', 'المدرسة', 29, 50], ['الطبلون 21', 'الصناعة', 33, 50], ['الطبلون 1', 'الشجاعية الشرقية', 47, 50], ['الطبلون 2', 'الشجاعية الشرقية', 22, 40], ['الطبلون 5', 'التفاح', 36, 50], ['الطبلون 7', 'التفاح', 49, 50], ['الطبلون 11', 'الدرج', 18, 40], ['الطبلون 12', 'الدرج', 30, 50], ['الطبلون 16', 'حي الزيتون', 44, 50], ['الطبلون 18', 'السوق', 12, 30]];
const breakerMin = (b) => (BREAKERS.find((x) => x[0] === b) || [, 30])[1];
const tariffRate = (t) => (TARIFFS.find((x) => x[1] === t) || [, , '1.50'])[2];
function openSubscriber() {
  const el = mount('ob', `<div class="ob-grid"><aside class="ob-side"><div class="mcard" id="mcard"></div><nav class="ob-nav" id="obNav" aria-label="أقسام النموذج"></nav><div class="hint" style="margin-top:auto">${ic('info', 'i i-sm')} يُنشأ رقم الحساب تلقائيًا عند الحفظ.</div></aside>
    <section class="ob-main"><div class="mh"><span class="tile-ic">${ic('user-plus', 'i i-lg')}</span><div><h2>إنشاء مشترك</h2><p>الحقول المعلّمة بـ <span class="req">*</span> مطلوبة</p></div><div class="end">${closeBtn}</div></div><div class="ob-body" id="obB"></div>
    <div class="mfoot"><div class="ob-prog" id="obProg"></div><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-primary" data-act="ob-save" id="obSave">${ic('check', 'i i-sm')}حفظ</button></div></div></section></div>`);
  MO = { el, id: 'subscriber', now: 0, touched: {}, tried: false, f: { status: 'قيد الانتظار', acct: 'أسبوعي', tariff: 'منزلي', brk: '10', seg: 'عادي', branch: 'الفرع الشمالي', sub: 'حي الزيتون', box: 'الطبلون 14', reading: '', date: '2026-11-16', fee: '150.00', feeOn: false, kwOpen: false, minOpen: false }, discard: 'تجاهل التغييرات؟' };
  obRender();
  [$('#obB'), $('.ob-grid', el)].forEach((n) => n.addEventListener('scroll', obSpy, { passive: true }));
  $('#obB [data-f="name"]').focus();
}
function obField(key, label, attrs = '', o = {}) {
  return `<div class="ff ${o.w || ''}"><${o.flab ? 'div class="flab"' : `label for="f-${key}"`}>${label}${o.req ? ' <span class="req">*</span>' : ''}${o.opt ? ' <span class="opt">اختياري</span>' : ''}${o.flab || ''}</${o.flab ? 'div' : 'label'}><div class="fc ${o.cls || ''}" id="fc-${key}">${o.icon ? ic(o.icon, 'i i-sm') : ''}<input id="f-${key}" data-f="${key}" value="${esc2(MO.f[key] ?? '')}" ${attrs}>${o.addon ? `<span class="addon">${o.addon}</span>` : ''}</div>${o.hint !== undefined ? `<span class="hint" id="h-${key}">${o.hint}</span>` : ''}</div>`;
}
const obPick = (key, label, opts, o = {}) => `<div class="ff ${o.w || ''}"><label>${label}${o.req ? ' <span class="req">*</span>' : ''}</label>${pickBtn(key, MO.f[key], opts, { icon: o.icon })}${o.hint ? `<span class="hint">${o.hint}</span>` : ''}</div>`;
const obHead = (i) => { const [icon, t, d] = OB_SECTIONS[i]; return `<header class="obs-h"><span class="ic">${ic(icon, 'i i-sm')}</span><div><h3>${t}</h3><p>${d}</p></div></header>`; };
const lockLink = (act, label) => `<button type="button" class="lbl-act" data-act="${act}">${ic('lock-open', 'i i-sm')}${label}</button>`;
function obRender() {
  const f = MO.f, area = BRANCH_AREA[f.branch] || '', subs = AREA_SUBS[area] || [];
  const boxes = BOXES.filter((b) => !f.sub || b[1] === f.sub); const boxList = boxes.length ? boxes : BOXES;
  $('#obB').innerHTML = `
    <section class="obs" id="obs-0">${obHead(0)}<div class="fg">
      ${obField('name', 'الاسم', 'placeholder="الاسم الرباعي كما في الهوية" autocomplete="off"', { req: 1, w: 'w6', icon: 'user', hint: '' })}
      ${obField('nid', 'رقم الهوية', 'inputmode="numeric" maxlength="9" placeholder="9 أرقام" data-ltr', { icon: 'id-card', hint: '' })}
      ${obField('phone', 'رقم الجوال', 'inputmode="tel" maxlength="12" placeholder="059 XXX XXXX" data-ltr', { icon: 'phone', hint: '' })}
      <div class="ff w6"><label>الحالة <span class="req">*</span></label><div class="seg fit">${['نشط', 'قيد الانتظار', 'مفصول'].map((x) => `<button type="button" aria-pressed="${f.status === x}" data-act="ob-pick" data-k="status" data-v="${x}">${x}</button>`).join('')}</div><span class="hint" id="h-status"></span></div></div></section>
    <section class="obs" id="obs-1">${obHead(1)}<div class="fg">
      <div class="ff w6"><label>نوع المحاسبة</label><div class="seg fit">${['أسبوعي', 'شهري'].map((x) => `<button type="button" aria-pressed="${f.acct === x}" data-act="ob-pick" data-k="acct" data-v="${x}">${x}</button>`).join('')}</div></div>
      <div class="ff w6"><label>نوع الاشتراك <span class="req">*</span></label><div class="rcs" role="radiogroup">${TARIFFS.map(([i, n, r]) => `<button class="rc" type="button" role="radio" aria-checked="${f.tariff === n}" data-act="ob-pick" data-k="tariff" data-v="${n}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${n}</b><small class="n">${r} ش/ك.و</small></span></button>`).join('')}</div></div>
      ${obField('kw', 'سعر الكيلو', 'inputmode="decimal" data-ltr', { addon: '₪', cls: 'ro', flab: lockLink('ob-kw-open', 'تعديل السعر'), hint: '' })}
      ${obPick('seg', 'تصنيف الزبائن', ['عادي', 'موظفو أبو زايد', 'مؤسسات'], { icon: 'tags' })}
      <div class="ff w6"><label>القاطع</label><div class="chips-pick tall">${BREAKERS.map(([a, m]) => `<button type="button" aria-pressed="${f.brk === a}" data-act="ob-pick" data-k="brk" data-v="${a}">${a} أمبير<small>الحد الأدنى ${m} ش</small></button>`).join('')}</div></div>
      ${obField('min', 'الحد الأدنى', 'inputmode="decimal" data-ltr', { req: 1, addon: '₪', cls: 'ro', flab: lockLink('ob-min-open', 'تعديل يدوي'), hint: '' })}</div></section>
    <section class="obs" id="obs-2">${obHead(2)}<div class="fg">
      ${obPick('branch', 'الفرع', Object.keys(BRANCH_AREA), { req: 1, w: 'w2', icon: 'building-2', hint: 'تغيير الفرع يمسح منطقة 2 والطبلون' })}
      <div class="ff w2"><label>المنطقة</label><div class="fc ro">${ic('lock', 'i i-sm')}<span class="ro-v" style="font-family:var(--f-body)">${area || 'اختر فرعًا أولاً لعرض منطقته.'}</span></div><span class="hint">للقراءة فقط، من الفرع</span></div>
      ${subs.length ? obPick('sub', 'منطقة 2', subs, { w: 'w2', icon: 'map-pinned' }) : `<div class="ff w2"><label>منطقة 2</label><div class="fc ro"><span class="ro-v" style="font-family:var(--f-body);font-weight:500;color:var(--muted)">لا توجد منطقة 2 في هذه المنطقة بعد.</span></div></div>`}
      <div class="ff w6"><label>الطبلون (الاسم والرقم)</label>${richBtn('box', f.box, { icon: 'network', label: 'الطبلون', ph: 'اختر الطبلون', search: 'بحث عن طبلون...', opts: boxList.map(([n, a, used, cap]) => ({ v: n, t: n, sub: a, used, cap })) })}</div></div></section>
    <section class="obs" id="obs-3">${obHead(3)}<div class="fg">
      ${obField('reading', 'القراءة السابقة', 'inputmode="numeric" data-ltr', { w: 'w2', addon: 'ك.و', hint: '' })}
      <div class="ff w2"><label>تاريخ الاشتراك</label>${dateBtn('date', f.date)}</div>
      ${obField('fee', 'رسوم الاشتراك', 'inputmode="decimal" data-ltr', { w: 'w2', addon: '₪', cls: 'ro', flab: `<label class="lbl-sw"><input type="checkbox" data-f="feeOn" ${f.feeOn ? 'checked' : ''}>تحميل رسوم اشتراك</label>`, hint: '' })}</div></section>
    <section class="obs" id="obs-4">${obHead(4)}<div class="fg">
      <div class="ff w6"><label for="f-address">العنوان <span class="opt">اختياري</span></label><div class="fc ta"><textarea id="f-address" data-f="address" placeholder="الحي، الشارع، علامة مميزة">${esc2(f.address || '')}</textarea></div></div>
      <div class="ff w6"><label for="f-other">معلومات أخرى <span class="opt">اختياري</span></label><div class="fc ta"><textarea id="f-other" data-f="other" placeholder="أي معلومة تفيد المحصّل">${esc2(f.other || '')}</textarea></div></div></div></section>`;
  obSync();
}
/** Rules from the form itself: name required; ID 9 digits; mobile 10 digits starting 059 or 056; previous reading when active; minimum when unlocked. */
function obErrors() {
  const f = MO.f, e = {}, phone = (f.phone || '').replace(/\s/g, '');
  if (!(f.name || '').trim()) e.name = 'اكتب اسم المشترك';
  if (f.nid && !/^\d{9}$/.test(f.nid)) e.nid = 'رقم الهوية يجب أن يتكون من 9 أرقام';
  if (phone && !/^05[96]\d{7}$/.test(phone)) e.phone = 'رقم الجوال يجب أن يتكون من 10 أرقام ويبدأ بـ 059 أو 056';
  if (f.status === 'نشط' && !String(f.reading).trim()) e.reading = 'أدخل القراءة السابقة للعدّاد';
  if (f.minOpen && !(num(f.min) > 0)) e.min = 'أدخل الحد الأدنى';
  if (f.feeOn && !(num(f.fee) > 0)) e.fee = 'أدخل رسوم الاشتراك';
  return e;
}
const OB_OF = { name: 0, nid: 0, phone: 0, min: 1, reading: 3, fee: 3 };
const OB_HINT = { name: 'يمكنك إضافة وصف إلى الاسم مثل: محمد حمدان، المنزل.', nid: 'إن كانت الهوية مسجلة يُربط الاشتراك بنفس ملف المشترك', phone: 'للتذكيرات والوصل' };
function obSync() {
  const f = MO.f, err = obErrors(), show = (k) => err[k] && (MO.tried || MO.touched[k]);
  ['name', 'nid', 'phone'].forEach((k) => { const h = $('#h-' + k); $('#fc-' + k).classList.toggle('err', !!show(k)); $('#f-' + k).setAttribute('aria-invalid', String(!!show(k))); h.className = 'hint ' + (show(k) ? 'bad' : k === 'nid' && f.nid && !err.nid ? 'ok' : ''); h.textContent = show(k) ? err[k] : k === 'nid' && f.nid && !err.nid ? '✓ لا يوجد مشترك بنفس الهوية' : OB_HINT[k]; });
  $('#h-status').textContent = f.status === 'نشط' ? 'عند التفعيل أدخل القراءة السابقة للعدّاد، منها يبدأ حساب الاستهلاك.' : '';
  // Price per kWh and minimum: read-only from the tariff and breaker until unlocked (each asks for confirmation).
  const kw = $('[data-f="kw"]'); kw.disabled = !f.kwOpen; if (!f.kwOpen) { f.kw = tariffRate(f.tariff); kw.value = f.kw; } $('#fc-kw').classList.toggle('ro', !f.kwOpen);
  $('#h-kw').textContent = f.kwOpen ? 'سعر خاص بهذا المشترك' : `من التعرفة: ${tariffRate(f.tariff)} ش/ك.و`; $('[data-act="ob-kw-open"]').hidden = f.kwOpen;
  const mi = $('[data-f="min"]'); mi.disabled = !f.minOpen; if (!f.minOpen) { f.min = breakerMin(f.brk).toFixed(2); mi.value = f.min; } $('#fc-min').classList.toggle('ro', !f.minOpen); $('#fc-min').classList.toggle('err', !!show('min'));
  $('#h-min').className = 'hint ' + (show('min') ? 'bad' : ''); $('#h-min').textContent = show('min') ? err.min : f.minOpen ? 'حد أدنى خاص بهذا المشترك' : `من القاطع ${f.brk} أمبير`; $('[data-act="ob-min-open"]').hidden = f.minOpen;
  const rd = $('[data-f="reading"]'), active = f.status === 'نشط'; rd.disabled = !active; $('#fc-reading').classList.toggle('ro', !active); $('#fc-reading').classList.toggle('err', !!show('reading'));
  $('#h-reading').className = 'hint ' + (show('reading') ? 'bad' : ''); $('#h-reading').textContent = show('reading') ? err.reading : active ? 'منها يبدأ حساب الاستهلاك.' : 'تُدخل القراءة عند تفعيل المشترك، منها يبدأ حساب استهلاكه.';
  const fe = $('[data-f="fee"]'); fe.disabled = !f.feeOn; $('#fc-fee').classList.toggle('ro', !f.feeOn); $('#fc-fee').classList.toggle('err', !!show('fee'));
  $('#h-fee').className = 'hint ' + (show('fee') ? 'bad' : ''); $('#h-fee').textContent = show('fee') ? err.fee : f.feeOn ? 'تُضاف رسوم الاشتراك إلى الرصيد وسجل المعاملات عند حفظ المشترك.' : 'لن تُضاف الرسوم إلى الرصيد. يمكنك تحميلها لاحقًا من سجل المعاملات.';
  const bad = new Set(Object.keys(err).map((k) => OB_OF[k])), done = OB_SECTIONS.map((_, i) => !bad.has(i) && (i !== 0 || !!(f.name || '').trim()));
  $('#obNav').innerHTML = OB_SECTIONS.map(([icon, t, d], i) => `<button type="button" data-act="ob-go" data-i="${i}" aria-current="${i === MO.now}"><span class="ic">${ic(icon, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span><span class="st2 ${MO.tried && bad.has(i) ? 'bad' : done[i] ? 'ok' : ''}" aria-label="${done[i] ? 'مكتمل' : 'غير مكتمل'}">${done[i] ? ic('check', 'i') : ''}</span></button>`).join('');
  const n = done.filter(Boolean).length;
  $('#obProg').innerHTML = `<span class="bar"><i style="width:${n / OB_SECTIONS.length * 100}%;${n === OB_SECTIONS.length ? 'background:var(--success)' : ''}"></i></span><span><b>${n}</b> من ${OB_SECTIONS.length} أقسام مكتملة</span>`;
  obCard();
  MO.dirty = !!(f.name || f.nid || f.phone || f.address || f.other);
}
/** The form scrolls in its own column on desktop and as one column with the side panel on phones. */
const obScroller = () => (getComputedStyle($('#obB')).overflowY === 'auto' ? $('#obB') : $('.ob-grid', MO.el));
function obSpy() {
  const b = obScroller(), top = (b === $('#obB') ? b.getBoundingClientRect().top : innerHeight * .35) + 96;
  let now = 0; $$('.obs', MO.el).forEach((s, i) => { if (s.getBoundingClientRect().top <= top) now = i; });
  if (b.scrollTop + b.clientHeight >= b.scrollHeight - 4) now = OB_SECTIONS.length - 1;
  if (now !== MO.now) { MO.now = now; $$('#obNav button').forEach((x, i) => x.setAttribute('aria-current', String(i === now))); }
}
function obSave() {
  MO.tried = true; const err = obErrors(); obSync();
  const first = ['name', 'nid', 'phone', 'min', 'reading', 'fee'].find((k) => err[k]);
  if (first) { const inp = $(`[data-f="${first}"]`); inp.closest('.ff').scrollIntoView({ block: 'center' }); inp.focus({ preventScroll: true }); return; }
  sheet(`<div class="cf"><div class="ic">${ic('user-plus', 'i i-lg')}</div></div><h3>إضافة السجل؟</h3><p>سيتم إضافة سجل جديد بالبيانات التي أدخلتها. هل تريد المتابعة؟</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">مراجعة البيانات</button><button class="btn btn-primary" data-act="ob-done">${ic('check', 'i i-sm')}نعم، أضف</button></div>`);
}
function obCard() {
  const f = MO.f;
  $('#mcard').innerHTML = `<div class="top2"><span class="mc-mark">${MA}</span><span class="chip2">${f.status}</span></div><div class="nm">${esc2(f.name) || '<span style="opacity:.7">مشترك جديد</span>'}</div><div class="acc">${esc2(f.phone) || '05— ——— ——'}</div><div class="tags2"><span>${f.tariff}، ${f.kwOpen && f.kw ? f.kw : tariffRate(f.tariff)} ش/ك.و</span><span>قاطع ${f.brk} أمبير</span><span>${f.box}</span></div>`;
}

/* Unlocking price per kWh / minimum, branch changes, saving — exact confirmation texts from SubscriptionTariffSection.jsx. */
const OB_UNLOCK = { 'ob-kw-open': ['kwOpen', 'kw', 'تعديل سعر الكيلو لهذا المشترك؟', () => `سيصبح لهذا المشترك سعر كيلو خاص به بدل سعر التعرفة (${tariffRate(MO.f.tariff)} شيكل)، ويُحسب به استهلاكه وخصوماته في القراءات القادمة. هل تريد المتابعة؟`], 'ob-min-open': ['minOpen', 'min', 'تعديل الحد الأدنى يدويًا؟', () => 'أنت على وشك تعديل الحد الأدنى لهذا المشترك يدويًا بدل القيمة المأخوذة من القاطع. هل تريد المتابعة؟'] };
document.addEventListener('click', (e) => {
  if (MO?.id !== 'subscriber') return;
  const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act;
  if (OB_UNLOCK[act]) { const [flag, key, t, body] = OB_UNLOCK[act]; MO.pendingUnlock = [flag, key]; return sheet(`<div class="cf"><div class="ic warn">${ic('lock-open', 'i i-lg')}</div></div><h3>${t}</h3><p>${body()}</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">إلغاء</button><button class="btn btn-primary" data-act="ob-unlock">نعم، عدّل</button></div>`); }
  if (act === 'ob-unlock') { const [flag, key] = MO.pendingUnlock; MO.f[flag] = true; MO.sheet = false; $('.sheet-host', MO.el).innerHTML = ''; obSync(); return $(`[data-f="${key}"]`).focus(); }
  if (act === 'ob-done') return success('تمت إضافة المشترك', '', `${MO.f.name}، رقم الحساب 202600412، ${MO.f.box}`, `<button class="btn btn-primary" data-act="close">${ic('file-text', 'i i-sm')}فتح الكشف</button><button class="btn btn-tone" data-tone="pay" data-act="close">${ic('hand-coins', 'i i-sm')}تسجيل دفعة</button><button class="btn btn-ghost" data-act="again-sub">${ic('user-plus', 'i i-sm')}مشترك آخر</button>`);
});
document.addEventListener('pick', (e) => {
  if (MO?.id !== 'subscriber') return; const k = e.detail.key;
  if (k === 'branch' || k === 'sub') {
    const f = MO.f; f[k] = e.detail.value; if (k === 'branch') { const subs = AREA_SUBS[BRANCH_AREA[f.branch]] || []; f.sub = subs[0] || ''; }
    const boxes = BOXES.filter((b) => b[1] === f.sub); f.box = (boxes[0] || BOXES[0])[0];
    const sc = obScroller(), y = sc.scrollTop; obRender(); sc.scrollTop = y;
  }
});
/* ── 4. تحميل حركة — ChargeModal.jsx ── */
const CHARGE_TYPES = [['gavel', 'غرامة مالية', 'مخالفة أو عبث بالعداد', [50, 100, 200], null, 'اكتب سبب الغرامة، مثال: توصيل خط بدون عداد'], ['unplug', 'رسوم قطع الخدمة', 'قطع الكهرباء أو إعادتها', [25, 50], 20, 'مثال: فصل بسبب تراكم الدين'], ['file-plus', 'رسوم اشتراك', 'تحميل رسوم الاشتراك على الحساب', [50, 100, 200], null, 'مثال: رسوم اشتراك المشترك الجديد'], ['scale', 'تحميل الحد الأدنى على المشترك', 'تحميل الحد الأدنى المحدد لهذا المشترك', [], 'min', '']];
function sheetModal(cls, icon, title, sub, s, body, ctaId, tone) {
  return mount('md sheet-modal ' + cls, `<div class="mh"><span class="tile-ic" ${tone ? `data-tone="${tone}" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)"` : ''}>${ic(icon, 'i i-lg')}</span><div><h2>${title}</h2><p>${sub}</p></div><div class="end">${closeBtn}</div></div><div class="mbody2">${body}</div><div class="mfoot"><span class="k"><span class="kbd">Esc</span> إغلاق</span><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-tone solid" data-tone="${tone || 'pay'}" id="${ctaId}" disabled></button></div></div>`);
}
/** Movement card (بطاقة الحركة): who, then «الرصيد الحالي» ± this line = «الرصيد بعده». */
const moveCard = (s, tag, tone, sign, afterId, midId, midLabel) => `<div class="move"><div class="move-who"><span class="av2">${s.n[0]}</span><div><b>${s.n}</b><small>حساب ${s.a}، ${s.box}، ${s.br}</small></div><span class="chip2x" data-tone="${tone}">${tag}</span></div><div class="move-eq"><div><small>الرصيد الحالي</small><b class="n">₪ ${money(s.bal)}</b><span>${s.bal > 0 ? 'عليه' : 'له'}</span></div><span class="op">${sign}</span><div><small>${midLabel}</small><b class="n" id="${midId}">₪ 0.00</b></div><span class="op">=</span><div><small>الرصيد بعده</small><b class="n" id="${afterId}">₪ ${money(s.bal)}</b><span id="${afterId}-d">${s.bal > 0 ? 'عليه' : 'له'}</span></div></div></div>`;
function openCharge(who) {
  const s = subBy(who), minC = s.min || 30;
  const el = sheetModal('', 'receipt', 'تحميل حركة', 'إضافة رسوم أو غرامة على حساب المشترك', null, `
    ${moveCard(s, 'تحميل', 'charge', '+', 'cAfter', 'cMid', 'التحميل')}
    <div class="ff w6"><label>نوع التحميل <span class="req">*</span></label><div class="rcs rcs-2" role="radiogroup">${CHARGE_TYPES.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="ch-type" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6"><div class="flab">مبلغ التحميل <span class="req">*</span><label class="lbl-sw" id="cLockSw" hidden><input type="checkbox" data-f="unlock">فتح القفل لتعديل المبلغ</label></div><div class="mini-amt" id="cAmtBox"><span>₪</span><input id="camt" inputmode="decimal" placeholder="0.00" aria-label="مبلغ التحميل"></div><div class="quick" id="cQuick" style="justify-content:flex-start;margin-top:4px"></div><span class="hint" id="cHint"></span></div>
    <div class="ff w6"><label id="cNoteL">سبب الغرامة <span class="req">*</span></label><div class="fc ta"><textarea data-f="note" id="cNote"></textarea></div><span class="hint">يظهر في كشف الحساب</span></div>`, 'cCta', 'charge');
  MO = { el, id: 'charge', s, k: 0, f: {}, discard: 'تجاهل التحميل؟' };
  const setType = (k) => {
    MO.k = k; const [, t, , quick, usual, ph] = CHARGE_TYPES[k], isMin = usual === 'min';
    $$('[data-act="ch-type"]', el).forEach((b) => b.setAttribute('aria-checked', String(+b.dataset.k === k)));
    $('#cQuick').innerHTML = quick.map((v) => `<button type="button" class="qchip" data-act="ch-quick" data-v="${v}">${v} ₪</button>`).join('');
    $('#cLockSw').hidden = !isMin; MO.f.unlock = false; $('[data-f="unlock"]').checked = false;
    if (isMin) $('#camt').value = money(minC); else if (!num($('#camt').value) || MO.autoFilled) { $('#camt').value = usual ? String(usual) : ''; }
    MO.autoFilled = isMin || !!usual;
    $('#cNoteL').innerHTML = k === 0 ? 'سبب الغرامة <span class="req">*</span>' : 'ملاحظات <span class="opt">اختياري</span>'; $('#cNote').placeholder = ph;
    upd();
  };
  const upd = () => {
    const a = num($('#camt').value), [, t, , , usual] = CHARGE_TYPES[MO.k], isMin = usual === 'min', locked = isMin && !MO.f.unlock;
    $('#camt').disabled = locked; $('#cAmtBox').classList.toggle('ro', locked);
    $('#cMid').textContent = `₪ ${money(a)}`; const after = s.bal + a; $('#cAfter').textContent = `₪ ${money(Math.abs(after))}`; $('#cAfter-d').textContent = after > 0 ? 'عليه' : 'له';
    $('#cHint').className = 'hint ' + (a > 500 ? 'warn' : ''); $('#cHint').textContent = isMin ? `الحد الأدنى للمشترك: ${money(minC)} ₪. يُسجّل كتحميل يدوي مستقل على الحساب.` : a > 500 ? 'مبلغ كبير. تأكد أنه صحيح قبل الحفظ، فهو يظهر في كشف الحساب.' : usual ? `المعتاد لهذا النوع ${usual} ₪` : '';
    const ok = a > 0 && (MO.k !== 0 || (MO.f.note || '').trim());
    $('#cCta').disabled = !ok; $('#cCta').innerHTML = !a ? 'أدخل مبلغ التحميل' : MO.k === 0 && !(MO.f.note || '').trim() ? 'اكتب سبب الغرامة' : `${ic('plus', 'i i-sm')}تحميل ${money(a)} ₪ على الحساب`;
    MO.a = a; MO.dirty = a > 0 && !MO.autoFilled || !!MO.f.note;
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k === 'unlock') { if (e.target.checked) { e.target.checked = false; return sheet(`<div class="cf"><div class="ic warn">${ic('lock-open', 'i i-lg')}</div></div><h3>تعديل مبلغ التحميل؟</h3><p>المبلغ مأخوذ من الحد الأدنى المحدد لهذا المشترك. هل تريد تعديله لهذه الحركة؟</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">إلغاء</button><button class="btn btn-primary" data-act="ch-unlock">نعم، عدّل</button></div>`); } MO.f.unlock = false; $('#camt').value = money(minC); } else if (k) MO.f[k] = e.target.value; if (e.target.id === 'camt') MO.autoFilled = false; upd(); });
  el.addEventListener('click', (e) => {
    const t = e.target.closest('[data-act="ch-type"]'); if (t) return setType(+t.dataset.k);
    const q = e.target.closest('[data-act="ch-quick"]'); if (q) { $('#camt').value = q.dataset.v; MO.autoFilled = false; return upd(); }
    if (e.target.closest('[data-act="ch-unlock"]')) { MO.f.unlock = true; $('[data-f="unlock"]').checked = true; MO.sheet = false; $('.sheet-host', el).innerHTML = ''; upd(); return $('#camt').focus(); }
  });
  $('#cCta').addEventListener('click', () => sheet(`<h3>تأكيد إضافة التحميل؟</h3><div class="sumbox"><div class="kv"><span>المشترك</span><b style="font-family:var(--f-body)">${s.n}</b></div><div class="kv"><span>النوع</span><b style="font-family:var(--f-body)">${CHARGE_TYPES[MO.k][1]}</b></div><div class="kv"><span>المبلغ</span><b>₪ ${money(MO.a)}</b></div><div class="kv"><span>الرصيد بعده</span><b>₪ ${money(s.bal + MO.a)}</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="charge" data-act="done" data-msg="تمت إضافة التحميل" data-amt="₪ ${money(MO.a)}">تأكيد</button></div>`));
  setType(0); $('#camt').focus();
}

/* ── 5. خصم — DiscountModal.jsx ── */
const DISC_KINDS = [['circle-dot', 'لمرة واحدة', 'مبلغ بالشيكل يُخصم الآن من الرصيد المستحق'], ['repeat', 'خصم القراءات الأسبوعية', 'من كل قراءة أسبوعية حتى تُوقفه']];
const DISC_METHODS = [['percent', 'نسبة', 'من قيمة كل قراءة'], ['zap', 'كيلوات', 'كيلوات مجانية كل أسبوع'], ['tag', 'شيكل من سعر الكيلو', 'يُنزل من سعر الكيلو']];
function openDiscount(who) {
  const s = subBy(who), price = 1.5, kwh = 139, bill = kwh * price;
  const el = sheetModal('', 'percent', 'إضافة خصم', 'لمرة واحدة، أو على كل قراءة أسبوعية حتى تُوقفه', null, `
    <div id="dMove"></div>
    <div class="ff w6"><label>نوع الخصم <span class="req">*</span></label><div class="rcs" role="radiogroup">${DISC_KINDS.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="dc-kind" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6" id="dMethodF" hidden><label>طريقة الخصم <span class="req">*</span></label><div class="rcs rcs-3" role="radiogroup">${DISC_METHODS.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="dc-method" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6"><label id="dValL"></label><div class="mini-amt"><span id="dUnit">₪</span><input id="dval" inputmode="decimal" placeholder="0" aria-label="قيمة الخصم"></div><div class="quick" id="dQuick" style="justify-content:flex-start;margin-top:4px"></div><span class="hint" id="dHint"></span></div>
    <div class="ff w6" id="dSegF" hidden><label>تصنيف الزبون <span class="opt">اختياري</span></label><div class="fc">${ic('tags', 'i i-sm')}<input data-f="seg" placeholder="مثال: موظفو أبو زايد"></div><div class="chips-pick" style="margin-top:4px">${['موظفو أبو زايد', 'مؤسسات', 'أسر محتاجة'].map((c) => `<button type="button" aria-pressed="false" data-act="dc-seg" data-v="${c}">${c}</button>`).join('')}</div></div>
    <div class="ff w6"><label>ملاحظات <span class="opt">اختياري</span></label><div class="fc ta"><textarea data-f="note" placeholder="مثال: خصم بموافقة المدير"></textarea></div></div>`, 'dCta', 'discount');
  MO = { el, id: 'discount', s, kind: 0, m: 0, f: {}, discard: 'تجاهل الخصم؟' };
  const upd = () => {
    const weekly = MO.kind === 1, v = num($('#dval').value);
    $('#dMethodF').hidden = !weekly; $('#dSegF').hidden = !weekly;
    const mode = weekly ? ['pct', 'kw', 'ils'][MO.m] : 'once';
    $('#dValL').innerHTML = { once: 'المبلغ (بالشيكل)', pct: 'النسبة من كل قراءة (من 1 إلى 100)', kw: `الكيلوات المجانية كل أسبوع (الكيلو بـ ${price.toFixed(2)} ₪)`, ils: `الخصم من سعر الكيلو (سعر الكيلو ${price.toFixed(2)} ₪)` }[mode] + ' <span class="req">*</span>';
    $('#dUnit').textContent = { once: '₪', pct: '%', kw: 'ك.و', ils: '₪' }[mode];
    const quick = { once: [10, 20, 50], pct: [5, 10, 20], kw: [5, 10, 20], ils: [0.5, 1] }[mode];
    $('#dQuick').innerHTML = quick.map((q) => `<button type="button" class="qchip" data-act="dc-quick" data-v="${q}">${q}</button>`).join('') + (mode === 'once' && s.bal > 0 ? `<button type="button" class="qchip" data-act="dc-quick" data-v="${s.bal}">كل ما عليه</button>` : '');
    const off = mode === 'once' ? v : Math.min(bill, mode === 'pct' ? bill * v / 100 : mode === 'kw' ? v * price : v * kwh);
    const bad = mode === 'pct' && (v < 1 || v > 100) && v !== 0;
    $('#dHint').className = 'hint ' + (bad ? 'bad' : ''); $('#dHint').textContent = bad ? 'النسبة من 1 إلى 100' : weekly && v ? `يوفّر ₪ ${money(off)} في الأسبوع، قرابة ₪ ${money(off * 4.3)} في الشهر` : '';
    $('#dMove').innerHTML = weekly
      ? `<div class="move"><div class="move-who"><span class="av2">${s.n[0]}</span><div><b>${s.n}</b><small>حساب ${s.a}، ${s.box}</small></div><span class="chip2x" data-tone="discount">كل أسبوع</span></div><div class="move-eq"><div><small>فاتورة الأسبوع المعتادة</small><b class="n">₪ ${money(bill)}</b><span>${kwh} كيلو × ${price.toFixed(2)} ₪</span></div><span class="op">−</span><div><small>الخصم</small><b class="n">₪ ${money(off)}</b><span>${['نسبة', 'كيلوات', 'شيكل من سعر الكيلو'][MO.m]}</span></div><span class="op">=</span><div><small>يدفع عن آخر قراءة</small><b class="n">₪ ${money(bill - off)}</b></div></div></div>`
      : moveCard(s, 'مرة واحدة', 'discount', '−', 'dAfter', 'dMid', 'الخصم');
    if (!weekly) { $('#dMid').textContent = `₪ ${money(v)}`; const after = s.bal - v; $('#dAfter').textContent = `₪ ${money(Math.abs(after))}`; $('#dAfter-d').textContent = after > 0 ? 'عليه' : 'له'; }
    $('#dCta').disabled = !v || bad; $('#dCta').innerHTML = !v ? 'أدخل قيمة الخصم' : weekly ? `${ic('repeat', 'i i-sm')}تفعيل خصم القراءات الأسبوعية` : `${ic('check', 'i i-sm')}خصم ${money(v)} ₪`;
    MO.off = off; MO.v = v; MO.dirty = v > 0;
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { if (e.target.dataset.f) MO.f[e.target.dataset.f] = e.target.value; upd(); });
  el.addEventListener('click', (e) => {
    const k = e.target.closest('[data-act="dc-kind"]'); if (k) { MO.kind = +k.dataset.k; $$('[data-act="dc-kind"]', el).forEach((b) => b.setAttribute('aria-checked', String(b === k))); $('#dval').value = ''; return upd(); }
    const m = e.target.closest('[data-act="dc-method"]'); if (m) { MO.m = +m.dataset.k; $$('[data-act="dc-method"]', el).forEach((b) => b.setAttribute('aria-checked', String(b === m))); $('#dval').value = ''; return upd(); }
    const q = e.target.closest('[data-act="dc-quick"]'); if (q) { $('#dval').value = q.dataset.v; return upd(); }
    const g = e.target.closest('[data-act="dc-seg"]'); if (g) { const on = g.getAttribute('aria-pressed') !== 'true'; $$('[data-act="dc-seg"]', el).forEach((b) => b.setAttribute('aria-pressed', 'false')); g.setAttribute('aria-pressed', String(on)); $('[data-f="seg"]').value = on ? g.dataset.v : ''; MO.f.seg = $('[data-f="seg"]').value; }
  });
  $('#dCta').addEventListener('click', () => sheet(`<h3>تأكيد إضافة الخصم؟</h3><div class="sumbox"><div class="kv"><span>النوع</span><b style="font-family:var(--f-body)">${DISC_KINDS[MO.kind][1]}</b></div>${MO.kind ? `<div class="kv"><span>الطريقة</span><b style="font-family:var(--f-body)">${DISC_METHODS[MO.m][1]}</b></div>` : ''}<div class="kv"><span>القيمة</span><b>${MO.v} ${$('#dUnit').textContent}</b></div><div class="kv"><span>${MO.kind ? 'يوفّر في الأسبوع' : 'يُخصم من الرصيد'}</span><b>− ₪ ${money(MO.off)}</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="discount" data-act="done" data-msg="تمت إضافة الخصم" data-amt="− ₪ ${money(MO.off)}">تأكيد</button></div>`));
  upd(); $('#dval').focus();
}

/* ── 6. دفعة مقسّمة — SplitPaymentModal.jsx: one window, the transfer on top and its allocation below ── */
const COLORS = ['oklch(0.62 0.19 254)', 'oklch(0.7 0.17 152)', 'oklch(0.75 0.15 72)', 'oklch(0.62 0.2 300)', 'oklch(0.65 0.2 25)'];
function openSplit() {
  const el = mount('md sheet-modal split2', `<div class="mh"><span class="tile-ic" data-tone="split" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)">${ic('split', 'i i-lg')}</span><div><h2>دفعة مقسّمة على عدة مشتركين</h2><p>حوالة واحدة توزَّع على مشتركين، ولو بهويات مختلفة</p></div><div class="end">${closeBtn}</div></div>
    <div class="mbody2">
      <div class="ff w6"><label>المبلغ المحوَّل (الإجمالي) <span class="req">*</span></label><div class="mini-amt" style="height:76px"><span>₪</span><input data-f="total" id="spTotal" inputmode="decimal" placeholder="0.00" style="font-size:34px" aria-label="المبلغ المحوَّل"></div></div>
      <section class="xcard"><h4>بيانات التحويل</h4>
        <div class="ff w6"><label>البنك المستلم <span class="req">*</span></label><div class="banks">${BANKS.map(([n, c, col]) => `<button class="bank" type="button" role="radio" aria-checked="false" data-act="sp2-bank" data-bank="${n}"><span class="lg" style="background:${col}">${c}</span>${n}</button>`).join('')}</div></div>
        <div class="fg"><div class="ff"><label>البنك المرسل</label>${pickBtn('sbank', '', ['غير محدد', ...BANKS.map((b) => b[0])], { icon: 'landmark', ph: 'اختر البنك أو المحفظة المحوّل منها' })}</div>
          <div class="ff"><label>تاريخ وصول الحوالة إلى البنك <span class="opt">اختياري</span></label>${dateBtn('date', '')}</div>
          <div class="ff"><label>اسم المحوِّل <span class="req">*</span></label><div class="fc">${ic('user', 'i i-sm')}<input data-f="sender" placeholder="اسم صاحب الحساب الذي حُوّل منه المبلغ"></div></div>
          <div class="ff"><label>الرقم المرجعي <span class="req">*</span></label><div class="fc" id="spRefBox">${ic('hash', 'i i-sm')}<input data-f="ref" placeholder="مثال: TRX-48213" data-ltr></div><span class="hint" id="spRefHint">من إشعار الحوالة</span></div></div>
        <label class="ack" id="spDup" hidden><input type="checkbox" class="cb" data-f="dupOk"><span>أؤكد أن هذا الرقم المرجعي مسجَّل على دفعة أخرى وأريد المتابعة</span></label>
        <span class="hint">اتركه فارغًا إن لم تتأكد من تاريخ الوصول. تُسجّل الحركة بتاريخ تسجيلها في النظام.</span></section>
      <section class="xcard"><div style="display:flex;align-items:center;gap:8px"><h4 style="margin:0">توزيع المبلغ على المشتركين</h4><button type="button" class="btn btn-secondary btn-sm" data-act="sp2-all" style="margin-inline-start:auto">${ic('users', 'i i-sm')}كل اشتراكات هذه الهوية</button></div>
        <div><div class="alloc-bar" id="aBar"></div><div class="alloc-sum" id="aSum"></div></div>
        <div id="aRows"></div>
        <div class="ff w6"><label>إضافة مشترك إلى هذه الدفعة</label>${pickBtn('spAdd', '', SUBS.map((x) => x.n), { icon: 'user-plus', ph: 'ابحث بالاسم أو الحساب أو الجوال' })}</div>
        <label class="ack" id="spOver" hidden><input type="checkbox" class="cb" data-f="overOk"><span>أؤكد أن المبالغ صحيحة</span></label>
        <div class="ff w6"><label>ملاحظة <span class="opt">تظهر في كشف كل مشترك</span></label><div class="fc">${ic('sticky-note', 'i i-sm')}<input data-f="note" placeholder="أي تفصيل يُحفظ مع الدفعة"></div></div></section>
    </div><div class="mfoot"><span class="k" id="spK"></span><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-tone solid" data-tone="split" id="spCta" disabled></button></div></div>`);
  MO = { el, id: 'split', f: {}, bank: null, rows: [], discard: 'تجاهل التغييرات؟' };
  const rowsHTML = () => { $('#aRows').innerHTML = MO.rows.map((r, i) => `<div class="arow"><span class="sw3" style="background:${COLORS[i % 5]}"></span><span><b>${r.n}</b><small>حساب ${r.a}، عليه ₪ ${money(r.owe)}</small></span><div class="mini-amt"><span>₪</span><input data-row="${i}" value="${r.v}" inputmode="decimal" aria-label="مبلغ ${r.n}"></div><button class="btn btn-ghost btn-icon btn-sm" data-act="sp2-del" data-i="${i}" aria-label="إزالة ${r.n}">${ic('x', 'i i-sm')}</button></div>`).join('') || '<div class="hint" style="padding:8px 0">لم تُضف أي مشترك بعد.</div>'; };
  const upd = () => {
    const total = num(MO.f.total), alloc = MO.rows.reduce((t, r) => t + num(r.v), 0), left = Math.round((total - alloc) * 100) / 100;
    $('#aBar').innerHTML = MO.rows.map((r, i) => `<i style="width:${total ? Math.min(100, num(r.v) / total * 100) : 0}%;background:${COLORS[i % 5]}"></i>`).join('');
    const msg = !total ? 'أدخل المبلغ المحوَّل ثم وزّعه على المشتركين' : MO.rows.length < 2 ? 'أضف مشتركَين على الأقل' : MO.rows.some((r) => !num(r.v)) ? 'أدخل مبلغ كل مشترك' : left === 0 ? '✓ وُزّع المبلغ كاملًا' : left > 0 ? `بقي ${money(left)} ₪ لم يُوزَّع` : `الموزَّع يزيد ${money(-left)} ₪ على المحوَّل`;
    const tone = msg.startsWith('✓') ? 'ok' : left < 0 ? 'over' : 'left';
    $('#aSum').innerHTML = `<span class="n" style="font-weight:700">${money(alloc)} من ${money(total)} ₪</span><span class="pill ${tone}">${msg}</span>`;
    const ref = (MO.f.ref || '').trim(), used = /^TRX-48213$/i.test(ref);
    $('#spRefHint').className = 'hint ' + (ref ? (used ? 'warn' : 'ok') : ''); $('#spRefHint').textContent = ref ? (used ? 'الرقم المرجعي مكرر: مسجَّل مسبقًا في السند V-08790، سعاد ناصر. يمكنك المتابعة بعد التأكيد.' : '✓ الرقم المرجعي متاح.') : 'من إشعار الحوالة';
    $('#spDup').hidden = !used; $('#spRefBox').classList.toggle('warnb', used);
    const over = MO.rows.some((r) => num(r.v) > r.owe); $('#spOver').hidden = !over;
    const ok = total > 0 && MO.bank && (MO.f.sender || '').trim() && ref && (!used || MO.f.dupOk) && MO.rows.length >= 2 && left === 0 && (!over || MO.f.overOk);
    $('#spCta').disabled = !ok; $('#spCta').innerHTML = `${ic('check', 'i i-sm')}${MO.rows.length >= 2 ? `تسجيل الدفعة على ${MO.rows.length} مشتركين` : 'تسجيل الدفعة'}`;
    $('#spK').textContent = MO.rows.length ? `${MO.rows.length} مشتركين` : '';
    MO.dirty = total > 0 || MO.rows.length > 0;
  };
  MO.upd = upd;
  const add = (s) => { if (!MO.rows.some((r) => r.a === s.a)) MO.rows.push({ n: s.n, a: s.a, owe: s.bal, v: '' }); rowsHTML(); upd(); };
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) MO.f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; if (e.target.dataset.row) MO.rows[+e.target.dataset.row].v = e.target.value; upd(); });
  el.addEventListener('pick', (e) => { if (e.detail.key === 'spAdd') { add(subBy(e.detail.value)); const pv = $('[data-pick="spAdd"] .pkv'); pv.textContent = 'ابحث بالاسم أو الحساب أو الجوال'; pv.classList.add('ph'); } else MO.f[e.detail.key] = e.detail.value; });
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act="sp2-bank"]'); if (b) { MO.bank = b.dataset.bank; $$('[data-act="sp2-bank"]', el).forEach((x) => x.setAttribute('aria-checked', String(x === b))); return upd(); }
    if (e.target.closest('[data-act="sp2-all"]')) { [['منصور للتجارة، المخزن', '202600149', 520], ['منصور للتجارة، المكتب', '202600150', 410]].forEach(([n, a, o]) => add({ n, a, bal: o })); return; }
    const d = e.target.closest('[data-act="sp2-del"]'); if (d) { MO.rows.splice(+d.dataset.i, 1); rowsHTML(); return upd(); }
  });
  $('#spCta').addEventListener('click', () => sheet(`<h3>تسجيل الدفعة المقسّمة؟</h3><div class="sumbox"><div class="kv"><span>الرقم المرجعي</span><b>${esc2(MO.f.ref)}</b></div><div class="kv"><span>المبلغ</span><b>₪ ${money(num(MO.f.total))}</b></div><div class="kv"><span>على</span><b style="font-family:var(--f-body)">${MO.rows.length} مشتركين</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="split" data-act="done" data-msg="تم تسجيل الدفعة المقسّمة" data-amt="₪ ${money(num(MO.f.total))}">تأكيد</button></div>`));
  add(SUBS[0]); $('#spTotal').focus();
}

/* ── Events ── */
document.addEventListener('click', (e) => {
  const opener = e.target.closest('[data-modal]');
  if (opener && !e.target.closest('.mback')) {
    e.preventDefault(); e.stopPropagation();
    const m = opener.dataset.modal, who = opener.dataset.who;
    ({ quickPay: openQuickPay, payment: () => openPayment(who), subscriber: openSubscriber, charge: () => openCharge(who), discount: () => openDiscount(who), split: openSplit }[m] || (() => {}))();
    return;
  }
  if (!MO) return;
  const a = e.target.closest('[data-act]'); if (!a || !MO.el.contains(a)) { if (!e.target.closest('.cur')) $('#cur')?.classList.remove('open'); return; }
  const act = a.dataset.act;
  if (act === 'close') return a.closest('.sheet') ? closeModal() : tryClose();
  if (act === 'sheet-back') { MO.sheet = false; $('.sheet-host', MO.el).innerHTML = ''; return; }
  if (act === 'done') return success(a.dataset.msg, a.dataset.amt, `${MO.s ? MO.s.n + '، ' : ''}سُجّل باسم محمد الأحمد، الآن`, `<button class="btn btn-primary" data-act="close">تم</button>`);
  if (act === 'pick') return openPayment(a.dataset.who);
  if (act === 'cur-toggle') return $('#cur').classList.toggle('open');
  if (act === 'cur') { MO.cur = a.dataset.cur; $('#cur').classList.remove('open'); return MO.upd(); }
  if (act === 'fill') { MO.cur = 'ILS'; $('#amt').value = money(MO.s.bal); return MO.upd(); }
  if (act === 'method') { MO.method = a.dataset.m; $$('.method', MO.el).forEach((b) => b.setAttribute('aria-checked', String(b === a))); $('#xfer').classList.toggle('on', MO.method === 'transfer'); return MO.upd(); }
  if (act === 'bank') { MO.bank = a.dataset.bank; $$('[data-act="bank"]', MO.el).forEach((b) => b.setAttribute('aria-checked', String(b === a))); return MO.upd(); }
  if (act === 'extra-hide') { $('#x-' + a.dataset.x).classList.remove('on'); $(`[data-act="extra"][data-x="${a.dataset.x}"]`, MO.el).classList.remove('on'); return; }
  if (act === 'extra') { a.classList.add('on'); $('#x-' + a.dataset.x).classList.add('on'); setTimeout(() => $(`#x-${a.dataset.x} input, #x-${a.dataset.x} textarea`)?.focus(), 200); return; }
  if (act === 'pay-review') {
    const amt = num($('#amt').value), [sym, , rate] = CUR[MO.cur], after = MO.s.bal - amt * rate;
    return sheet(`<h3>تأكيد تسجيل الدفعة؟</h3><p>راجع التفاصيل قبل التسجيل. يُطبع الوصل بعد التأكيد.</p><div class="sumbox"><div class="kv"><span>المشترك</span><b style="font-family:var(--f-body)">${MO.s.n}</b></div><div class="kv"><span>المبلغ</span><b>${sym} ${money(amt)}</b></div><div class="kv"><span>الطريقة</span><b style="font-family:var(--f-body)">${MO.method === 'cash' ? 'نقد' : 'تحويل، ' + MO.bank}</b></div>${MO.f.ref ? `<div class="kv"><span>رقم المرجع</span><b>${esc2(MO.f.ref)}</b></div>` : ''}<div class="kv"><span>الرصيد بعدها</span><b>${after <= 0 ? 'مسدّد' : '₪ ' + money(after)}</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-primary" data-act="pay-done" data-amt="${sym} ${money(amt)}">${ic('check', 'i i-sm')}تأكيد وتسجيل</button></div>`);
  }
  if (act === 'pay-done') return success('تم تسجيل الدفعة', a.dataset.amt, `${MO.s.n}، الوصل V-08813، صندوق C-418`, `<button class="btn btn-primary" data-act="close">${ic('printer', 'i i-sm')}طباعة الوصل</button><button class="btn btn-secondary" data-act="again">${ic('plus', 'i i-sm')}دفعة لمشترك آخر</button><button class="btn btn-ghost" data-act="close">إغلاق</button>`);
  if (act === 'again') return openQuickPay();
  if (act === 'ob-pick') { MO.f[a.dataset.k] = a.dataset.v; $$(`[data-act="ob-pick"][data-k="${a.dataset.k}"]`, MO.el).forEach((b) => b.setAttribute(b.getAttribute('role') === 'radio' ? 'aria-checked' : 'aria-pressed', String(b === a))); return obSync(); }
  if (act === 'ob-go') { const b = obScroller(); b.scrollTo({ top: b.scrollTop + $('#obs-' + a.dataset.i).getBoundingClientRect().top - b.getBoundingClientRect().top - 8 }); return; }
  if (act === 'ob-save') return obSave();
  if (act === 'again-sub') return openSubscriber();
}, true);
document.addEventListener('input', (e) => {
  if (!MO) return;
  if (MO.id === 'subscriber' && e.target.dataset.f) { const k = e.target.dataset.f; MO.f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; obSync(); if (e.target.type === 'checkbox' && e.target.checked) $(`[data-f="${k === 'minOn' ? 'min' : 'fee'}"]`)?.focus(); }
});
document.addEventListener('pick', (e) => { if (!MO?.f) return; MO.f[e.detail.key] = e.detail.value; if (MO.id === 'subscriber') obSync(); });
document.addEventListener('focusout', (e) => { const k = e.target.dataset?.f; if (MO?.id === 'subscriber' && ['name', 'nid', 'phone'].includes(k) && MO.f[k]) { MO.touched[k] = true; obSync(); } });
document.addEventListener('keydown', (e) => {
  if (!MO) return;
  if (e.key === 'Escape') { e.stopPropagation(); tryClose(); }
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && MO.id === 'subscriber' && !MO.sheet) { e.preventDefault(); obSave(); }
}, true);
