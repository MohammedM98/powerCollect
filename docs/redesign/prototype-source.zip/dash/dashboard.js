function dashboard(p) {
  const wait = [['check-check', 'بانتظار الاعتماد', 'في أسبوع القراءة الأخير', 12, 'warn', 'meter-readings'], ['gauge', 'عدادات لم تُقرأ', 'في أسبوع القراءة الأخير', 344, 'bad', 'meter-readings'], ['wallet', 'صناديق مفتوحة', 'فيها حركات لم تُغلق', 7, 'warn', 'cash-boxes'], ['power', 'قطع متأخر', 'في قوائم القطع ولم يُنفّذ', 0, 'ok', 'disconnection-lists'], ['calendar', 'قطع خلال 7 أيام', '2 قائمة مفتوحة', 23, 'warn', 'disconnection-lists']];
  const debtors = [['سعاد ناصر', 'S-202600118', '1,940.00', 137], ['خالد منصور', 'S-202600148', '640.00', 64], ['محمود داود', 'S-202600204', '214.50', 14], ['هبة يوسف', 'S-202600367', '120.00', 12]];
  const branches = [['الفرع الشمالي', '72,400', 100], ['الفرع الجنوبي', '41,300', 57], ['فرع الوسط', '38,900', 54], ['الفرع الشرقي', '21,600', 30], ['الفرع الغربي', '12,220', 17]];
  const breakers = [['6', 312, 13], ['10', 1204, 52], ['16', 540, 23], ['20', 188, 8], ['32', 62, 3], ['63', 12, 1]];
  const pays = [['خالد منصور', '202600148', 'الفرع الشمالي', 'أحمد سالم', 1, '', '320.00', 'قبل دقيقتين', 0], ['نادية عيسى', '202600092', 'الفرع الجنوبي', 'يوسف حمدان', 0, 'بنك فلسطين', '1,150.00', 'قبل 9 دقائق', 0], ['عمر الشريف', '202600311', 'الفرع الشمالي', 'رامي خليل', 1, '', '185.00', 'قبل 24 دقيقة', 0], ['محمود داود', '202600204', 'فرع الوسط', 'أحمد سالم', 0, 'بنك القدس', '214.50', 'قبل ساعة', 0], ['ليلى حسن', '202600057', 'فرع الوسط', 'أحمد سالم', 1, '', '90.00', 'قبل 3 ساعات', 1]];
  return `
  <div class="ph" data-part="رأس الصفحة">
    <div class="crumb">الرئيسية</div>
    <div class="ph-row">
      <div><h1>مساء الخير، محمد</h1><p>كل الفروع، 5 فروع في 3 محافظات. الاثنين 16/11/2026</p></div>
      <div class="ph-filters" data-part="النطاق والفترة">${pickBtn('fGov', 'كل المحافظات', ['كل المحافظات', 'غزة', 'خانيونس', 'رفح'], { icon: 'map', cls: 'select' })}${pickBtn('fBranch', 'كل الفروع', ['كل الفروع', 'الفرع الشمالي', 'الفرع الجنوبي', 'فرع الوسط', 'الفرع الشرقي', 'الفرع الغربي'], { icon: 'building-2', cls: 'select' })}<div class="seg"><button aria-pressed="false">7 أيام</button><button aria-pressed="true">30 يومًا</button><button aria-pressed="false">90 يومًا</button></div></div>
    </div>
    <div class="pills" data-part="إجراءات سريعة">
      <button class="btn btn-primary" data-modal="quickPay">${ic('hand-coins', 'i i-sm')}تسجيل دفعة</button>
      <button class="btn btn-secondary" data-modal="subscriber">${ic('user-plus', 'i i-sm')}مشترك جديد</button>
      <button class="btn btn-secondary" data-go="meter-readings">${ic('gauge', 'i i-sm')}القراءات</button>
      <button class="btn btn-secondary" data-go="messages">${ic('send', 'i i-sm')}رسالة جديدة</button>
      <button class="btn btn-secondary" data-go="reports">${ic('chart-no-axes-combined', 'i i-sm')}التقارير</button>
      <button class="btn btn-secondary" data-go="meter-boxes">${ic('network', 'i i-sm')}الطبلونات</button>
      <button class="btn btn-secondary">${ic('building-2', 'i i-sm')}فرع جديد</button>
    </div>
  </div>

  <div class="grid2">
    <section class="card surf" data-part="التحصيل">
      <div class="card-h"><h3>المحصّل في آخر 30 يومًا</h3><span class="delta up">↗ 12.4%</span><div class="end"><div class="seg"><button aria-pressed="true" aria-label="رسم">${ic('chart-spline', 'i i-sm')}</button><button aria-pressed="false" aria-label="جدول">${ic('list', 'i i-sm')}</button></div></div></div>
      <div class="balance n">₪ 186,420.00</div>
      <div class="muted" style="margin-top:6px;font-size:13px">الفترة السابقة <b class="n" style="color:var(--foreground)">₪ 165,880.00</b></div>
      <div class="minis">
        <div class="mini"><small>المحصّل اليوم</small><b>₪ 8,240</b><span>146 دفعة حتى الآن</span></div>
        <div class="mini"><small>دفعات الفترة</small><b>3,412</b><span>نقدي ₪ 132,360، حوالات ₪ 54,060</span></div>
        <div class="mini"><small>طرق الدفع</small><div class="split" style="margin-top:8px"><i style="width:71%;background:var(--accent)"></i><i style="width:29%;background:var(--warning)"></i></div><span>نقدي 71%، حوالات 29%</span></div>
      </div>
      <svg class="chart" id="chart" viewBox="0 0 700 220" preserveAspectRatio="none" aria-label="التحصيل اليومي"></svg>
    </section>
    <section class="card surf" data-part="بانتظارك">
      <div class="card-h"><div><h3>بانتظارك</h3><p class="muted" style="margin:2px 0 0;font-size:12.5px">ما يحتاج متابعة اليوم</p></div></div>
      ${wait.map(([i, t, s, n, tone, go]) => `<a class="wait" href="#${go}" data-go="${go}"><span class="ic">${ic(i)}</span><span class="t"><b>${t}</b><small>${s}</small></span><span class="badge ${n ? tone : 'ok'}">${n.toLocaleString('en')}</span>${ic('chevron-left', 'i i-sm muted')}</a>`).join('')}
    </section>
  </div>

  <div class="tiles" data-part="بطاقات الأرقام">
    <a class="card surf tile hero" href="#subscriptions" data-go="subscriptions"><span class="l"><span class="ic">${ic('users', 'i i-sm')}</span>المشتركون النشطون</span><span class="v">2,318</span><span class="h">من 2,460، 38 جديد في آخر 30 يومًا</span><span class="split"><i style="width:94%;background:var(--success)"></i><i style="width:1%;background:var(--warning)"></i><i style="width:5%;background:var(--muted)"></i></span></a>
    <a class="card surf tile" href="#meter-boxes" data-go="meter-boxes"><span class="l"><span class="ic">${ic('network', 'i i-sm')}</span>الطبلونات</span><span class="v">62</span><span class="h">قُرئ 86% من العدادات هذا الأسبوع</span></a>
    <div class="card surf tile"><span class="l"><span class="ic">${ic('zap', 'i i-sm')}</span>الأمبير المتعاقد عليه</span><span class="v">28,614 <small>أمبير</small></span><span class="h">الأكثر: قاطع 10 أمبير (52%)</span></div>
    <a class="card surf tile" href="#receivables" data-go="receivables"><span class="l"><span class="ic">${ic('clock', 'i i-sm')}</span>الديون المستحقة</span><span class="v">51,580 <small>₪</small></span><span class="h">412 مدين، أكثر من 90 يومًا 14%</span></a>
  </div>

  <div class="grid3">
    <section class="card surf" data-part="أكبر المدينين"><div class="card-h"><div><h3>أكبر المدينين</h3><p class="muted n" style="margin:2px 0 0;font-size:12.5px">412 مدين، ₪ 51,580</p></div><div class="end"><button class="btn btn-secondary btn-sm" data-go="receivables">الكل</button></div></div>
      ${debtors.map(([n, a, b, d]) => `<div class="list-row"><span class="av2">${n[0]}</span><span class="t"><b>${n}</b><small>₪ ${b}، منذ ${d} يومًا</small></span><button class="btn btn-secondary btn-sm" data-modal="payment" data-who="${n}">كشف</button></div>`).join('')}</section>
    <section class="card surf" data-part="قراءات الأسبوع"><div class="card-h"><div><h3>قراءات الأسبوع</h3><p class="muted" style="margin:2px 0 0;font-size:12.5px">بدأ الجمعة 06/11/2026</p></div><div class="end"><button class="btn btn-secondary btn-sm" data-go="meter-readings">فتح</button></div></div>
      <div class="ring"><svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--surface-3)" stroke-width="3.4"/><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--accent)" stroke-width="3.4" stroke-linecap="round" stroke-dasharray="83.8 97.4"/></svg><div class="c"><div><b>86%</b><small>معتمدة</small></div></div></div>
      <div class="kv"><span>معتمدة</span><b>2,104</b></div><div class="kv"><span>بانتظار الاعتماد</span><b>12</b></div><div class="kv"><span>لم تُقرأ</span><b style="color:color-mix(in oklab, var(--danger) 80%, var(--foreground))">344</b></div></section>
    <section class="card surf" data-part="التحصيل حسب الفرع"><div class="card-h"><div><h3>التحصيل حسب الفرع</h3><p class="muted" style="margin:2px 0 0;font-size:12.5px">آخر 30 يومًا</p></div></div>
      ${branches.map(([n, a, w], i) => `<div class="rank"><span class="num">${i + 1}</span><b>${n}</b><span class="amt">₪ ${a}</span><span class="bar"><i style="width:${w}%"></i></span></div>`).join('')}
      <div class="kv" style="margin-top:6px"><span>صناديق مفتوحة</span><b>7</b></div><div class="kv"><span>دفعات اليوم</span><b>146</b></div><div class="kv"><span>الأعلى</span><b style="font-family:inherit">الفرع الشمالي</b></div></section>
  </div>

  <div class="grid2">
    <section class="card surf" data-part="المشتركون حسب القاطع"><div class="card-h"><h3>المشتركون حسب القاطع</h3></div>
      ${breakers.map(([a, n, s]) => `<div style="padding:8px 0"><div class="kv" style="padding:0 0 8px"><b style="font-family:inherit">${a} أمبير</b><span class="n">${n.toLocaleString('en')}، ${s}%</span></div><div class="bar"><i style="width:${s / 52 * 100}%"></i></div></div>`).join('')}</section>
    <section class="card surf" data-part="طرق الدفع"><div class="card-h"><div><h3>طرق الدفع</h3><p class="muted n" style="margin:2px 0 0;font-size:12.5px">آخر 30 يومًا، ₪ 186,420</p></div></div>
      <div class="split" style="height:14px"><i style="width:71%;background:var(--accent)"></i><i style="width:29%;background:var(--warning)"></i></div>
      <div class="legend"><div><i style="background:var(--accent)"></i><span><b>₪ 132,360</b><small>نقدي، 71%</small></span></div><div><i style="background:var(--warning)"></i><span><b>₪ 54,060</b><small>حوالات، 29%</small></span></div></div></section>
  </div>

  <section class="card surf" data-part="أحدث الدفعات">
    <div class="card-h"><div><h3>أحدث الدفعات</h3><p class="muted" style="margin:2px 0 0;font-size:12.5px">الدفعات المسجلة في آخر 30 يومًا، الأحدث أولًا. المجموع لا يشمل الملغاة.</p></div></div>
    <div class="toolbar"><div class="field" style="flex:1 1 280px">${ic('search', 'i i-sm')}<span>اسم المشترك أو رقم الحساب</span></div><div class="seg"><button aria-pressed="true">الكل</button><button aria-pressed="false">نقدي</button><button aria-pressed="false">حوالات</button></div></div>
    <div class="tblw"><table class="dt"><thead><tr><th>المشترك</th><th>الحساب</th><th>الفرع</th><th>سجّلها</th><th>الطريقة</th><th class="amt">المبلغ</th><th>الوقت</th><th>الحالة</th><th>الوصل</th></tr></thead><tbody>
      ${pays.map(([n, a, br, by, cash, bank, amt, t, x]) => `<tr data-modal="payment" data-who="${n}"><td><span class="who"><span class="av2">${n[0]}</span><b>${n}</b></span></td><td class="n muted">${a}</td><td>${br}</td><td>${by}</td><td><span class="chip">${ic(cash ? 'banknote' : 'landmark', 'i i-sm')}${cash ? 'نقدي' : 'حوالة، ' + bank}</span></td><td class="amt ${x ? 'strike' : ''}">₪ ${amt}</td><td class="muted">${t}</td><td><span class="chip ${x ? '' : 'success'}">${x ? 'ملغاة' : 'سارية'}</span></td><td><button class="btn btn-ghost btn-icon btn-sm" aria-label="طباعة الوصل">${ic('printer', 'i i-sm')}</button></td></tr>`).join('')}
    </tbody></table></div>
    <div class="tfoot"><span class="muted" style="font-size:13px">مجموع الدفعات السارية <b class="n" style="color:var(--foreground)">₪ 186,420.00</b></span><div class="pager"><button aria-label="السابق">›</button><button class="on">1</button><button>2</button><button>3</button><button aria-label="التالي">‹</button></div></div>
  </section>`;
}
