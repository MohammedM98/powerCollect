
/* ═══════════ Bespoke views (pages designed by hand on top of the kit) ═══════════ */
const VIEWS = {};

/* ── مكتبة المكونات: every building block, then the full inventory of windows ── */
VIEWS.kit = (p) => {
  const sec = (t, sub, body) => `<section class="card surf kit-sec"><div class="card-h"><div><h3>${t}</h3>${sub ? `<p class="muted" style="margin:2px 0 0;font-size:13px">${sub}</p>` : ''}</div></div>${body}</section>`;
  const tones = [['pay', 'تسجيل دفعة'], ['charge', 'تحميل حركة'], ['discount', 'خصم'], ['clearing', 'مقاصة'], ['split', 'دفعة مقسّمة'], ['reading', 'قراءة']];
  const forms = Object.keys(FORMS).map((id) => ({ id, f: SP.forms[id], inv: FORMS[id] }));
  const unlisted = Object.keys(SP.forms).filter((id) => !FORMS[id]);
  const areas = {};
  PAGES.forEach((pg) => (pg[7] || []).forEach((id) => { (areas[pg[4]] = areas[pg[4]] || new Set()).add(id); }));
  const fieldsN = Object.values(SP.forms).reduce((t, f) => t + (f.sections || []).reduce((a, s) => a + (s.fields || []).length, 0), 0);
  return `${header(p, 'مكتبة المكونات', 'كل عناصر الواجهة بنظام الألوان (ج)، ثم كل نوافذ باور كولكت')}
  <div class="kpis">${[['الصفحات', PAGES.length, `${Object.keys(SP.pages).length} مستخرجة من الكود`], ['النوافذ والنماذج', Object.keys(FORMS).length + unlisted.length, `${Object.keys(SP.forms).length} مستخرجة، ${unlisted.length} جديدة في الجرد`], ['الحقول', fieldsN || '—', 'في كل النماذج المستخرجة'], ['نوافذ التأكيد', SP.confirms.length || Object.keys(CONFIRMS).length, 'حذف، تجاهل، اعتماد…']].map(([l, v, s]) => `<section class="card surf kpi"><small>${l}</small><b>${v}</b><span>${s}</span></section>`).join('')}</div>

  ${sec('خريطة مكونات HeroUI', 'كل عنصر في هذا التصميم وما يقابله في مكتبة HeroUI v3 عند التطبيق على الكود', `<div class="hmap">${[
    ['Button', 'الأزرار: رئيسي فحمي، ثانوي، شبحي، خطر، وأزرار الحركات بألوانها', 'mouse-pointer-click'], ['Chip', 'الحالات وأنواع الحركات وعدّادات التبويبات', 'tag'], ['Table', 'كل الجداول: فرز، تحديد، صف المجموع، رأس ثابت', 'table'], ['Pagination', 'ترقيم الصفحات تحت الجداول', 'chevrons-left-right'],
    ['Dropdown', 'قائمة إجراءات الصف، تصدير، الأعمدة', 'ellipsis-vertical'], ['Select', 'القوائم المنسدلة القصيرة (الفرع، المنطقة، الترتيب)', 'list'], ['ComboBox', 'القوائم الطويلة مع بحث (الطبلون، المشترك، البنك)', 'search'], ['DatePicker', 'التاريخ بالأشهر الشامية، الأسبوع يبدأ السبت', 'calendar'],
    ['RadioGroup', 'بطاقات الاختيار (طريقة الدفع، نوع الاشتراك، نوع التحميل)', 'circle-dot'], ['Checkbox', 'التحديد وسطور الإقرار «أؤكد أن…»', 'square-check'], ['Switch', 'التفعيل والإيقاف (المشترك نفسه، تحميل الرسوم)', 'toggle-right'], ['Tabs', 'التبويبات والمقطّعات (عرض مختصر / كل الحركات)', 'panels-top-left'],
    ['TextField / NumberField / TextArea', 'كل حقول الإدخال بارتفاع 48 بكسل', 'text-cursor-input'], ['Modal', 'كل النوافذ (78 نافذة)', 'app-window'], ['AlertDialog', 'نوافذ التأكيد (حذف، تجاهل، اعتماد)', 'triangle-alert'], ['Drawer', 'النوافذ على الجوال تفتح من الأسفل', 'panel-bottom'],
    ['Card', 'البطاقات والأرقام والصناديق', 'square'], ['Avatar', 'أول حرف من اسم المشترك أو الموظف', 'circle-user'], ['ProgressBar / Meter', 'امتلاء الطبلون، تغطية المستحق، توزيع الدفعة', 'gauge'], ['Toast', 'رسائل التأكيد القصيرة', 'message-square'],
    ['Skeleton', 'حالة التحميل', 'loader'], ['Breadcrumbs', 'المسار أعلى الصفحة', 'chevron-left'], ['Popover / ListBox', 'كل القوائم المنبثقة', 'layers'], ['Kbd', 'اختصارات لوحة المفاتيح', 'keyboard']
  ].map(([c, d, i]) => `<div class="hm"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${c}</b><small>${d}</small></span></div>`).join('')}</div>`)}

  ${sec('الأزرار', 'زر رئيسي فحمي واحد في كل صفحة، وأزرار الحركات المالية بلون نوعها', `
    <div class="kit-row"><button class="btn btn-primary">${ic('check', 'i i-sm')}حفظ</button><button class="btn btn-secondary">${ic('pencil', 'i i-sm')}تعديل</button><button class="btn btn-outline">${ic('download', 'i i-sm')}تصدير</button><button class="btn btn-ghost">إلغاء</button><button class="btn btn-danger">${ic('trash-2', 'i i-sm')}حذف</button><button class="btn btn-danger solid">${ic('trash-2', 'i i-sm')}حذف نهائي</button><button class="btn btn-primary" disabled>غير متاح</button></div>
    <div class="kit-row">${tones.map(([t, l], i) => toneBtn(l, t, { solid: i === 0 })).join('')}</div>
    <div class="kit-row">${tones.map(([t, l]) => toneBtn(l, t, { sm: true })).join('')}<span class="btn-group"><button class="btn btn-secondary btn-sm">اليوم</button><button class="btn btn-secondary btn-sm">الأسبوع</button><button class="btn btn-secondary btn-sm">الشهر</button></span><button class="btn btn-secondary btn-icon" aria-label="المزيد">${ic('ellipsis', 'i')}</button></div>`)}

  ${sec('الحالات وأنواع الحركات', 'اللون يعني الشيء نفسه في كل مكان', `
    <div class="kit-row">${['نشط', 'قيد الانتظار', 'مفصول', 'معتمد', 'بانتظار التدقيق', 'مرفوض', 'مغلق'].map(chipStatus).join('')}</div>
    <div class="kit-row">${['دفعة', 'تحميل حركة', 'رسوم قطع', 'خصم', 'مقاصة', 'دفعة مقسّمة', 'قراءة أسبوعية'].map(chipTx).join('')}</div>`)}

  ${sec('الحقول', 'كل الحقول بارتفاع 48 بكسل، والعنوان فوق الحقل، والمسافة بين الصفوف 16 بكسل', `<div class="fg">
    <div class="ff"><label>نص <span class="req">*</span></label><div class="fc">${ic('user', 'i i-sm')}<input placeholder="الاسم الرباعي"></div></div>
    <div class="ff"><label>رقم الجوال</label><div class="fc">${ic('phone', 'i i-sm')}<input data-ltr inputmode="tel" placeholder="05X XXX XXXX"></div></div>
    <div class="ff"><label>مبلغ</label><div class="fc"><input data-ltr inputmode="decimal" placeholder="0.00"><span class="addon">₪</span></div></div>
    <div class="ff"><label>بخطأ</label><div class="fc err"><input value="12"></div><span class="hint bad">رقم الهوية 9 أرقام</span></div>
    <div class="ff"><label>قائمة منسدلة</label>${pickBtn('kit1', 'الفرع الشمالي', ['الفرع الشمالي', 'الفرع الجنوبي', 'فرع الوسط', 'الفرع الشرقي', 'الفرع الغربي'], { icon: 'building-2' })}</div>
    <div class="ff"><label>قائمة بحث كبيرة</label>${pickBtn('kit2', '', NAMES, { icon: 'users', ph: 'ابحث عن مشترك' })}</div>
    <div class="ff"><label>تاريخ</label>${dateBtn('kit3', '2026-11-16')}</div>
    <div class="ff"><label>للقراءة فقط</label><div class="fc ro"><span style="color:var(--foreground);font-weight:600">202600148</span></div></div>
    <div class="ff w6"><label>ملاحظات <span class="opt">اختياري</span></label><div class="fc ta"><textarea placeholder="أي تفصيل"></textarea></div></div></div>`)}

  ${sec('الاختيار', 'التبديل والخيارات والبطاقات', `<div class="fg">
    <div class="ff w6"><label>مقطّع</label><div class="seg fit"><button aria-pressed="true" data-gseg>أسبوعي</button><button aria-pressed="false" data-gseg>شهري</button></div></div>
    <div class="ff w6"><label>بطاقات</label><div class="rcs"><button class="rc" role="radio" aria-checked="true" data-gcard><span class="ic">${ic('house', 'i i-sm')}</span><span><b>سكني</b><small>₪ 1.50 لكل كيلوواط</small></span></button><button class="rc" role="radio" aria-checked="false" data-gcard><span class="ic">${ic('store', 'i i-sm')}</span><span><b>تجاري</b><small>₪ 1.80 لكل كيلوواط</small></span></button></div></div>
    <div class="ff"><div class="flab">مفتاح<label class="lbl-sw"><input type="checkbox" checked>مفعّل</label></div><div class="fc ro" style="color:var(--muted)">يتغير أثره فورًا</div></div>
    <div class="ff"><label>مربعات اختيار</label><div class="fc" style="gap:18px"><label style="display:flex;gap:8px;align-items:center;color:var(--foreground)"><input type="checkbox" class="cb" checked>نقد</label><label style="display:flex;gap:8px;align-items:center;color:var(--foreground)"><input type="checkbox" class="cb">حوالة</label></div></div>
    <div class="ff w6"><label>اختيار متعدد</label><div class="chips-pick"><button aria-pressed="true" data-gchip>الفرع الشمالي</button><button aria-pressed="false" data-gchip>الفرع الجنوبي</button><button aria-pressed="true" data-gchip>فرع الوسط</button></div></div>
    <div class="ff w6"><label>رفع ملف</label><label class="drop">${ic('cloud-upload', 'i i-lg')}<b>اسحب الملف هنا أو اختره</b><small>Excel حتى 5 ميغابايت</small><input type="file" hidden></label></div></div>`)}

  ${dataTable({ title: 'جدول البيانات', sub: 'بحث، فلاتر، فرز، تحديد جماعي، أعمدة، كثافة، تصدير، ترقيم الصفحات', columns: [{ label: 'المشترك', type: 'person' }, { label: 'الطبلون', type: 'text' }, { label: 'الحالة', type: 'status' }, { label: 'آخر حركة', type: 'badge' }, { label: 'التاريخ', type: 'date' }, { label: 'الرصيد', type: 'money' }], rows: [['خالد منصور|202600148', 'الطبلون 14', 'نشط', 'دفعة', '16/11/2026', '₪ 640.00'], ['سعاد ناصر|202600118', 'الطبلون 21', 'مفصول', 'رسوم قطع', '02/07/2026', '₪ 1,940.00'], ['محمود داود|202600204', 'الطبلون 3', 'قيد الانتظار', 'خصم', '02/11/2026', '₪ 214.50'], ['هبة يوسف|202600367', 'الطبلون 9', 'نشط', 'مقاصة', '14/11/2026', '₪ 120.00']], filters: [{ label: 'الحالة', type: 'select', options: ['الكل', 'نشط', 'قيد الانتظار', 'مفصول'] }, { label: 'الفترة', type: 'daterange' }], rowActions: ['كشف الحساب', 'تسجيل دفعة', 'تعديل البيانات', 'إرسال SMS', 'حذف'], bulkActions: ['إرسال رسالة', 'تعديل جماعي', 'تصدير المحدد'], selectable: true, totals: true })}

  ${sec('حالات فارغة وتحميل', '', `<div class="kit-2"><div class="card-in"><div class="dt2-empty" style="padding:28px"><div class="ic">${ic('inbox', 'i i-lg')}</div><b>لا توجد دفعات اليوم بعد</b><p>ابدأ بتسجيل أول دفعة، وستظهر هنا مباشرة.</p>${toneBtn('تسجيل دفعة', 'pay', { solid: true, sm: true })}</div></div><div class="card-in">${[70, 52, 84].map((w) => `<div class="skel-row"><span class="sk" style="width:34px;height:34px;border-radius:50%"></span><span style="flex:1;display:flex;flex-direction:column;gap:8px"><span class="sk" style="width:${w}%"></span><span class="sk" style="width:40%;height:9px"></span></span></div>`).join('')}</div></div>`)}

  ${sec(`كل النوافذ (${forms.length + unlisted.length})`, 'مجمّعة حسب القسم، اضغط أي نافذة لمعاينتها', Object.entries(areas).map(([a, ids]) => `<div class="kit-grp"><h4>${a} <span class="chip2x st-default">${ids.size}</span></h4><div class="form-grid">${[...ids].map(formCard).join('')}</div></div>`).join('') + (unlisted.length ? `<div class="kit-grp"><h4>نوافذ وجدها الجرد الجديد في الكود <span class="chip2x st-default">${unlisted.length}</span></h4><div class="form-grid">${unlisted.map(formCard).join('')}</div></div>` : ''))}

  ${SP.confirms.length ? sec(`نوافذ التأكيد (${SP.confirms.length})`, 'الحذف والقطع بلون الخطر، ومع ضغط مطوّل حيث يطلبه النظام', `<div class="cf-grid">${SP.confirms.map((c, i) => { const t = c.tone || (/حذف|قطع|إغلاق/.test(c.title) ? 'danger' : /تجاهل|تراجع/.test(c.title) ? 'warning' : 'default'); return `<button type="button" class="cf-card" data-confirm="${i}"><span class="d ${t}"></span><span><span>${esc2(c.title)}</span><small>${esc2((c.file || '').split('/').pop())}</small></span></button>`; }).join('')}</div>`) : ''}`;
};
