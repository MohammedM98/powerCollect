
/* ═══ HeroUI-style Select (listbox) and DatePicker — replace the native <select> and date popups ═══
   A trigger is a button.fc.pick with data-pick="key" + data-opts (JSON) or data-date="key" + data-value (ISO).
   Choosing fires a bubbling 'pick' event: { key, value }. */
const MONTHS = ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];
const WDAYS = ['سبت', 'أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'];
const TODAY = '2026-11-16';
const fmtDate = (iso) => { if (!iso) return ''; const [y, m, d] = iso.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; };
const isoOf = (y, m, d) => `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
const pickBtn = (key, value, opts, o = {}) => `<button type="button" class="${o.cls || 'fc'} pick" data-pick="${key}" data-opts='${JSON.stringify(opts).replace(/'/g, '&#39;')}' aria-haspopup="listbox" aria-expanded="false" ${o.id ? `id="${o.id}"` : ''}>${o.icon ? ic(o.icon, 'i i-sm') : ''}<span class="pkv ${value ? '' : 'ph'}">${value || o.ph || 'اختر'}</span>${ic('chevrons-up-down', 'i i-sm chev')}</button>`;
const dateBtn = (key, value, o = {}) => `<button type="button" class="fc pick" data-date="${key}" ${o.id ? `id="${o.id}"` : ''} data-value="${value || ''}" aria-haspopup="dialog" aria-expanded="false">${ic('calendar', 'i i-sm')}<span class="pkv ${value ? '' : 'ph'}">${value ? fmtDate(value) : 'اختر التاريخ'}</span>${ic('chevron-down', 'i i-sm chev')}</button>`;
/** Rich select: options are { v, t, sub, used, cap }; the trigger shows the chosen card in short. */
const RICH = {};
const richFace = (key, v) => {
  const c = RICH[key], o = c.opts.find((x) => x.v === v), pct = o && o.cap ? Math.round(o.used / o.cap * 100) : null;
  return `${ic(c.icon, 'i i-sm')}<span class="pkv ${o ? '' : 'ph'}">${o ? `<b>${esc2(o.t)}</b><small>${esc2(o.sub)}</small>` : c.ph}</span>${pct !== null ? `<span class="cap"><span class="n">${o.used} من ${o.cap}</span><span class="rbar ${pct > 90 ? 'hot' : ''}"><i style="width:${pct}%"></i></span></span>` : ''}${ic('chevrons-up-down', 'i i-sm chev')}`;
};
const richBtn = (key, value, conf) => { RICH[key] = conf; return `<button type="button" class="fc pick rich" data-pick="${key}" data-rich data-value="${esc2(value || '')}" aria-haspopup="listbox" aria-expanded="false" aria-label="${conf.label}">${richFace(key, value)}</button>`; };
let POP = null;
function closePop(focusBack = false) { if (!POP) return; POP.el.remove(); POP.btn.setAttribute('aria-expanded', 'false'); if (focusBack) POP.btn.focus(); POP = null; }
function placePop(el, btn) {
  const r = btn.getBoundingClientRect(), h = el.offsetHeight, w = Math.min(innerWidth - 16, Math.max(r.width, el.dataset.min ? +el.dataset.min : 0));
  // Align to the trigger's start edge (right in RTL); if that runs off the left, align to its left edge instead.
  el.style.width = w + 'px'; el.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.right - w < 8 ? r.left : r.right - w)) + 'px'; el.style.right = 'auto';
  const below = innerHeight - r.bottom - 8 >= h || r.top < h + 8;
  el.style.top = (below ? r.bottom + 6 : r.top - h - 6) + 'px'; el.dataset.side = below ? 'bottom' : 'top';
}
function emit(btn, value) { btn.dispatchEvent(new CustomEvent('pick', { bubbles: true, detail: { key: btn.dataset.pick || btn.dataset.date, value } })); }
function openList(btn) {
  closePop();
  const rich = 'rich' in btn.dataset, conf = rich ? RICH[btn.dataset.pick] : null;
  const opts = rich ? conf.opts : JSON.parse(btn.dataset.opts), cur = rich ? btn.dataset.value : btn.querySelector('.pkv').textContent.trim();
  const el = document.createElement('div'); el.className = 'pop lb' + (rich ? ' lb-rich' : ''); el.setAttribute('role', 'listbox');
  const search = rich || opts.length > 6; const val = (o) => (rich ? o.v : o);
  el.innerHTML = `${search ? `<div class="lb-s">${ic('search', 'i i-sm')}<input placeholder="${rich ? conf.search : 'ابحث…'}" aria-label="ابحث في الخيارات"></div>` : ''}<div class="lb-l"></div>`;
  document.body.append(el);
  POP = { el, btn, kind: 'list', i: Math.max(0, opts.findIndex((o) => val(o) === cur)), list: opts, val };
  const draw = () => {
    const q = search ? el.querySelector('input').value.trim() : '';
    POP.list = opts.filter((o) => !q || (rich ? (o.t + ' ' + o.sub).includes(q) : o.includes(q))); POP.i = Math.min(POP.i, Math.max(0, POP.list.length - 1));
    const card = (o) => { const pct = Math.round(o.used / o.cap * 100); return `<span class="ic">${ic(conf.icon, 'i i-sm')}</span><span class="t"><b>${esc2(o.t)}</b><small>${esc2(o.sub)}</small></span><span class="cap"><span class="n">${o.used} من ${o.cap}</span><span class="rbar ${pct > 90 ? 'hot' : ''}"><i style="width:${pct}%"></i></span></span>`; };
    el.querySelector('.lb-l').innerHTML = POP.list.length ? POP.list.map((o, i) => `<div class="lb-o ${rich ? 'lb-card' : ''} ${i === POP.i ? 'on' : ''}" role="option" aria-selected="${val(o) === cur}" data-v="${esc2(val(o))}">${rich ? card(o) : esc2(o)}${val(o) === cur ? ic('check', 'i i-sm') : ''}</div>`).join('') : `<div class="lb-e">${rich ? 'لا يوجد طبلون بهذا الاسم أو المنطقة' : 'لا توجد نتيجة'}</div>`;
    el.querySelector('.lb-o.on')?.scrollIntoView({ block: 'nearest' });
    if (POP.placed) placePop(el, btn);
  };
  draw();
  // Prefer opening downward: scroll the form just enough to make room under the trigger.
  const sc = btn.closest('.ob-body, .mbody2, .co-main, .ob-grid'), need = el.offsetHeight + 14 - (innerHeight - btn.getBoundingClientRect().bottom);
  if (sc && need > 0 && getComputedStyle(sc).overflowY !== 'visible') sc.scrollTop += Math.min(need, sc.scrollHeight - sc.clientHeight - sc.scrollTop);
  placePop(el, btn); POP.placed = true; btn.setAttribute('aria-expanded', 'true');
  if (search) { const inp = el.querySelector('input'); inp.addEventListener('input', () => { POP.i = 0; draw(); }); inp.focus(); } else el.tabIndex = -1, el.focus();
  el.addEventListener('mousemove', (e) => { const o = e.target.closest('.lb-o'); if (!o) return; const i = [...el.querySelectorAll('.lb-o')].indexOf(o); if (i !== POP.i) { POP.i = i; el.querySelectorAll('.lb-o').forEach((x, k) => x.classList.toggle('on', k === i)); } });
  el.addEventListener('click', (e) => { const o = e.target.closest('.lb-o'); if (o) choose(o.dataset.v); });
  POP.draw = draw;
}
function choose(v) { const btn = POP.btn; if ('rich' in btn.dataset) { btn.dataset.value = v; btn.innerHTML = richFace(btn.dataset.pick, v); } else { const pv = btn.querySelector('.pkv'); pv.textContent = v; pv.classList.remove('ph'); } closePop(true); emit(btn, v); }
function openCal(btn, iso) {
  closePop();
  const sel = btn.dataset.value || TODAY; const [sy, sm] = (iso || sel).split('-').map(Number);
  const el = document.createElement('div'); el.className = 'pop cal'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'اختر التاريخ'); el.dataset.min = '312';
  document.body.append(el);
  POP = { el, btn, kind: 'cal', y: sy, m: sm - 1, focus: sel };
  const draw = () => {
    const { y, m } = POP; const first = new Date(y, m, 1).getDay(); const lead = (first + 1) % 7; const days = new Date(y, m + 1, 0).getDate();
    let cells = ''; for (let i = 0; i < lead; i++) cells += '<span></span>';
    for (let d = 1; d <= days; d++) { const v = isoOf(y, m, d); cells += `<button type="button" class="cd ${v === btn.dataset.value ? 'sel' : ''} ${v === TODAY ? 'today' : ''}" data-d="${v}" tabindex="${v === POP.focus ? 0 : -1}" aria-label="${fmtDate(v)}" aria-pressed="${v === btn.dataset.value}">${d}</button>`; }
    el.innerHTML = `<div class="cal-h"><button type="button" class="btn btn-ghost btn-icon btn-sm" data-cal="-1" aria-label="الشهر السابق">${ic('chevron-right', 'i i-sm')}</button><b>${MONTHS[m]} ${y}</b><button type="button" class="btn btn-ghost btn-icon btn-sm" data-cal="1" aria-label="الشهر التالي">${ic('chevron-left', 'i i-sm')}</button></div><div class="cal-w">${WDAYS.map((w) => `<span>${w}</span>`).join('')}</div><div class="cal-g">${cells}</div><div class="cal-f"><button type="button" class="btn btn-secondary btn-sm" data-cd="${TODAY}">اليوم</button><span class="muted" style="font-size:12px">${btn.dataset.value ? fmtDate(btn.dataset.value) : ''}</span></div>`;
    (el.querySelector(`[data-d="${POP.focus}"]`) || el.querySelector('.cd'))?.focus({ preventScroll: true });
  };
  POP.draw = draw; draw(); placePop(el, btn); btn.setAttribute('aria-expanded', 'true');
  el.addEventListener('click', (e) => {
    const nav = e.target.closest('[data-cal]'); if (nav) { POP.m += +nav.dataset.cal; if (POP.m < 0) { POP.m = 11; POP.y--; } if (POP.m > 11) { POP.m = 0; POP.y++; } POP.focus = isoOf(POP.y, POP.m, 1); draw(); return; }
    const d = e.target.closest('[data-d], [data-cd]'); if (d) pickDate(d.dataset.d || d.dataset.cd);
  });
}
function pickDate(v) { const btn = POP.btn; btn.dataset.value = v; const pv = btn.querySelector('.pkv'); pv.textContent = fmtDate(v); pv.classList.remove('ph'); closePop(true); emit(btn, v); }
document.addEventListener('click', (e) => {
  const p = e.target.closest('[data-pick]'); if (p) { e.preventDefault(); e.stopImmediatePropagation(); return POP?.btn === p ? closePop() : openList(p); }
  const d = e.target.closest('[data-date]'); if (d) { e.preventDefault(); e.stopImmediatePropagation(); return POP?.btn === d ? closePop() : openCal(d); }
  if (POP && !POP.el.contains(e.target)) closePop();
}, true);
document.addEventListener('keydown', (e) => {
  const t = e.target.closest?.('[data-pick], [data-date]');
  if (!POP && t && !e.ctrlKey && !e.metaKey && ['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); return t.dataset.pick ? openList(t) : openCal(t); }
  if (!POP) return;
  if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); return closePop(true); }
  if (e.key === 'Tab') return closePop();
  if (POP.kind === 'list') {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); e.stopImmediatePropagation(); POP.i = (POP.i + (e.key === 'ArrowDown' ? 1 : -1) + POP.list.length) % POP.list.length; POP.draw(); }
    if (e.key === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); if (POP.list[POP.i]) choose(POP.val(POP.list[POP.i])); }
  } else if (POP.kind === 'cal') {
    const step = { ArrowLeft: 1, ArrowRight: -1, ArrowDown: 7, ArrowUp: -7 }[e.key];
    if (step) { e.preventDefault(); e.stopImmediatePropagation(); const d = new Date(POP.focus); d.setDate(d.getDate() + step); POP.y = d.getFullYear(); POP.m = d.getMonth(); POP.focus = isoOf(POP.y, POP.m, d.getDate()); POP.draw(); }
    if (e.key === 'PageUp' || e.key === 'PageDown') { e.preventDefault(); POP.m += e.key === 'PageDown' ? 1 : -1; if (POP.m < 0) { POP.m = 11; POP.y--; } if (POP.m > 11) { POP.m = 0; POP.y++; } POP.focus = isoOf(POP.y, POP.m, 1); POP.draw(); }
    if (e.key === 'Enter' && e.target.dataset.d) { e.preventDefault(); e.stopImmediatePropagation(); pickDate(e.target.dataset.d); }
  }
}, true);
addEventListener('resize', () => closePop());
/* Follow the trigger while its container scrolls; close once it leaves the view. */
document.addEventListener('scroll', (e) => {
  if (!POP || POP.el.contains(e.target)) return;
  const r = POP.btn.getBoundingClientRect(), box = (POP.btn.closest('.ob-body, .mbody2, .co-main, .ob-grid') || document.documentElement).getBoundingClientRect();
  if (r.bottom < box.top || r.top > box.bottom) return closePop();
  placePop(POP.el, POP.btn);
}, true);
