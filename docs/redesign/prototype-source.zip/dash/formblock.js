/* ── Generic form window: every field drawn with the matching HeroUI-style control ──
   Text shown to people is user-facing Arabic only: extraction notes (English, code conditions) never reach the screen,
   and {placeholders} become sample values. Every control is 48px, labels sit above, rows are 16px apart. */
const FIELD_ICON = { tel: 'phone', id: 'id-card', email: 'at-sign', password: 'lock', date: 'calendar', datetime: 'calendar-clock', time: 'clock', search: 'search', number: 'hash' };
const SAMPLE = { n: '12', 'عدد': '12', name: 'خالد منصور', 'اسم': 'خالد منصور', 'الاسم': 'خالد منصور', 'رقم': '14', noun: 'الفرع', 'السجل': 'الفرع', 'قارئ': 'أحمد سالم', 'المبلغ': '₪ 640.00', amount: '₪ 640.00' };
const fill = (s) => String(s ?? '').replace(/\{([^}]+)\}/g, (m, k) => SAMPLE[k.trim()] ?? '');
const firstVariant = (s) => fill(String(s ?? '').split(' / ')[0]).trim();
/** User-facing Arabic only: drops parentheses holding Latin text and anything that reads like code. */
const ar = (s) => { const t = fill(String(s ?? '')).replace(/\([^)]*[A-Za-z][^)]*\)/g, '').replace(/\s{2,}/g, ' ').trim(); return /[A-Za-z_=<>]{2,}/.test(t.replace(/SMS|Excel|PDF|CSV|QR|ID|[A-Z]{2,4}-?\d*/g, '')) ? '' : t; };
function fieldHTML(fd, k) {
  const key = 'g' + k, lab = esc2(ar(fd.label) || firstVariant(fd.label)), req = fd.required ? ' <span class="req">*</span>' : '';
  const h = ar(fd.hint), hint = h ? `<span class="hint">${esc2(h)}</span>` : '';
  const opts = (Array.isArray(fd.options) ? fd.options.filter((o) => typeof o === 'string') : []).map((o) => ar(o) || o);
  const real = opts.length > 0 && !/from DB|من قاعدة|DB:|[A-Za-z]{4,}/.test(opts.join(' '));
  const unit = fd.unit && fd.type !== 'money' ? ` <span class="opt">${esc2(fd.unit)}</span>` : '';
  const lbl = `<label>${lab}${req}${unit}</label>`;
  const wrap = (inner, w = '') => `<div class="ff ${w}">${inner}${hint}</div>`;
  const ph = esc2(ar(fd.placeholder) || '');
  switch (fd.type) {
    case 'textarea': return wrap(`${lbl}<div class="fc ta"><textarea placeholder="${ph}"></textarea></div>`, 'w6');
    case 'switch': { const on = /true|نعم|مفعّل|مفعل|1/.test(String(fd.default)); return wrap(`${lbl}<label class="fc sw-field"><span>${on ? 'مفعّل' : 'غير مفعّل'}</span><span class="lbl-sw"><input type="checkbox" ${on ? 'checked' : ''} data-gsw aria-label="${lab}"></span></label>`); }
    case 'checkbox': return wrap(`<span class="flab" aria-hidden="true">&nbsp;</span><div class="fc cb-field"><label><input type="checkbox" class="cb" ${fd.default ? 'checked' : ''}><span>${lab}${req}</span></label></div>`, (fd.label || '').length > 40 ? 'w6' : '');
    case 'segmented': case 'radio': if (real && opts.length <= 4) return wrap(`${lbl}<div class="seg fit">${opts.map((o, i) => `<button type="button" aria-pressed="${o === fd.default || (!fd.default && i === 0)}" data-gseg>${esc2(o)}</button>`).join('')}</div>`, 'w6');
    /* falls through to cards for longer option lists */
    case 'cards': if (real) return wrap(`${lbl}<div class="rcs" role="radiogroup">${opts.map((o, i) => { const t = txTone(o); return `<button type="button" class="rc" role="radio" aria-checked="${o === fd.default || (!fd.default && i === 0)}" data-gcard><span class="ic">${ic(t ? TX_ICON[t] : 'circle-dot', 'i i-sm')}</span><span><b>${esc2(o)}</b></span></button>`; }).join('')}</div>`, 'w6');
    /* falls through */
    case 'select': case 'combobox': return wrap(`${lbl}${pickBtn(key, real && opts.includes(fd.default) ? fd.default : '', real ? opts : ['الخيار الأول', 'الخيار الثاني', 'الخيار الثالث'], { icon: fd.type === 'combobox' ? 'search' : 'list', ph: `اختر ${lab.replace(/^ال/, '') ? lab : ''}`.trim() })}`);
    case 'multiselect': case 'chips': return wrap(`${lbl}<div class="chips-pick">${(real ? opts : ['الخيار الأول', 'الخيار الثاني', 'الخيار الثالث']).map((o, i) => `<button type="button" aria-pressed="${i === 0}" data-gchip>${esc2(o)}</button>`).join('')}</div>`, 'w6');
    case 'date': case 'datetime': return wrap(`${lbl}${dateBtn(key, '2026-11-16')}`);
    case 'currency': return wrap(`${lbl}<div class="seg fit">${['₪ شيكل', '$ دولار', 'د.أ دينار', '€ يورو'].map((o, i) => `<button type="button" aria-pressed="${i === 0}" data-gseg>${o}</button>`).join('')}</div>`);
    case 'money': return wrap(`${lbl}<div class="fc"><input inputmode="decimal" placeholder="0.00" data-ltr aria-label="${lab}"><span class="addon">${esc2(fd.unit || '₪')}</span></div>`);
    case 'file': return wrap(`${lbl}<label class="drop">${ic('cloud-upload', 'i i-lg')}<b>اسحب الملف هنا أو اختره</b><small>${esc2(h || 'ملف Excel أو PDF أو صورة')}</small><input type="file" hidden></label>`, 'w6');
    case 'color': return wrap(`${lbl}<div class="swatches">${['#2A2D34', '#E2642A', '#3B82F6', '#16A34A', '#9333EA', '#DC2626'].map((c, i) => `<button type="button" style="background:${c}" aria-pressed="${i === 0}" aria-label="${c}"></button>`).join('')}</div>`);
    case 'readonly': return wrap(`${lbl}<div class="fc ro"><span class="ro-v">${esc2(ar(fd.default) || '1,284')}</span></div>`);
    case 'table': return wrap(`${lbl}<div class="mini-tbl2">${['خالد منصور', 'سعاد ناصر', 'محمود داود'].map((n, i) => `<div><span class="who2"><span class="av3">${n[0]}</span><span><b>${n}</b><small>${202600148 + i * 37}</small></span></span><span class="n">₪ ${money(640 - i * 170)}</span></div>`).join('')}</div>`, 'w6');
    default: {
      const t = ['id', 'tel', 'number'].includes(fd.type) ? 'data-ltr inputmode="numeric"' : fd.type === 'password' ? 'type="password"' : fd.type === 'email' ? 'type="email" data-ltr' : fd.type === 'time' ? 'type="time"' : '';
      return wrap(`${lbl}<div class="fc">${FIELD_ICON[fd.type] ? ic(FIELD_ICON[fd.type], 'i i-sm') : ''}<input ${t} placeholder="${ph}" aria-label="${lab}">${fd.unit ? `<span class="addon">${esc2(fd.unit)}</span>` : ''}</div>`);
    }
  }
}
function openForm(id) {
  if (BESPOKE_FORMS[id]) return BESPOKE_FORMS[id]();
  const f = SP.forms[id]; if (!f) return toast('هذه النافذة لم تُستخرج بعد', 'info');
  const title = firstVariant(f.title || id), tone = txTone(title), secs = (f.sections || []).filter((s) => s.fields?.length);
  let k = 0;
  const body = secs.length ? secs.map((s) => `<section class="gsec">${s.title && secs.length > 1 && ar(s.title) ? `<h4>${esc2(ar(s.title))}</h4>` : ''}<div class="fg">${s.fields.map((fd) => fieldHTML(fd, k++)).join('')}</div></section>`).join('')
    : `<div class="dt2-empty" style="padding:24px"><div class="ic">${ic('app-window', 'i i-lg')}</div><b>${esc2(title)}</b><p>نافذة عرض بلا حقول إدخال</p></div>`;
  const comp = (f.computed || []).map(ar).filter(Boolean);
  const compHTML = comp.length ? `<div class="effect"><small>يتحدّث أثناء الإدخال</small>${comp.map((c) => `<div class="kv"><span>${esc2(c)}</span><b class="n">—</b></div>`).join('')}</div>` : '';
  // Footer: cancel, then the main action; further variants of the action go into a menu so the footer never crowds.
  const btns = (f.buttons?.length ? f.buttons : [{ label: 'إلغاء', role: 'cancel' }, { label: 'حفظ', role: 'submit' }]).map((b) => ({ ...b, label: firstVariant(b.label) })).filter((b) => b.label);
  const cancel = btns.find((b) => b.role === 'cancel') || { label: 'إلغاء' };
  const mains = btns.filter((b) => b.role === 'submit' || b.role === 'danger'), extra = btns.filter((b) => b.role === 'secondary' || b.role === 'link');
  const main = mains[0], more = [...mains.slice(1), ...extra];
  const mainHTML = !main ? '' : /اضغط/.test(main.label) ? `<button type="button" class="btn btn-danger solid hold" data-hold><span class="fillbar"></span><span class="t">${ic('hand', 'i i-sm')}${esc2(main.label)}</span></button>`
    : main.role === 'danger' ? `<button type="button" class="btn btn-danger solid" data-act="g-submit">${ic('trash-2', 'i i-sm')}${esc2(main.label)}</button>`
    : tone && tone !== 'reading' ? toneBtn(esc2(main.label), tone, { solid: true, attrs: 'data-act="g-submit"' }) : `<button type="button" class="btn btn-primary" data-act="g-submit">${ic('check', 'i i-sm')}${esc2(main.label)}</button>`;
  const moreHTML = more.length ? `<button type="button" class="btn btn-secondary btn-icon" data-more='${JSON.stringify(more.map((b) => b.label)).replace(/'/g, '&#39;')}' aria-label="إجراءات أخرى" title="إجراءات أخرى">${ic('ellipsis', 'i')}</button>` : '';
  const size = f.size === 'sm' ? 'gsm' : f.size === 'xl' || f.size === 'full' || f.size === 'lg' ? 'glg' : '';
  const sub = ar((f.title || '').split(' / ').slice(1).join('، ')) || (f.steps?.length ? f.steps.map(ar).filter(Boolean).join('، ') : '');
  const el = mount(`md sheet-modal gform ${size}`, `<div class="mh"><span class="tile-ic" ${tone ? `data-tone="${tone}" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)"` : ''}>${ic(tone ? TX_ICON[tone] : actIcon(title) === 'circle-dot' ? 'app-window' : actIcon(title), 'i i-lg')}</span><div><h2>${esc2(title)}</h2>${sub ? `<p>${esc2(sub)}</p>` : ''}</div><div class="end">${closeBtn}</div></div><div class="mbody2">${body}${compHTML}</div><div class="mfoot"><span class="k"><span class="kbd">Esc</span> إغلاق</span><div class="end">${moreHTML}<button type="button" class="btn btn-secondary" data-act="close">${esc2(cancel.label)}</button>${mainHTML}</div></div>`);
  MO = { el, id: 'g-' + id, f: {}, discard: null };
}

