
/* ═══════════ Component kit: data table, menus, filters, tones ═══════════ */
const NAMES = ['خالد منصور', 'سعاد ناصر', 'محمود داود', 'هبة يوسف', 'عمر الشريف', 'نادية عيسى', 'ليلى حسن', 'يوسف حمدان', 'رامي خليل', 'سامر عودة', 'منى عبد الله', 'إياد الكفارنة', 'آمنة العجل', 'طارق أبو زايد', 'رغد سالم', 'باسل نصر'];
const STATUS_TONE = [[/نشط|مسدّد|مسدد|معتمد|مدقّق|مدقق|مكتمل|مُرسل|مرسل|تم|ناجح|متصل|مفعّل|مفعل|مقبول|مغلق ومطابق|مطابق/, 'success'], [/انتظار|معلّق|معلق|جزئي|قيد|متأخر|بانتظار|مسودة|تحت/, 'warning'], [/مفصول|مرفوض|فشل|محذوف|مقطوع|مدين|ملغى|ملغي|موقوف|معطّل|معطل|عجز|خطأ/, 'danger']];
const statusTone = (t) => (STATUS_TONE.find(([r]) => r.test(t)) || [, 'default'])[1];
const TX_TONE = [[/مقسّمة|مقسمة/, 'split'], [/دفعة|تحصيل|سداد|قبض/, 'pay'], [/مقاصة/, 'clearing'], [/خصم/, 'discount'], [/تحميل|رسوم|غرامة|حد أدنى|الحد الأدنى|قطع/, 'charge'], [/قراءة|فاتورة|استهلاك/, 'reading']];
const txTone = (t) => (TX_TONE.find(([r]) => r.test(t)) || [, null])[1];
const TX_ICON = { pay: 'hand-coins', charge: 'receipt', discount: 'percent', clearing: 'arrow-left-right', split: 'split', reading: 'gauge' };
const ACT_ICON = [[/حذف نهائي/, 'trash-2'], [/حذف|إزالة/, 'trash-2'], [/تعديل/, 'pencil'], [/طباعة|سند/, 'printer'], [/كشف|عرض|تفاصيل|فتح/, 'eye'], [/إرجاع|تراجع/, 'undo-2'], [/أرشفة/, 'archive'], [/استعادة/, 'archive-restore'], [/رسالة|SMS|إرسال/, 'send'], [/نسخ/, 'copy'], [/تصدير|Excel|تنزيل/, 'download'], [/اعتماد|تدقيق/, 'badge-check'], [/إغلاق/, 'lock'], [/قراءة/, 'gauge'], [/نقل/, 'arrow-left-right'], [/قطع/, 'unplug'], [/إعادة وصل|وصل/, 'plug']];
const actIcon = (t) => (txTone(t) && !/حذف|تعديل/.test(t) ? TX_ICON[txTone(t)] : (ACT_ICON.find(([r]) => r.test(t)) || [, 'circle-dot'])[1]);
const chipStatus = (t) => `<span class="chip2x st-${statusTone(t)}"><span class="dot"></span>${esc2(t)}</span>`;
const chipTx = (t) => { const k = txTone(t); return k ? `<span class="chip2x" data-tone="${k}">${ic(TX_ICON[k], 'i')}${esc2(t)}</span>` : `<span class="chip2x st-default">${esc2(t)}</span>`; };
const toneBtn = (label, tone, o = {}) => `<button type="button" class="btn btn-tone ${o.solid ? 'solid' : ''} ${o.sm ? 'btn-sm' : ''}" data-tone="${tone}" ${o.attrs || ''}>${ic(o.icon || TX_ICON[tone] || 'circle-dot', 'i i-sm')}${label}</button>`;
const numOf = (v) => { const m = String(v ?? '').replace(/[,٬\s]/g, '').match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : NaN; };

function cell(type, v, col) {
  const s = v == null ? '' : String(v);
  if (type === 'person') { const [n, sub] = s.split('|'); return `<div class="who2"><span class="av3">${esc2((n || '?').trim()[0] || '?')}</span><span><b>${esc2(n)}</b>${sub ? `<small>${esc2(sub)}</small>` : ''}</span></div>`; }
  if (type === 'money') { const n = numOf(s); if (isNaN(n)) return esc2(s); const cur = (s.match(/[₪$€]|د\.أ/) || ['₪'])[0]; return `<span class="mv" dir="ltr">${n < 0 ? '− ' : ''}<span class="cur">${cur}</span>${money(Math.abs(n))}</span>`; }
  if (type === 'status') return s ? chipStatus(s) : '';
  if (type === 'badge') return s ? (txTone(s) ? chipTx(s) : `<span class="chip2x st-default">${esc2(s)}</span>`) : '';
  if (type === 'progress') { const n = numOf(s); const pct = isNaN(n) ? 0 : Math.max(0, Math.min(100, n)); return `<div class="pr"><span class="rbar ${pct > 90 ? 'hot' : ''}"><i style="width:${pct}%"></i></span><span class="n">${esc2(s)}</span></div>`; }
  if (type === 'boolean') { const on = /^(نعم|true|1|✓|مفعّل|مفعل)$/.test(s.trim()); return ic(on ? 'check' : 'minus', 'i i-sm' + (on ? '' : ' off')); }
  return esc2(s);
}
const COLCLS = { money: 'c-money', number: 'c-num', date: 'c-date', datetime: 'c-date', account: 'c-acc', progress: 'c-prog', boolean: 'c-bool' };

/* Sample rows: the extracted 3–4 rows, varied into a fuller page so sorting, paging and selection have something to do. */
function expandRows(cols, rows, n) {
  if (!rows?.length) return [];
  const out = [];
  for (let i = 0; i < n; i++) {
    const base = rows[i % rows.length];
    out.push(cols.map((c, k) => {
      let v = base[k]; if (i < rows.length || v == null) return v; v = String(v);
      if (c.type === 'person') return NAMES[(i * 5 + k) % NAMES.length] + (v.includes('|') ? '|' + v.split('|')[1].replace(/\d{3}$/, (d) => String((+d + i * 7) % 1000).padStart(3, '0')) : '');
      if (c.type === 'money' || c.type === 'number') { const x = numOf(v); if (isNaN(x)) return v; const y = Math.round(x * (0.35 + ((i * 37) % 100) / 70) * 100) / 100; return c.type === 'money' ? v.replace(/-?[\d,]+(\.\d+)?/, money(y)) : String(Math.round(y)); }
      if (c.type === 'account') return v.replace(/\d{3}$/, (d) => String((+d + i * 13) % 1000).padStart(3, '0'));
      if (c.type === 'date' || c.type === 'datetime') return v.replace(/(\d{1,2})([/\-.])/, (m, d, sep) => String(((+d + i) % 28) + 1).padStart(d.length, '0') + sep);
      return v;
    }));
  }
  return out;
}

const TBL = {};
let tblSeq = 0;
/** spec: { title, sub, columns:[{label,type}], rows, rowActions, bulkActions, filters:[{label,type,options}], search, selectable, empty, per, export, totals, rowHref } */
function dataTable(spec) {
  const id = 't' + (++tblSeq);
  const cols = spec.columns.map((c) => ({ ...c, type: c.type || 'text' })).filter((c) => c.type !== 'actions');
  const rows = spec.expand === false ? (spec.rows || []) : expandRows(cols, spec.rows || [], spec.count || 23);
  /* Dense tables: show the 7 columns that matter most (the first, names, statuses, amounts, then in order); the rest open in each row's details. */
  const hidden = new Set();
  if (cols.length > 7) { const pri = (c, k) => (k === 0 ? 0 : c.type === 'person' ? 1 : c.type === 'status' ? 2 : c.type === 'money' ? 3 : 4); const keep = cols.map((c, k) => [pri(c, k), k]).sort((a, b) => a[0] - b[0] || a[1] - b[1]).slice(0, 7).map(([, k]) => k); cols.forEach((c, k) => { if (!keep.includes(k)) hidden.add(k); }); }
  TBL[id] = { spec, cols, rows, q: '', f: {}, sort: null, sel: new Set(), page: 1, per: spec.per || 8, hidden, open: new Set(), compact: false, loading: false };
  return `<section class="card surf dt2" id="${id}" data-tbl="${id}">${tblShell(id)}</section>`;
}
function tblShell(id) {
  const T = TBL[id], s = T.spec;
  const filters = (s.filters || []).filter((f) => f.type !== 'search').map((f, i) => {
    const opts = Array.isArray(f.options) && f.options.length && !/from DB|من قاعدة/.test(f.options.join(' ')) ? f.options : null;
    if (f.type === 'toggle') return `<label class="lbl-sw" style="margin:0;height:40px;padding:0 6px"><input type="checkbox" data-tf="${id}:${i}">${esc2(f.label)}</label>`;
    if (f.type === 'segmented' && opts) return `<div class="seg" data-tseg="${id}:${i}">${opts.map((o, k) => `<button type="button" aria-pressed="${k === 0}" data-v="${esc2(o)}">${esc2(o)}</button>`).join('')}</div>`;
    const list = opts || (f.type === 'date' || f.type === 'daterange' ? ['اليوم', 'أمس', 'آخر 7 أيام', 'هذا الشهر', 'الشهر الماضي', 'مخصص'] : ['الكل', 'الفرع الشمالي', 'الفرع الجنوبي', 'فرع الوسط']);
    return pickBtn(`f:${id}:${i}`, T.f[i] || '', list, { icon: f.type === 'date' || f.type === 'daterange' ? 'calendar-range' : 'list-filter', cls: 'select', ph: f.label });
  }).join('');
  const searchF = (s.filters || []).find((f) => f.type === 'search');
  return `<div class="dt2-bar">
      ${s.title ? `<div style="margin-inline-end:auto"><h3 style="margin:0;font-size:18px">${esc2(s.title)}</h3>${s.sub ? `<p class="muted" style="margin:2px 0 0;font-size:13px">${esc2(s.sub)}</p>` : ''}</div>` : ''}
      ${s.search !== false ? `<label class="dt2-search">${ic('search', 'i i-sm')}<input data-tq="${id}" placeholder="${esc2(searchF?.label || s.searchPh || 'ابحث في الجدول')}" aria-label="بحث"></label>` : ''}
      ${filters}<span class="grow"></span>
      <button type="button" class="btn btn-ghost btn-icon btn-sm" data-tmenu="cols:${id}" aria-label="الأعمدة الظاهرة" title="الأعمدة">${ic('columns-3', 'i i-sm')}</button>
      <button type="button" class="btn btn-ghost btn-icon btn-sm" data-tdens="${id}" aria-label="كثافة الصفوف" title="كثافة الصفوف">${ic('rows-3', 'i i-sm')}</button>
      ${s.export !== false ? `<button type="button" class="btn btn-secondary btn-sm" data-tmenu="exp:${id}">${ic('download', 'i i-sm')}تصدير</button>` : ''}
    </div><div class="dt2-chips" id="${id}-chips"></div><div id="${id}-bulk"></div><div class="dt2-scroll"><div class="th-wrap"></div><table id="${id}-tb"></table></div><div class="dt2-foot" id="${id}-foot"></div>`;
}
function tblView(id) {
  const T = TBL[id]; let rows = T.rows.map((r, i) => ({ r, i }));
  const q = T.q.trim(); if (q) rows = rows.filter(({ r }) => r.join(' ').includes(q));
  Object.values(T.f).forEach((v) => { if (v && !/^الكل|^كل /.test(v) && !/أيام|اليوم|أمس|الشهر|مخصص/.test(v)) rows = rows.filter(({ r }) => r.join(' ').includes(v)); });
  if (T.sort) { const { k, dir } = T.sort, t = T.cols[k].type; rows.sort((a, b) => { const x = a.r[k], y = b.r[k]; const nx = numOf(x), ny = numOf(y); const c = (t === 'money' || t === 'number' || t === 'progress') && !isNaN(nx) && !isNaN(ny) ? nx - ny : String(x ?? '').localeCompare(String(y ?? ''), 'ar'); return dir * c; }); }
  return rows;
}
function tblDraw(id) {
  const T = TBL[id], s = T.spec, el = $('#' + id); if (!el) return;
  el.classList.toggle('compact', T.compact); el.classList.toggle('loading', T.loading);
  const view = tblView(id), pages = Math.max(1, Math.ceil(view.length / T.per)); T.page = Math.min(T.page, pages);
  const slice = view.slice((T.page - 1) * T.per, T.page * T.per);
  const vis = T.cols.map((c, k) => ({ c, k })).filter(({ k }) => !T.hidden.has(k));
  const selOn = s.selectable !== false, acts = s.rowActions?.length;
  const allOn = slice.length && slice.every(({ i }) => T.sel.has(i)), someOn = slice.some(({ i }) => T.sel.has(i));
  const expOn = T.hidden.size > 0;
  const head = `<thead><tr>${expOn ? '<th class="c-exp"><span class="sr-only">تفاصيل</span></th>' : ''}${selOn ? `<th class="c-sel"><input type="checkbox" class="cb" data-tall="${id}" aria-label="تحديد الكل" ${allOn ? 'checked' : ''}></th>` : ''}${vis.map(({ c, k }) => { const srt = T.sort?.k === k; return `<th class="${COLCLS[c.type] || ''}" ${srt ? `aria-sort="${T.sort.dir > 0 ? 'ascending' : 'descending'}"` : ''}><button type="button" class="sort" data-tsort="${id}:${k}">${esc2(c.label)}${ic(srt ? (T.sort.dir > 0 ? 'arrow-up' : 'arrow-down') : 'chevrons-up-down', 'i')}</button></th>`; }).join('')}${acts ? '<th class="c-act"><span class="sr" style="position:absolute;width:1px;height:1px;overflow:hidden">إجراءات</span></th>' : ''}</tr></thead>`;
  const mainK = vis.find(({ c }) => c.type === 'person')?.k ?? vis[0]?.k;
  const body = slice.length ? slice.map(({ r, i }) => `<tr class="${T.sel.has(i) ? 'sel' : ''} ${T.open.has(i) ? 'open' : ''}" ${s.rowHref ? `data-href="${s.rowHref}"` : ''}>${expOn ? `<td class="c-exp"><button type="button" class="exp" data-texp="${id}:${i}" aria-expanded="${T.open.has(i)}" aria-label="تفاصيل الصف">${ic('chevron-down', 'i i-sm')}</button></td>` : ''}${selOn ? `<td class="c-sel"><input type="checkbox" class="cb" data-tsel="${id}:${i}" aria-label="تحديد الصف" ${T.sel.has(i) ? 'checked' : ''}></td>` : ''}${vis.map(({ c, k }) => `<td class="${COLCLS[c.type] || ''} ${k === mainK ? 'c-main' : ''} ${c.type === 'money' && numOf(r[k]) < 0 ? 'neg' : ''}" data-label="${esc2(c.label)}">${cell(c.type, r[k], c)}</td>`).join('')}${acts ? `<td class="c-act"><button type="button" class="row-menu" data-tmenu="row:${id}:${i}" aria-label="إجراءات الصف" aria-haspopup="menu" aria-expanded="false">${ic('ellipsis-vertical', 'i i-sm')}</button></td>` : ''}</tr>${T.open.has(i) ? `<tr class="dt2-detail"><td colspan="${vis.length + (selOn ? 1 : 0) + (acts ? 1 : 0) + 1}"><dl>${[...T.hidden].map((k) => `<div><dt>${esc2(T.cols[k].label)}</dt><dd>${cell(T.cols[k].type, r[k], T.cols[k]) || '—'}</dd></div>`).join('')}</dl></td></tr>` : ''}`).join('')
    : `<tr><td colspan="${vis.length + (selOn ? 1 : 0) + (acts ? 1 : 0) + (expOn ? 1 : 0)}" style="height:auto;border:0;display:table-cell"><div class="dt2-empty"><div class="ic">${ic(T.q || Object.values(T.f).some(Boolean) ? 'search-x' : 'inbox', 'i i-lg')}</div><b>${T.q || Object.values(T.f).some(Boolean) ? 'لا توجد نتائج مطابقة' : esc2(s.empty || 'لا توجد بيانات بعد')}</b><p>${T.q || Object.values(T.f).some(Boolean) ? 'جرّب كلمة أخرى أو امسح الفلاتر.' : ''}</p>${T.q || Object.values(T.f).some(Boolean) ? `<button type="button" class="btn btn-secondary btn-sm" data-tclear="${id}">${ic('x', 'i i-sm')}مسح البحث والفلاتر</button>` : ''}</div></td></tr>`;
  const totals = s.totals ? `<tfoot><tr class="dt2-totals">${selOn ? '<td></td>' : ''}${vis.map(({ c, k }, n) => `<td class="${COLCLS[c.type] || ''}">${n === 0 ? 'المجموع' : c.type === 'money' ? cell('money', '₪ ' + view.reduce((t, { r }) => t + (numOf(r[k]) || 0), 0)) : ''}</td>`).join('')}${acts ? '<td></td>' : ''}</tr></tfoot>` : '';
  $('#' + id + '-tb').innerHTML = head + `<tbody>${body}</tbody>` + totals;
  const hall = $(`[data-tall="${id}"]`); if (hall) hall.indeterminate = !allOn && someOn;
  // Active filter chips
  const chips = [...(T.q ? [['q', `البحث: ${T.q}`]] : []), ...Object.entries(T.f).filter(([, v]) => v).map(([k, v]) => [k, `${s.filters[+k].label}: ${v}`])];
  $('#' + id + '-chips').innerHTML = chips.length ? chips.map(([k, t]) => `<span class="fchip">${esc2(t)}<button type="button" data-tunf="${id}:${k}" aria-label="إزالة الفلتر">${ic('x', 'i i-sm')}</button></span>`).join('') + `<button type="button" class="fchip-clear" data-tclear="${id}">مسح الكل</button>` : '';
  // Bulk bar
  const n = T.sel.size;
  $('#' + id + '-bulk').innerHTML = n && s.bulkActions?.length !== 0 ? `<div class="dt2-bulk" role="region" aria-label="إجراءات على المحدد"><span>تم تحديد <b>${n}</b></span><span class="grow"></span>${(s.bulkActions?.length ? s.bulkActions : ['تصدير المحدد']).map((b) => `<button type="button" class="btn btn-sm ${/حذف|قطع/.test(b) ? 'danger' : ''}" data-tbulk="${id}">${ic(actIcon(b), 'i i-sm')}${esc2(b)}</button>`).join('')}<button type="button" class="btn btn-sm btn-icon" data-tnone="${id}" aria-label="إلغاء التحديد">${ic('x', 'i i-sm')}</button></div>` : '';
  // Footer: count + pager + per page
  const from = view.length ? (T.page - 1) * T.per + 1 : 0, to = Math.min(view.length, T.page * T.per);
  const nums = []; for (let p = 1; p <= pages; p++) { if (p === 1 || p === pages || Math.abs(p - T.page) <= 1) nums.push(p); else if (nums[nums.length - 1] !== '…') nums.push('…'); }
  $('#' + id + '-foot').innerHTML = `<span><b>${from}–${to}</b> من <b>${view.length}</b></span><span class="grow"></span><span class="per">${pickBtn(`per:${id}`, `${T.per} صفوف`, ['8 صفوف', '15 صفًا', '25 صفًا', '50 صفًا'], { cls: 'select', icon: 'list' })}</span><nav class="pager" aria-label="الصفحات"><button type="button" data-tpage="${id}:${T.page - 1}" ${T.page === 1 ? 'disabled' : ''} aria-label="السابقة">${ic('chevron-right', 'i i-sm')}</button>${nums.map((p) => p === '…' ? '<span class="gap">…</span>' : `<button type="button" data-tpage="${id}:${p}" ${p === T.page ? 'aria-current="page"' : ''}>${p}</button>`).join('')}<button type="button" data-tpage="${id}:${T.page + 1}" ${T.page === pages ? 'disabled' : ''} aria-label="التالية">${ic('chevron-left', 'i i-sm')}</button></nav>`;
}
const tblDrawAll = () => Object.keys(TBL).forEach((id) => $('#' + id) ? tblDraw(id) : delete TBL[id]);

/* Menus (HeroUI Dropdown) on the shared popover. items: [{label, icon, tone, danger, k, act} | 'sep' | {head}] */
function openMenu(btn, items, onPick) {
  closePop();
  const el = document.createElement('div'); el.className = 'pop menu'; el.setAttribute('role', 'menu'); el.tabIndex = -1;
  el.innerHTML = items.map((it, n) => it === 'sep' ? '<div class="sep" role="separator"></div>' : it.head ? `<div class="mh2">${esc2(it.head)}</div>` : it.check !== undefined ? `<label class="mi" role="menuitemcheckbox"><input type="checkbox" class="cb" data-mi="${n}" ${it.check ? 'checked' : ''}>${esc2(it.label)}</label>` : `<button type="button" class="mi ${it.danger ? 'danger' : ''}" role="menuitem" data-mi="${n}" ${it.tone ? `data-tone="${it.tone}"` : ''}>${ic(it.icon || 'circle-dot', 'i i-sm')}${it.desc ? `<span class="mi-t"><b>${esc2(it.label)}</b><small>${esc2(it.desc)}</small></span>` : esc2(it.label)}${it.k ? `<span class="k">${it.k}</span>` : ''}</button>`).join('');
  document.body.append(el); el.dataset.min = '230';
  POP = { el, btn, kind: 'menu' }; placePop(el, btn); btn.setAttribute('aria-expanded', 'true');
  const first = el.querySelector('button.mi, label.mi'); first?.focus();
  el.addEventListener('click', (e) => { const m = e.target.closest('[data-mi]'); if (!m) return; const it = items[+m.dataset.mi]; if (m.type === 'checkbox') { onPick(it, m.checked); return; } closePop(true); onPick(it); });
  el.addEventListener('keydown', (e) => { const list = [...el.querySelectorAll('button.mi, label.mi')], i = list.indexOf(document.activeElement.closest('.mi')); if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); list[(i + (e.key === 'ArrowDown' ? 1 : -1) + list.length) % list.length]?.focus(); } });
}
const toast = (msg, icon = 'check') => { $('.toast2')?.remove(); document.body.insertAdjacentHTML('beforeend', `<div class="toast2" role="status">${ic(icon, 'i i-sm')}<span>${msg}</span></div>`); setTimeout(() => $('.toast2')?.remove(), 2400); };

document.addEventListener('input', (e) => { const q = e.target.dataset?.tq; if (q && TBL[q]) { TBL[q].q = e.target.value; TBL[q].page = 1; tblDraw(q); } });
document.addEventListener('change', (e) => {
  const d = e.target.dataset || {};
  if (d.tall) { const T = TBL[d.tall]; const view = tblView(d.tall).slice((T.page - 1) * T.per, T.page * T.per); view.forEach(({ i }) => e.target.checked ? T.sel.add(i) : T.sel.delete(i)); tblDraw(d.tall); }
  if (d.tsel) { const [id, i] = d.tsel.split(':'); const T = TBL[id]; e.target.checked ? T.sel.add(+i) : T.sel.delete(+i); tblDraw(id); }
  if (d.tf) { const [id, i] = d.tf.split(':'); TBL[id].f[i] = e.target.checked ? 'نعم' : ''; tblDraw(id); }
});
document.addEventListener('pick', (e) => {
  const k = e.detail.key || '';
  if (k.startsWith('f:')) { const [, id, i] = k.split(':'); if (TBL[id]) { TBL[id].f[i] = e.detail.value; TBL[id].page = 1; tblDraw(id); } }
  if (k.startsWith('per:')) { const id = k.slice(4); if (TBL[id]) { TBL[id].per = numOf(e.detail.value) || 8; TBL[id].page = 1; tblDraw(id); } }
});
document.addEventListener('click', (e) => {
  const xp = e.target.closest('[data-texp]'); if (xp) { const [id, i] = xp.dataset.texp.split(':'); const T = TBL[id]; T.open.has(+i) ? T.open.delete(+i) : T.open.add(+i); return tblDraw(id); }
  const t = e.target.closest('[data-tsort], [data-tpage], [data-tclear], [data-tunf], [data-tnone], [data-tdens], [data-tmenu], [data-tbulk], [data-tseg] button');
  if (!t) return;
  const d = t.dataset;
  if (d.tsort) { const [id, k] = d.tsort.split(':'); const T = TBL[id]; T.sort = T.sort?.k === +k ? (T.sort.dir > 0 ? { k: +k, dir: -1 } : null) : { k: +k, dir: 1 }; return tblDraw(id); }
  if (d.tpage) { const [id, p] = d.tpage.split(':'); TBL[id].page = +p; tblDraw(id); return $('#' + id).scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
  if (d.tclear) { const T = TBL[d.tclear]; T.q = ''; T.f = {}; return tblRebar(d.tclear); }
  if (d.tunf) { const [id, k] = d.tunf.split(':'); const T = TBL[id]; if (k === 'q') { T.q = ''; $(`[data-tq="${id}"]`).value = ''; } else delete T.f[k]; return tblRebar(id); }
  if (d.tnone) { TBL[d.tnone].sel.clear(); return tblDraw(d.tnone); }
  if (d.tdens) { const T = TBL[d.tdens]; T.compact = !T.compact; toast(T.compact ? 'صفوف متقاربة' : 'صفوف مريحة', 'rows-3'); return tblDraw(d.tdens); }
  if (d.tbulk) { const T = TBL[d.tbulk]; toast(`${t.textContent.trim()}: ${T.sel.size} صفوف`); T.sel.clear(); return tblDraw(d.tbulk); }
  if (t.closest('[data-tseg]')) { const [id, i] = t.closest('[data-tseg]').dataset.tseg.split(':'); TBL[id].f[i] = t.closest('[data-tseg]').firstElementChild === t ? '' : t.dataset.v; return tblDraw(id); }
  if (d.tmenu) {
    e.stopPropagation(); if (POP?.btn === t) return closePop();
    const [kind, id, i] = d.tmenu.split(':'), T = TBL[id];
    if (kind === 'cols') return openMenu(t, [{ head: 'الأعمدة الظاهرة' }, ...T.cols.map((c, k) => ({ label: c.label, check: !T.hidden.has(k), k }))], (it, on) => { on ? T.hidden.delete(it.k) : T.hidden.add(it.k); tblDraw(id); });
    if (kind === 'exp') return openMenu(t, [{ label: 'Excel (xlsx)', icon: 'file-spreadsheet' }, { label: 'PDF', icon: 'file-text' }, { label: 'طباعة', icon: 'printer', k: 'Ctrl P' }], (it) => toast(`جارٍ التصدير: ${it.label}`, 'download'));
    if (kind === 'row') { const acts = T.spec.rowActions; const items = []; acts.forEach((a, n) => { if (/حذف/.test(a) && n && !/حذف/.test(acts[n - 1])) items.push('sep'); items.push({ label: a, icon: actIcon(a), tone: /حذف|تعديل/.test(a) ? null : txTone(a), danger: /حذف|قطع/.test(a) }); }); return openMenu(t, items, (it) => toast(it.label + ' — يفتح النافذة الخاصة به', it.icon)); }
  }
}, true);
function tblRebar(id) { const el = $('#' + id); const T = TBL[id]; el.innerHTML = tblShell(id); $(`[data-tq="${id}"]`).value = T.q; tblDraw(id); }
