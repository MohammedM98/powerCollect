
/* ═══════════ Pages, forms and confirmations drawn from the extracted specs (SPECS) ═══════════
   Every page/form/confirm in PowerCollect is described in specs/*.json (read from the real code).
   Pages with a bespoke design (dashboard, statement, cash boxes) override the generic list page. */
const SP = { pages: {}, forms: {}, confirms: [] };
(SPECS || []).forEach((f) => { (f.pages || []).forEach((p) => { SP.pages[p.id] = p; }); (f.forms || []).forEach((x) => { SP.forms[x.id] = x; }); (f.confirms || []).forEach((c) => SP.confirms.push(c)); });
const BESPOKE_FORMS = { payment: () => openPayment('خالد منصور'), subscription: openSubscriber, charge: () => openCharge('خالد منصور'), discount: () => openDiscount('خالد منصور'), split: openSplit, quickPay: openQuickPay };

/* Header buttons: money actions carry their tone; one solid main action per page. */
function actionBtn(a, i) {
  const label = clean(a.label || a), tone = txTone(label), opens = a.opens ? `data-form="${a.opens}"` : '';
  if (tone && tone !== 'reading') return toneBtn(esc2(label), tone, { solid: i === 0, attrs: opens });
  const icon = actIcon(label) === 'circle-dot' ? (/جديد|إضافة|إنشاء/.test(label) ? 'plus' : /Excel|تصدير|تنزيل/.test(label) ? 'download' : /طباعة/.test(label) ? 'printer' : 'circle-dot') : actIcon(label);
  return `<button type="button" class="btn ${i === 0 && a.kind !== 'secondary' ? 'btn-primary' : 'btn-secondary'}" ${opens}>${ic(icon, 'i i-sm')}${esc2(label)}</button>`;
}
function pageTabs(tabs) { return tabs?.length ? `<div class="tabs-scroll"><div class="seg" role="tablist">${tabs.map((t, i) => `<button type="button" role="tab" aria-pressed="${i === 0}">${esc2(clean(t))}</button>`).join('')}</div></div>` : ''; }
const clean = (x) => { const raw = typeof x === 'string' ? x : x?.label || ''; return ar(raw) || (/[A-Za-z]/.test(raw) ? ar(firstVariant(raw)) : firstVariant(raw)); };
function kpiStrip(kpis) { return kpis?.length ? `<div class="kpis">${kpis.map((k) => `<section class="card surf kpi"><small>${esc2(clean(k.label))}</small><b>${esc2(fill(k.example ?? '—'))}</b>${ar(k.note) ? `<span>${esc2(ar(k.note))}</span>` : ''}</section>`).join('')}</div>` : ''; }
function tableFrom(t, extra = {}) {
  if (!t?.columns?.length) return '';
  /* Columns with no user-facing name (selection boxes, technical keys) are dropped together with their data. */
  const keep = t.columns.map((c, i) => [c, i]).filter(([c]) => c.type === 'actions' || (ar(c.label) && !/checkbox/i.test(c.label)));
  return dataTable({ title: t.title && clean(t.title), columns: keep.map(([c]) => ({ ...c, label: ar(c.label) })), rows: (t.sampleRows || []).map((r) => keep.map(([, i]) => r[i])), rowActions: (t.rowActions || []).map(clean).filter(Boolean), bulkActions: t.bulkActions && t.bulkActions.map(clean).filter(Boolean), filters: (extra.filters || t.filters || []).map((f) => ({ ...f, label: clean(f.label), options: Array.isArray(f.options) ? f.options.map((o) => (typeof o === 'string' ? (ar(o) || fill(o)).replace(/ · /g, '، ') : o)) : f.options })), selectable: t.selectable !== false && (t.bulkActions?.length || t.selectable), empty: t.emptyText, totals: extra.totals, ...extra.o });
}
function listPage(p, s) {
  const acts = (s.headerActions || []).filter((a) => a.label);
  return `${header(p, clean(s.title) || p[1].replace(/ \(.*\)/, ''), ar(s.subtitle) || p[5])}${tabs(p)}
    ${acts.length ? `<div class="pills" data-part="أزرار الإجراءات">${acts.slice(0, 6).map(actionBtn).join('')}${acts.length > 6 ? `<button type="button" class="btn btn-secondary" data-more='${JSON.stringify(acts.slice(6).map((a) => a.label)).replace(/'/g, '&#39;')}'>${ic('ellipsis', 'i i-sm')}المزيد</button>` : ''}</div>` : ''}
    ${pageTabs(s.tabs)}${kpiStrip(s.kpis)}
    ${tableFrom(s.table, { filters: s.filters })}
    ${(s.tables || []).map((t) => tableFrom(t)).join('')}
    ${(() => { /* Only the on-screen Arabic names of the page's other blocks (the «…» text), never extraction notes. */
      const names = [...new Set((s.otherSections || []).map((o) => { const t = typeof o === 'string' ? o : o.title || ''; const m = t.match(/«([^»]{3,60})»/); return m && ar(m[1]) ? ar(m[1]) : ar(t).length && ar(t).length < 70 ? ar(t) : ''; }).filter(Boolean))];
      return names.length ? `<section class="card surf"><div class="card-h"><div><h3>أقسام أخرى في هذه الصفحة</h3><p class="muted" style="margin:2px 0 0;font-size:13px">تُبنى بنفس المكونات</p></div></div><div class="other-secs">${names.map((n) => `<div>${ic('layout-panel-top', 'i i-sm')}<span>${esc2(n)}</span></div>`).join('')}</div></section>` : ''; })()}
    ${formsOf(p)}`;
}
function formsOf(p) {
  const ids = (p[7] || []).filter((id) => SP.forms[id] || BESPOKE_FORMS[id]);
  return ids.length ? `<section class="card surf"><div class="card-h"><div><h3>النوافذ التي تفتح من هذه الصفحة</h3><p class="muted" style="margin:2px 0 0;font-size:13px">اضغط أي نافذة لمعاينتها</p></div><span class="chip2x st-default" style="margin-inline-start:auto">${ids.length}</span></div><div class="form-grid">${ids.map((id) => formCard(id)).join('')}</div></section>` : '';
}
function formCard(id) {
  const f = SP.forms[id] || { title: (FORMS[id] || [id])[0], sections: [] }, n = (f.sections || []).reduce((t, s) => t + (s.fields || []).length, 0);
  const tone = txTone(f.title || '');
  return `<button type="button" class="form-card" data-form="${id}" ${tone ? `data-tone="${tone}"` : ''}><span class="ic">${ic(tone ? TX_ICON[tone] : 'app-window', 'i i-sm')}</span><span><b>${esc2(clean((f.title || id).split(' / ')[0]) || (FORMS[id] || [id])[0].split(' / ')[0])}</b><small>${n ? `${n} حقل` : 'عرض'}${f.sections?.length > 1 ? `، ${f.sections.length} أقسام` : ''}${BESPOKE_FORMS[id] ? '، تصميم خاص' : ''}</small></span>${ic('chevron-left', 'i i-sm chev')}</button>`;
}

/* ── Generic form window: every field drawn with the matching HeroUI-style control ──
   Text shown to people is user-facing Arabic only: extraction notes (English, code conditions) never reach the screen,
   and {placeholders} become sample values. Every control is 48px, labels sit above, rows are 16px apart. */
const FIELD_ICON = { tel: 'phone', id: 'id-card', email: 'at-sign', password: 'lock', date: 'calendar', datetime: 'calendar-clock', time: 'clock', search: 'search', number: 'hash' };
const SAMPLE = { fullName: 'خالد منصور', display_name: 'سماح عودة', branch: 'الفرع الشمالي', title: '', x: '20', amount: '₪ 640.00', n: '12', 'عدد': '12', name: 'خالد منصور', 'اسم': 'خالد منصور', 'الاسم': 'خالد منصور', 'رقم': '14', noun: 'الفرع', 'السجل': 'الفرع', 'قارئ': 'أحمد سالم', 'المبلغ': '₪ 640.00', amount: '₪ 640.00' };
const fill = (s) => String(s ?? '').replace(/\{([^}]+)\}/g, (m, k) => SAMPLE[k.trim()] ?? '').replace(/[{}]/g, '');
const firstVariant = (s) => fill(String(s ?? '').split(' / ')[0]).trim();
/** User-facing Arabic only: drops parentheses holding Latin text and anything that reads like code. */
const ar = (s) => { const t = fill(String(s ?? '')).replace(/\([^)]*[A-Za-z][^)]*\)/g, '').replace(/\s{2,}/g, ' ').trim(); return /[A-Za-z_=<>]{2,}/.test(t.replace(/SMS|Excel|PDF|CSV|QR|ID|[A-Z]{2,4}-?\d*/g, '')) ? '' : t; };
function fieldHTML(fd, k) {
  if (!ar(fd.label) && /[A-Za-z]/.test(String(fd.label || ''))) return ''; /* hidden/technical inputs are not on screen */
  const long = String(ar(fd.label) || '').length > 42;
  const key = 'g' + k, lab = esc2(ar(fd.label) || firstVariant(fd.label)), req = fd.required ? ' <span class="req">*</span>' : '';
  const h = ar(fd.hint), hint = h ? `<span class="hint">${esc2(h)}</span>` : '';
  const opts = (Array.isArray(fd.options) ? fd.options.filter((o) => typeof o === 'string') : []).map((o) => ar(o) || o);
  const real = opts.length > 0 && !/from DB|من قاعدة|DB:|[A-Za-z]{4,}/.test(opts.join(' '));
  const unit = '';
  const lbl = `<label class="${long ? 'long' : ''}">${lab}${req}${unit}</label>`;
  const wrap = (inner, w = '') => `<div class="ff ${long ? 'w6' : w}">${inner}${hint}</div>`;
  const ph = esc2(ar(fd.placeholder) || '');
  switch (fd.type) {
    case 'textarea': return wrap(`${lbl}<div class="fc ta"><textarea placeholder="${ph}"></textarea></div>`, 'w6');
    case 'switch': { const on = /true|نعم|مفعّل|مفعل|1/.test(String(fd.default)); return wrap(`${lbl}<div class="fc sw-field"><label><span>${on ? 'مفعّل' : 'غير مفعّل'}</span><span class="lbl-sw"><input type="checkbox" ${on ? 'checked' : ''} data-gsw aria-label="${lab}"></span></label></div>`); }
    case 'checkbox': return (fd.label || '').length > 34 ? wrap(`<label class="ack"><input type="checkbox" class="cb" ${fd.default ? 'checked' : ''}><span>${lab}${req}</span></label>`, 'w6') : wrap(`<span class="flab" aria-hidden="true">&nbsp;</span><div class="fc cb-field"><label><input type="checkbox" class="cb" ${fd.default ? 'checked' : ''}><span>${lab}${req}</span></label></div>`);
    case 'segmented': case 'radio': if (real && opts.length <= 4) return wrap(`${lbl}<div class="seg fit">${opts.map((o, i) => `<button type="button" aria-pressed="${o === fd.default || (!fd.default && i === 0)}" data-gseg>${esc2(o)}</button>`).join('')}</div>`, 'w6');
    /* falls through to cards for longer option lists */
    case 'cards': if (real) return wrap(`${lbl}<div class="rcs" role="radiogroup">${opts.map((o, i) => { const t = txTone(o); return `<button type="button" class="rc" role="radio" aria-checked="${o === fd.default || (!fd.default && i === 0)}" data-gcard><span class="ic">${ic(t ? TX_ICON[t] : 'circle-dot', 'i i-sm')}</span><span><b>${esc2(o)}</b></span></button>`; }).join('')}</div>`, 'w6');
    /* falls through */
    case 'select': case 'combobox': return wrap(`${lbl}${pickBtn(key, real && opts.includes(fd.default) ? fd.default : '', real ? opts : ['الخيار الأول', 'الخيار الثاني', 'الخيار الثالث'], { icon: fd.type === 'combobox' ? 'search' : 'list', ph: 'اختر' })}`);
    case 'multiselect': case 'chips': return wrap(`${lbl}<div class="chips-pick">${(real ? opts : ['الخيار الأول', 'الخيار الثاني', 'الخيار الثالث']).map((o, i) => `<button type="button" aria-pressed="${i === 0}" data-gchip>${esc2(o)}</button>`).join('')}</div>`, 'w6');
    case 'date': case 'datetime': return wrap(`${lbl}${dateBtn(key, '2026-11-16')}`);
    case 'currency': return wrap(`${lbl}<div class="seg fit">${['₪ شيكل', '$ دولار', 'د.أ دينار', '€ يورو'].map((o, i) => `<button type="button" aria-pressed="${i === 0}" data-gseg>${o}</button>`).join('')}</div>`);
    case 'money': return wrap(`${lbl}<div class="fc"><input inputmode="decimal" placeholder="0.00" data-ltr aria-label="${lab}"><span class="addon">${esc2(fd.unit || '₪')}</span></div>`);
    case 'file': return wrap(`${lbl}<label class="drop">${ic('cloud-upload', 'i i-lg')}<b>اسحب الملف هنا أو اختره</b><small>${esc2(h || 'ملف Excel أو PDF أو صورة')}</small><input type="file" hidden></label>`, 'w6');
    case 'color': return wrap(`${lbl}<div class="swatches">${['#2A2D34', '#E2642A', '#3B82F6', '#16A34A', '#9333EA', '#DC2626'].map((c, i) => `<button type="button" style="background:${c}" aria-pressed="${i === 0}" aria-label="${c}"></button>`).join('')}</div>`);
    case 'readonly': return wrap(`${lbl}<div class="fc ro"><span class="ro-v">${esc2(ar(fd.default) || '—')}</span></div>`);
    case 'table': { const heads = String(fd.label || '').split(/\s*\/\s*|،\s*/).map((x) => ar(x) || x).filter(Boolean); const cols = heads.length > 1 ? heads : ['المشترك', 'المبلغ'];
      const sample = (h, r) => /مبلغ|المتوقع|الفرق|الرصيد|رسوم|عدّ|المحصّل|الإجمالي/.test(h) ? `₪ ${money([1240, 860, 0][r] + (/الفرق/.test(h) ? -[0, 20, 0][r] * 1 : 0))}` : /العملة/.test(h) ? ['شيكل', 'دولار', 'دينار'][r] : /القرار|الحالة/.test(h) ? chipStatus(['مطابق', 'عجز', 'مطابق'][r]) : /المشترك|الاسم/.test(h) ? NAMES[r] : /التاريخ/.test(h) ? `${14 + r}/11/2026` : ['—', '—', '—'][r];
      return wrap(`${heads.length > 1 ? '' : lbl}<div class="mini-tbl3"><table><thead><tr>${cols.map((c) => `<th>${esc2(c)}</th>`).join('')}</tr></thead><tbody>${[0, 1, 2].map((r) => `<tr>${cols.map((c) => `<td>${sample(c, r)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`, 'w6'); }
    default: {
      const t = ['id', 'tel', 'number'].includes(fd.type) ? 'data-ltr inputmode="numeric"' : fd.type === 'password' ? 'type="password"' : fd.type === 'email' ? 'type="email" data-ltr' : fd.type === 'time' ? 'type="time"' : '';
      return wrap(`${lbl}<div class="fc">${FIELD_ICON[fd.type] ? ic(FIELD_ICON[fd.type], 'i i-sm') : ''}<input ${t} placeholder="${ph}" aria-label="${lab}">${fd.unit ? `<span class="addon">${esc2(fd.unit)}</span>` : ''}</div>`);
    }
  }
}
function openForm(id) {
  if (BESPOKE_FORMS[id]) return BESPOKE_FORMS[id]();
  const f = SP.forms[id]; if (!f) return toast('هذه النافذة لم تُستخرج بعد', 'info');
  const title = firstVariant(f.title || id), tone = txTone(title), secs = (f.sections || []).filter((s) => s.fields?.length);
  let k = 0;
  const body = secs.length ? secs.map((s) => `<section class="gsec">${s.title && secs.length > 1 && ar(s.title) ? `<h4>${esc2(ar(s.title))}</h4>` : ''}<div class="fg">${s.fields.map((fd) => fieldHTML(fd, k++)).join('')}</div></section>`).join('')
    : `<div class="dt2-empty" style="padding:24px"><div class="ic">${ic('app-window', 'i i-lg')}</div><b>${esc2(title)}</b><p>نافذة عرض بلا حقول إدخال</p></div>`;
  const comp = (f.computed || []).map(ar).filter(Boolean);
  const compHTML = comp.length ? `<div class="effect"><small>يتحدّث أثناء الإدخال</small>${comp.map((c) => `<div class="kv"><span>${esc2(c)}</span><b class="n">—</b></div>`).join('')}</div>` : '';
  // Footer: cancel, then the main action; further variants of the action go into a menu so the footer never crowds.
  const btns = (f.buttons?.length ? f.buttons : [{ label: 'إلغاء', role: 'cancel' }, { label: 'حفظ', role: 'submit' }]).map((b) => ({ ...b, label: firstVariant(b.label) })).filter((b) => b.label);
  const cancel = btns.find((b) => b.role === 'cancel') || { label: 'إلغاء' };
  const mains = btns.filter((b) => b.role === 'submit' || b.role === 'danger'), extra = btns.filter((b) => b.role === 'secondary' || b.role === 'link');
  const main = mains[0], more = [...mains.slice(1), ...extra];
  const mainHTML = !main ? '' : /اضغط/.test(main.label) ? `<button type="button" class="btn btn-danger solid hold" data-hold><span class="fillbar"></span><span class="t">${ic('hand', 'i i-sm')}${esc2(main.label)}</span></button>`
    : main.role === 'danger' ? `<button type="button" class="btn btn-danger solid" data-act="g-submit">${ic('trash-2', 'i i-sm')}${esc2(main.label)}</button>`
    : tone && tone !== 'reading' ? toneBtn(esc2(main.label), tone, { solid: true, attrs: 'data-act="g-submit"' }) : `<button type="button" class="btn btn-primary" data-act="g-submit">${ic('check', 'i i-sm')}${esc2(main.label)}</button>`;
  const moreHTML = more.length ? `<button type="button" class="btn btn-secondary btn-icon" data-more='${JSON.stringify(more.map((b) => b.label)).replace(/'/g, '&#39;')}' aria-label="إجراءات أخرى" title="إجراءات أخرى">${ic('ellipsis', 'i')}</button>` : '';
  const size = f.size === 'sm' ? 'gsm' : f.size === 'xl' || f.size === 'full' || f.size === 'lg' ? 'glg' : '';
  const alt = (f.title || '').split(' / ').slice(1).map(ar).filter(Boolean);
  const sub = alt.length && alt.every((x) => /^تعديل/.test(x)) ? 'الإضافة والتعديل من النافذة نفسها' : alt.join('، ') || (f.steps?.length ? f.steps.map(ar).filter(Boolean).join('، ') : '');
  const el = mount(`md sheet-modal gform ${size}`, `<div class="mh"><span class="tile-ic" ${tone ? `data-tone="${tone}" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)"` : ''}>${ic(tone ? TX_ICON[tone] : actIcon(title) === 'circle-dot' ? 'app-window' : actIcon(title), 'i i-lg')}</span><div><h2>${esc2(title)}</h2>${sub ? `<p>${esc2(sub)}</p>` : ''}</div><div class="end">${closeBtn}</div></div><div class="mbody2">${body}${compHTML}</div><div class="mfoot"><span class="k"><span class="kbd">Esc</span> إغلاق</span><div class="end">${moreHTML}<button type="button" class="btn btn-secondary" data-act="close">${esc2(cancel.label)}</button>${mainHTML}</div></div>`);
  MO = { el, id: 'g-' + id, f: {}, discard: null };
}

/* ── Confirmations: tone-coloured; destructive ones ask for a press-and-hold ── */
function openConfirm(c) {
  const tone = c.tone || (/حذف|قطع|إغلاق|إلغاء/.test(c.title) ? 'danger' : /تجاهل|تراجع|إرجاع/.test(c.title) ? 'warning' : 'default');
  const hold = /اضغط/.test(c.title + (c.body || '')) || c.hold;
  const icon = { danger: 'triangle-alert', warning: 'circle-alert', default: 'circle-help' }[tone];
  const el = mount('sm cfm', `<div class="cfm-b"><span class="cfm-ic ${tone}">${ic(icon, 'i i-lg')}</span><h3>${esc2(c.title)}</h3>${c.body ? `<p>${esc2(c.body)}</p>` : ''}${c.requiresInput ? `<div class="fc" style="margin-top:4px"><input placeholder="${esc2(c.requiresInput)}"></div>` : ''}</div><div class="cfm-f"><button type="button" class="btn btn-secondary" data-act="close">${esc2(c.cancelLabel || 'إلغاء')}</button>${hold ? `<button type="button" class="btn ${tone === 'danger' ? 'btn-danger solid' : 'btn-primary'} hold" data-hold><span class="fillbar"></span><span class="t">${ic('hand', 'i i-sm')}${esc2(c.confirmLabel || 'اضغط مع الاستمرار')}</span></button>` : `<button type="button" class="btn ${tone === 'danger' ? 'btn-danger solid' : 'btn-primary'}" data-act="close">${esc2(c.confirmLabel || 'تأكيد')}</button>`}</div>`);
  MO = { el, id: 'confirm', discard: null };
}
let holdT = null;
document.addEventListener('pointerdown', (e) => { const b = e.target.closest('[data-hold]'); if (!b) return; b.classList.add('holding'); holdT = setTimeout(() => { b.classList.remove('holding'); closeModal(); toast('تم التأكيد'); }, 1600); });
['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => document.addEventListener(ev, () => { clearTimeout(holdT); $$('[data-hold].holding').forEach((b) => b.classList.remove('holding')); }, true));
document.addEventListener('click', (e) => {
  const f = e.target.closest('[data-form]'); if (f && !e.target.closest('.mback')) { e.preventDefault(); e.stopPropagation(); return openForm(f.dataset.form); }
  const c = e.target.closest('[data-confirm]'); if (c) { e.preventDefault(); e.stopPropagation(); return openConfirm(SP.confirms[+c.dataset.confirm]); }
  const m = e.target.closest('[data-more]'); if (m) { e.stopPropagation(); return openMenu(m, JSON.parse(m.dataset.more).map((l) => ({ label: l, icon: actIcon(l), tone: txTone(l) })), (it) => toast(it.label)); }
  const s = e.target.closest('[data-gseg]'); if (s) return $$('button', s.parentElement).forEach((b) => b.setAttribute('aria-pressed', String(b === s)));
  const r = e.target.closest('[data-gcard]'); if (r) return $$('.rc', r.parentElement).forEach((b) => b.setAttribute('aria-checked', String(b === r)));
  const ch = e.target.closest('[data-gchip]'); if (ch) return ch.setAttribute('aria-pressed', String(ch.getAttribute('aria-pressed') !== 'true'));
  if (e.target.closest('[data-act="g-submit"]')) { closeModal(); toast('تم الحفظ'); }
}, true);
