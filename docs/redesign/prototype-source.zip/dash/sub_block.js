/* ── 3. إنشاء مشترك — SubscriptionModal.jsx: five sections in one scrolling form, the side index follows the scroll ── */
const OB_SECTIONS = [['user', 'بيانات المشترك', 'الاسم والهوية والجوال والحالة'], ['gauge', 'نوع الاشتراك والقاطع', 'المحاسبة والتعرفة والقاطع والحد الأدنى'], ['map-pin', 'الموقع والعداد', 'الفرع والمنطقة والطبلون'], ['calendar-clock', 'معلومات الاشتراك', 'القراءة والرسوم والتاريخ'], ['notebook-pen', 'معلومات إضافية', 'العنوان وأي معلومة أخرى']];
const TARIFFS = [['house', 'منزلي', '1.50'], ['store', 'تجاري', '1.80']];
const BREAKERS = [['6', 20], ['10', 30], ['16', 45], ['20', 60], ['32', 90], ['63', 160]];
const BRANCH_AREA = { 'الفرع الشمالي': 'الشجاعية', 'الفرع الجنوبي': 'رفح', 'فرع الوسط': 'دير البلح', 'الفرع الشرقي': 'التفاح', 'الفرع الغربي': 'الدرج' };
const AREA_SUBS = { 'الشجاعية': ['حي الزيتون', 'السوق', 'المدرسة', 'الشجاعية الشرقية'], 'التفاح': ['التفاح'], 'الدرج': ['الدرج'], 'رفح': ['الصناعة'], 'دير البلح': ['الصناعة'] };
const BOXES = [['الطبلون 14', 'حي الزيتون', 38, 40], ['الطبلون 9', 'السوق', 41, 50], ['الطبلون 3', 'المدرسة', 29, 50], ['الطبلون 21', 'الصناعة', 33, 50], ['الطبلون 1', 'الشجاعية الشرقية', 47, 50], ['الطبلون 2', 'الشجاعية الشرقية', 22, 40], ['الطبلون 5', 'التفاح', 36, 50], ['الطبلون 7', 'التفاح', 49, 50], ['الطبلون 11', 'الدرج', 18, 40], ['الطبلون 12', 'الدرج', 30, 50], ['الطبلون 16', 'حي الزيتون', 44, 50], ['الطبلون 18', 'السوق', 12, 30]];
const breakerMin = (b) => (BREAKERS.find((x) => x[0] === b) || [, 30])[1];
const tariffRate = (t) => (TARIFFS.find((x) => x[1] === t) || [, , '1.50'])[2];
function openSubscriber() {
  const el = mount('ob', `<div class="ob-grid"><aside class="ob-side"><div class="mcard" id="mcard"></div><nav class="ob-nav" id="obNav" aria-label="أقسام النموذج"></nav><div class="hint" style="margin-top:auto">${ic('info', 'i i-sm')} يُنشأ رقم الحساب تلقائيًا عند الحفظ.</div></aside>
    <section class="ob-main"><div class="mh"><span class="tile-ic">${ic('user-plus', 'i i-lg')}</span><div><h2>إنشاء مشترك</h2><p>الحقول المعلّمة بـ <span class="req">*</span> مطلوبة</p></div><div class="end">${closeBtn}</div></div><div class="ob-body" id="obB"></div>
    <div class="mfoot"><div class="ob-prog" id="obProg"></div><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-primary" data-act="ob-save" id="obSave">${ic('check', 'i i-sm')}حفظ</button></div></div></section></div>`);
  MO = { el, id: 'subscriber', now: 0, touched: {}, tried: false, f: { status: 'قيد الانتظار', acct: 'أسبوعي', tariff: 'منزلي', brk: '10', seg: 'عادي', branch: 'الفرع الشمالي', sub: 'حي الزيتون', box: 'الطبلون 14', reading: '', date: '2026-11-16', fee: '150.00', feeOn: false, kwOpen: false, minOpen: false }, discard: 'تجاهل التغييرات؟' };
  obRender();
  [$('#obB'), $('.ob-grid', el)].forEach((n) => n.addEventListener('scroll', obSpy, { passive: true }));
  $('#obB [data-f="name"]').focus();
}
function obField(key, label, attrs = '', o = {}) {
  return `<div class="ff ${o.w || ''}"><${o.flab ? 'div class="flab"' : `label for="f-${key}"`}>${label}${o.req ? ' <span class="req">*</span>' : ''}${o.opt ? ' <span class="opt">اختياري</span>' : ''}${o.flab || ''}</${o.flab ? 'div' : 'label'}><div class="fc ${o.cls || ''}" id="fc-${key}">${o.icon ? ic(o.icon, 'i i-sm') : ''}<input id="f-${key}" data-f="${key}" value="${esc2(MO.f[key] ?? '')}" ${attrs}>${o.addon ? `<span class="addon">${o.addon}</span>` : ''}</div>${o.hint !== undefined ? `<span class="hint" id="h-${key}">${o.hint}</span>` : ''}</div>`;
}
const obPick = (key, label, opts, o = {}) => `<div class="ff ${o.w || ''}"><label>${label}${o.req ? ' <span class="req">*</span>' : ''}</label>${pickBtn(key, MO.f[key], opts, { icon: o.icon })}${o.hint ? `<span class="hint">${o.hint}</span>` : ''}</div>`;
const obHead = (i) => { const [icon, t, d] = OB_SECTIONS[i]; return `<header class="obs-h"><span class="ic">${ic(icon, 'i i-sm')}</span><div><h3>${t}</h3><p>${d}</p></div></header>`; };
const lockLink = (act, label) => `<button type="button" class="lbl-act" data-act="${act}">${ic('lock-open', 'i i-sm')}${label}</button>`;
function obRender() {
  const f = MO.f, area = BRANCH_AREA[f.branch] || '', subs = AREA_SUBS[area] || [];
  const boxes = BOXES.filter((b) => !f.sub || b[1] === f.sub); const boxList = boxes.length ? boxes : BOXES;
  $('#obB').innerHTML = `
    <section class="obs" id="obs-0">${obHead(0)}<div class="fg">
      ${obField('name', 'الاسم', 'placeholder="الاسم الرباعي كما في الهوية" autocomplete="off"', { req: 1, w: 'w6', icon: 'user', hint: '' })}
      ${obField('nid', 'رقم الهوية', 'inputmode="numeric" maxlength="9" placeholder="9 أرقام" data-ltr', { icon: 'id-card', hint: '' })}
      ${obField('phone', 'رقم الجوال', 'inputmode="tel" maxlength="12" placeholder="059 XXX XXXX" data-ltr', { icon: 'phone', hint: '' })}
      <div class="ff w6"><label>الحالة <span class="req">*</span></label><div class="seg fit">${['نشط', 'قيد الانتظار', 'مفصول'].map((x) => `<button type="button" aria-pressed="${f.status === x}" data-act="ob-pick" data-k="status" data-v="${x}">${x}</button>`).join('')}</div><span class="hint" id="h-status"></span></div></div></section>
    <section class="obs" id="obs-1">${obHead(1)}<div class="fg">
      <div class="ff w6"><label>نوع المحاسبة</label><div class="seg fit">${['أسبوعي', 'شهري'].map((x) => `<button type="button" aria-pressed="${f.acct === x}" data-act="ob-pick" data-k="acct" data-v="${x}">${x}</button>`).join('')}</div></div>
      <div class="ff w6"><label>نوع الاشتراك <span class="req">*</span></label><div class="rcs" role="radiogroup">${TARIFFS.map(([i, n, r]) => `<button class="rc" type="button" role="radio" aria-checked="${f.tariff === n}" data-act="ob-pick" data-k="tariff" data-v="${n}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${n}</b><small class="n">${r} ش/ك.و</small></span></button>`).join('')}</div></div>
      ${obField('kw', 'سعر الكيلو', 'inputmode="decimal" data-ltr', { addon: '₪', cls: 'ro', flab: lockLink('ob-kw-open', 'تعديل السعر'), hint: '' })}
      ${obPick('seg', 'تصنيف الزبائن', ['عادي', 'موظفو أبو زايد', 'مؤسسات'], { icon: 'tags' })}
      <div class="ff w6"><label>القاطع</label><div class="chips-pick tall">${BREAKERS.map(([a, m]) => `<button type="button" aria-pressed="${f.brk === a}" data-act="ob-pick" data-k="brk" data-v="${a}">${a} أمبير<small>الحد الأدنى ${m} ش</small></button>`).join('')}</div></div>
      ${obField('min', 'الحد الأدنى', 'inputmode="decimal" data-ltr', { req: 1, addon: '₪', cls: 'ro', flab: lockLink('ob-min-open', 'تعديل يدوي'), hint: '' })}</div></section>
    <section class="obs" id="obs-2">${obHead(2)}<div class="fg">
      ${obPick('branch', 'الفرع', Object.keys(BRANCH_AREA), { req: 1, w: 'w2', icon: 'building-2', hint: 'تغيير الفرع يمسح منطقة 2 والطبلون' })}
      <div class="ff w2"><label>المنطقة</label><div class="fc ro">${ic('lock', 'i i-sm')}<span class="ro-v" style="font-family:var(--f-body)">${area || 'اختر فرعًا أولاً لعرض منطقته.'}</span></div><span class="hint">للقراءة فقط، من الفرع</span></div>
      ${subs.length ? obPick('sub', 'منطقة 2', subs, { w: 'w2', icon: 'map-pinned' }) : `<div class="ff w2"><label>منطقة 2</label><div class="fc ro"><span class="ro-v" style="font-family:var(--f-body);font-weight:500;color:var(--muted)">لا توجد منطقة 2 في هذه المنطقة بعد.</span></div></div>`}
      <div class="ff w6"><label>الطبلون (الاسم والرقم)</label>${richBtn('box', f.box, { icon: 'network', label: 'الطبلون', ph: 'اختر الطبلون', search: 'بحث عن طبلون...', opts: boxList.map(([n, a, used, cap]) => ({ v: n, t: n, sub: a, used, cap })) })}</div></div></section>
    <section class="obs" id="obs-3">${obHead(3)}<div class="fg">
      ${obField('reading', 'القراءة السابقة', 'inputmode="numeric" data-ltr', { w: 'w2', addon: 'ك.و', hint: '' })}
      <div class="ff w2"><label>تاريخ الاشتراك</label>${dateBtn('date', f.date)}</div>
      ${obField('fee', 'رسوم الاشتراك', 'inputmode="decimal" data-ltr', { w: 'w2', addon: '₪', cls: 'ro', flab: `<label class="lbl-sw"><input type="checkbox" data-f="feeOn" ${f.feeOn ? 'checked' : ''}>تحميل رسوم اشتراك</label>`, hint: '' })}</div></section>
    <section class="obs" id="obs-4">${obHead(4)}<div class="fg">
      <div class="ff w6"><label for="f-address">العنوان <span class="opt">اختياري</span></label><div class="fc ta"><textarea id="f-address" data-f="address" placeholder="الحي، الشارع، علامة مميزة">${esc2(f.address || '')}</textarea></div></div>
      <div class="ff w6"><label for="f-other">معلومات أخرى <span class="opt">اختياري</span></label><div class="fc ta"><textarea id="f-other" data-f="other" placeholder="أي معلومة تفيد المحصّل">${esc2(f.other || '')}</textarea></div></div></div></section>`;
  obSync();
}
/** Rules from the form itself: name required; ID 9 digits; mobile 10 digits starting 059 or 056; previous reading when active; minimum when unlocked. */
function obErrors() {
  const f = MO.f, e = {}, phone = (f.phone || '').replace(/\s/g, '');
  if (!(f.name || '').trim()) e.name = 'اكتب اسم المشترك';
  if (f.nid && !/^\d{9}$/.test(f.nid)) e.nid = 'رقم الهوية يجب أن يتكون من 9 أرقام';
  if (phone && !/^05[96]\d{7}$/.test(phone)) e.phone = 'رقم الجوال يجب أن يتكون من 10 أرقام ويبدأ بـ 059 أو 056';
  if (f.status === 'نشط' && !String(f.reading).trim()) e.reading = 'أدخل القراءة السابقة للعدّاد';
  if (f.minOpen && !(num(f.min) > 0)) e.min = 'أدخل الحد الأدنى';
  if (f.feeOn && !(num(f.fee) > 0)) e.fee = 'أدخل رسوم الاشتراك';
  return e;
}
const OB_OF = { name: 0, nid: 0, phone: 0, min: 1, reading: 3, fee: 3 };
const OB_HINT = { name: 'يمكنك إضافة وصف إلى الاسم مثل: محمد حمدان، المنزل.', nid: 'إن كانت الهوية مسجلة يُربط الاشتراك بنفس ملف المشترك', phone: 'للتذكيرات والوصل' };
function obSync() {
  const f = MO.f, err = obErrors(), show = (k) => err[k] && (MO.tried || MO.touched[k]);
  ['name', 'nid', 'phone'].forEach((k) => { const h = $('#h-' + k); $('#fc-' + k).classList.toggle('err', !!show(k)); $('#f-' + k).setAttribute('aria-invalid', String(!!show(k))); h.className = 'hint ' + (show(k) ? 'bad' : k === 'nid' && f.nid && !err.nid ? 'ok' : ''); h.textContent = show(k) ? err[k] : k === 'nid' && f.nid && !err.nid ? '✓ لا يوجد مشترك بنفس الهوية' : OB_HINT[k]; });
  $('#h-status').textContent = f.status === 'نشط' ? 'عند التفعيل أدخل القراءة السابقة للعدّاد، منها يبدأ حساب الاستهلاك.' : '';
  // Price per kWh and minimum: read-only from the tariff and breaker until unlocked (each asks for confirmation).
  const kw = $('[data-f="kw"]'); kw.disabled = !f.kwOpen; if (!f.kwOpen) { f.kw = tariffRate(f.tariff); kw.value = f.kw; } $('#fc-kw').classList.toggle('ro', !f.kwOpen);
  $('#h-kw').textContent = f.kwOpen ? 'سعر خاص بهذا المشترك' : `من التعرفة: ${tariffRate(f.tariff)} ش/ك.و`; $('[data-act="ob-kw-open"]').hidden = f.kwOpen;
  const mi = $('[data-f="min"]'); mi.disabled = !f.minOpen; if (!f.minOpen) { f.min = breakerMin(f.brk).toFixed(2); mi.value = f.min; } $('#fc-min').classList.toggle('ro', !f.minOpen); $('#fc-min').classList.toggle('err', !!show('min'));
  $('#h-min').className = 'hint ' + (show('min') ? 'bad' : ''); $('#h-min').textContent = show('min') ? err.min : f.minOpen ? 'حد أدنى خاص بهذا المشترك' : `من القاطع ${f.brk} أمبير`; $('[data-act="ob-min-open"]').hidden = f.minOpen;
  const rd = $('[data-f="reading"]'), active = f.status === 'نشط'; rd.disabled = !active; $('#fc-reading').classList.toggle('ro', !active); $('#fc-reading').classList.toggle('err', !!show('reading'));
  $('#h-reading').className = 'hint ' + (show('reading') ? 'bad' : ''); $('#h-reading').textContent = show('reading') ? err.reading : active ? 'منها يبدأ حساب الاستهلاك.' : 'تُدخل القراءة عند تفعيل المشترك، منها يبدأ حساب استهلاكه.';
  const fe = $('[data-f="fee"]'); fe.disabled = !f.feeOn; $('#fc-fee').classList.toggle('ro', !f.feeOn); $('#fc-fee').classList.toggle('err', !!show('fee'));
  $('#h-fee').className = 'hint ' + (show('fee') ? 'bad' : ''); $('#h-fee').textContent = show('fee') ? err.fee : f.feeOn ? 'تُضاف رسوم الاشتراك إلى الرصيد وسجل المعاملات عند حفظ المشترك.' : 'لن تُضاف الرسوم إلى الرصيد. يمكنك تحميلها لاحقًا من سجل المعاملات.';
  const bad = new Set(Object.keys(err).map((k) => OB_OF[k])), done = OB_SECTIONS.map((_, i) => !bad.has(i) && (i !== 0 || !!(f.name || '').trim()));
  $('#obNav').innerHTML = OB_SECTIONS.map(([icon, t, d], i) => `<button type="button" data-act="ob-go" data-i="${i}" aria-current="${i === MO.now}"><span class="ic">${ic(icon, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span><span class="st2 ${MO.tried && bad.has(i) ? 'bad' : done[i] ? 'ok' : ''}" aria-label="${done[i] ? 'مكتمل' : 'غير مكتمل'}">${done[i] ? ic('check', 'i') : ''}</span></button>`).join('');
  const n = done.filter(Boolean).length;
  $('#obProg').innerHTML = `<span class="bar"><i style="width:${n / OB_SECTIONS.length * 100}%;${n === OB_SECTIONS.length ? 'background:var(--success)' : ''}"></i></span><span><b>${n}</b> من ${OB_SECTIONS.length} أقسام مكتملة</span>`;
  obCard();
  MO.dirty = !!(f.name || f.nid || f.phone || f.address || f.other);
}
/** The form scrolls in its own column on desktop and as one column with the side panel on phones. */
const obScroller = () => (getComputedStyle($('#obB')).overflowY === 'auto' ? $('#obB') : $('.ob-grid', MO.el));
function obSpy() {
  const b = obScroller(), top = (b === $('#obB') ? b.getBoundingClientRect().top : innerHeight * .35) + 96;
  let now = 0; $$('.obs', MO.el).forEach((s, i) => { if (s.getBoundingClientRect().top <= top) now = i; });
  if (b.scrollTop + b.clientHeight >= b.scrollHeight - 4) now = OB_SECTIONS.length - 1;
  if (now !== MO.now) { MO.now = now; $$('#obNav button').forEach((x, i) => x.setAttribute('aria-current', String(i === now))); }
}
function obSave() {
  MO.tried = true; const err = obErrors(); obSync();
  const first = ['name', 'nid', 'phone', 'min', 'reading', 'fee'].find((k) => err[k]);
  if (first) { const inp = $(`[data-f="${first}"]`); inp.closest('.ff').scrollIntoView({ block: 'center' }); inp.focus({ preventScroll: true }); return; }
  sheet(`<div class="cf"><div class="ic">${ic('user-plus', 'i i-lg')}</div></div><h3>إضافة السجل؟</h3><p>سيتم إضافة سجل جديد بالبيانات التي أدخلتها. هل تريد المتابعة؟</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">مراجعة البيانات</button><button class="btn btn-primary" data-act="ob-done">${ic('check', 'i i-sm')}نعم، أضف</button></div>`);
}
function obCard() {
  const f = MO.f;
  $('#mcard').innerHTML = `<div class="top2"><span class="mc-mark">${MA}</span><span class="chip2">${f.status}</span></div><div class="nm">${esc2(f.name) || '<span style="opacity:.7">مشترك جديد</span>'}</div><div class="acc">${esc2(f.phone) || '05— ——— ——'}</div><div class="tags2"><span>${f.tariff}، ${f.kwOpen && f.kw ? f.kw : tariffRate(f.tariff)} ش/ك.و</span><span>قاطع ${f.brk} أمبير</span><span>${f.box}</span></div>`;
}

/* Unlocking price per kWh / minimum, branch changes, saving — exact confirmation texts from SubscriptionTariffSection.jsx. */
const OB_UNLOCK = { 'ob-kw-open': ['kwOpen', 'kw', 'تعديل سعر الكيلو لهذا المشترك؟', () => `سيصبح لهذا المشترك سعر كيلو خاص به بدل سعر التعرفة (${tariffRate(MO.f.tariff)} شيكل)، ويُحسب به استهلاكه وخصوماته في القراءات القادمة. هل تريد المتابعة؟`], 'ob-min-open': ['minOpen', 'min', 'تعديل الحد الأدنى يدويًا؟', () => 'أنت على وشك تعديل الحد الأدنى لهذا المشترك يدويًا بدل القيمة المأخوذة من القاطع. هل تريد المتابعة؟'] };
document.addEventListener('click', (e) => {
  if (MO?.id !== 'subscriber') return;
  const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act;
  if (OB_UNLOCK[act]) { const [flag, key, t, body] = OB_UNLOCK[act]; MO.pendingUnlock = [flag, key]; return sheet(`<div class="cf"><div class="ic warn">${ic('lock-open', 'i i-lg')}</div></div><h3>${t}</h3><p>${body()}</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">إلغاء</button><button class="btn btn-primary" data-act="ob-unlock">نعم، عدّل</button></div>`); }
  if (act === 'ob-unlock') { const [flag, key] = MO.pendingUnlock; MO.f[flag] = true; MO.sheet = false; $('.sheet-host', MO.el).innerHTML = ''; obSync(); return $(`[data-f="${key}"]`).focus(); }
  if (act === 'ob-done') return success('تمت إضافة المشترك', '', `${MO.f.name}، رقم الحساب 202600412، ${MO.f.box}`, `<button class="btn btn-primary" data-act="close">${ic('file-text', 'i i-sm')}فتح الكشف</button><button class="btn btn-tone" data-tone="pay" data-act="close">${ic('hand-coins', 'i i-sm')}تسجيل دفعة</button><button class="btn btn-ghost" data-act="again-sub">${ic('user-plus', 'i i-sm')}مشترك آخر</button>`);
});
document.addEventListener('pick', (e) => {
  if (MO?.id !== 'subscriber') return; const k = e.detail.key;
  if (k === 'branch' || k === 'sub') {
    const f = MO.f; f[k] = e.detail.value; if (k === 'branch') { const subs = AREA_SUBS[BRANCH_AREA[f.branch]] || []; f.sub = subs[0] || ''; }
    const boxes = BOXES.filter((b) => b[1] === f.sub); f.box = (boxes[0] || BOXES[0])[0];
    const sc = obScroller(), y = sc.scrollTop; obRender(); sc.scrollTop = y;
  }
});
