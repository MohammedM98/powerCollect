
/* ── الصناديق المالية — BranchCashBoxes.jsx (branch staff, managers, auditors) ── */
const BOX_TYPES = { cash: ['الصندوق النقدي', 'نقدي', 'banknote', 'pay'], bank: ['صندوق الحوالات البنكية', 'حوالات بنكية', 'landmark', 'split'], clear: ['صندوق المقاصات', 'مقاصة', 'arrow-left-right', 'clearing'] };
const CBOXES = [
  // [no, type, owner, entries, cancelled, ils, usd, jod, opened, closed, closedBy, audited, state]
  ['2026-0142', 'cash', 'سامي النجار', 38, 1, 5420, 50, 0, '15/11 08:10', '', '', '', 'open'],
  ['2026-0143', 'bank', 'رائد قديح (أنت)', 12, 0, 3180, 0, 0, '15/11 09:00', '', '', '', 'open'],
  ['2026-0144', 'cash', 'منى الفرا', 41, 2, 4960, 0, 120, '15/11 08:30', '', '', '', 'open'],
  ['2026-0145', 'clear', 'سامي النجار', 4, 0, 260, 0, 0, '15/11 10:40', '', '', '', 'open'],
  ['2026-0146', 'bank', 'منى الفرا', 9, 0, 2100, 0, 0, '16/11 08:05', '', '', '', 'open'],
  ['2026-0147', 'clear', 'أحمد شعث', 3, 0, 180, 0, 0, '16/11 09:20', '', '', '', 'open'],
  ['2026-0131', 'bank', 'منى الفرا', 20, 0, 4600, 0, 0, '8/11', '14/11 17:20', 'أحمد شعث', '', 'review'],
  ['2026-0129', 'clear', 'سامي النجار', 4, 0, 260, 0, 0, '8/11', '14/11 16:05', 'أحمد شعث', '16/11', 'audited'],
  ['2026-0127', 'cash', 'رائد قديح (أنت)', 52, 3, 6180, 100, 0, '8/11', '14/11 15:40', 'أحمد شعث', '16/11', 'audited'],
  ['2026-0125', 'cash', 'منى الفرا', 33, 0, 3920, 0, 0, '8/11', '14/11 15:10', 'أحمد شعث', '', 'review'],
];
const CB = { tab: 'open', type: '', view: 'table', q: '', owner: '', audit: '', space: 'boxes' };
function cbBoxes() {
  let list = CBOXES.filter((b) => CB.tab === 'open' ? b[12] === 'open' : b[12] !== 'open');
  if (CB.type) list = list.filter((b) => b[1] === CB.type);
  if (CB.owner && CB.owner !== 'كل الموظفين') list = list.filter((b) => b[2].startsWith(CB.owner));
  if (CB.audit === 'بانتظار التدقيق') list = list.filter((b) => b[12] === 'review'); if (CB.audit === 'تم التدقيق') list = list.filter((b) => b[12] === 'audited');
  if (CB.q) list = list.filter((b) => b.join(' ').includes(CB.q));
  return list;
}
const cbState = (b) => b[12] === 'open' ? '<span class="chip2x st-default cb-open"><span class="dot"></span>مفتوح</span>' : `<span class="chip2x st-success"><span class="dot"></span>مُغلق</span>${b[12] === 'audited' ? chipStatus('معتمد تدقيقيًا') : '<span class="chip2x st-warning"><span class="dot"></span>قيد التدقيق</span>'}`;
const cbMoney = (b) => `<span class="mv" dir="ltr">${money(b[5])}</span> <small>شيكل</small>${b[6] || b[7] ? `<small class="fx">و${[b[6] ? `${b[6]} دولار` : '', b[7] ? `${b[7]} دينار` : ''].filter(Boolean).join('، ')}</small>` : ''}`;
const cbEntries = (b) => `${b[3]} حركة${b[4] ? `، ${b[4]} ملغاة` : ''}<small>${b[1] === 'cash' ? (b[6] || b[7] ? 'بعضها بعملة أجنبية' : 'نقد بالشيكل') : b[1] === 'bank' ? 'يدقّقها قسم التدقيق بعد الإغلاق' : 'مقاصات على حسابات المشتركين'}</small>`;
const cbTimes = (b) => `<small>فُتح ${b[8]}</small><small>${b[9] ? `أُغلق ${b[9]}، ${b[10]}` : 'لم يُغلق بعد'}</small>${b[11] ? `<small class="ok">اعتُمد التدقيق ${b[11]}</small>` : ''}`;
const cbAct = (b) => b[12] === 'open' ? `<button type="button" class="btn btn-outline btn-sm" data-form="boxDetails">${ic('lock', 'i i-sm')}مراجعة وإغلاق</button>` : `<button type="button" class="btn btn-secondary btn-sm" data-form="boxDetails">${ic('eye', 'i i-sm')}عرض الصندوق</button>`;
const CB_OPEN = new Set();
/** Calm box table: box · employee · entries · total · status · one quiet action; times and notes live in the detail row. */
function cbTable(list) {
  return `<div class="dt2-scroll"><table class="cb-table"><thead><tr><th class="st-x"><span class="sr-only">تفاصيل</span></th>${['الصندوق', 'الموظف', 'الحركات', 'الإجمالي', 'الحالة'].map((h, i) => `<th class="${i === 3 ? 'c-money' : ''}">${h}</th>`).join('')}<th class="c-act"><span class="sr-only">إجراء</span></th></tr></thead><tbody>${list.map((b) => {
    const [, l1, icn, tone] = BOX_TYPES[b[1]], open = CB_OPEN.has(b[0]);
    return `<tr class="${open ? 'open' : ''}"><td class="st-x"><button type="button" class="exp" data-cbexp="${b[0]}" aria-expanded="${open}" aria-label="تفاصيل صندوق ${b[0]}">${ic('chevron-down', 'i i-sm')}</button></td>
      <td><span class="cb-type" data-tone="${tone}"><span class="ic">${ic(icn, 'i i-sm')}<span class="sd ${b[12] === 'open' ? 'open' : 'closed'}"></span></span><span><button type="button" class="cb-no" data-form="boxDetails" aria-label="عرض صندوق ${b[0]}">${b[0]}</button><small>${l1}</small></span></span></td>
      <td><div class="who2"><span class="av3">${b[2][0]}</span><b>${b[2]}</b></div></td>
      <td class="cb-n"><b class="n">${b[3]}</b> حركة${b[4] ? `<small>${b[4]} ملغاة</small>` : ''}</td>
      <td class="c-money"><span class="mv" dir="ltr">${money(b[5])}</span>${b[6] || b[7] ? `<small>و${[b[6] ? `${b[6]} دولار` : '', b[7] ? `${b[7]} دينار` : ''].filter(Boolean).join('، ')}</small>` : ''}</td>
      <td><div class="cb-st">${cbState(b)}</div></td><td class="c-act" style="width:auto">${cbAct(b)}</td></tr>
      ${open ? `<tr class="st-detail"><td></td><td colspan="6"><dl>${[['فُتح', b[8]], ['أُغلق', b[9] ? `${b[9]}، ${b[10]}` : 'لم يُغلق بعد'], ['اعتماد التدقيق', b[11] || '—'], ['نوع الحركات', b[1] === 'cash' ? (b[6] || b[7] ? 'بعضها بعملة أجنبية' : 'نقد بالشيكل') : b[1] === 'bank' ? 'يدقّقها قسم التدقيق بعد الإغلاق' : 'مقاصات على حسابات المشتركين'], ['الحركات الملغاة', String(b[4])]].map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl></td></tr>` : ''}`; }).join('')}</tbody></table></div>`;
}
document.addEventListener('click', (e) => { const x = e.target.closest('[data-cbexp]'); if (!x) return; const k = x.dataset.cbexp; CB_OPEN.has(k) ? CB_OPEN.delete(k) : CB_OPEN.add(k); cbDraw(); });
function cbDraw() {
  const list = cbBoxes(), el = $('#cbList'); if (!el) return;
  const tot = list.reduce((t, b) => [t[0] + b[5], t[1] + b[6], t[2] + b[7]], [0, 0, 0]);
  el.innerHTML = !list.length ? `<div class="dt2-empty"><div class="ic">${ic('archive', 'i i-lg')}</div><b>لا توجد صناديق مطابقة</b><p>تُفتح الصناديق تلقائيًا عند تسجيل أول دفعة أو مقاصة في الفرع، وتُضاف كل حركة إلى صندوق الموظف حسب نوعها.</p></div>`
    : CB.view === 'table' ? cbTable(list)
    : `<div class="cb-cards">${list.map((b) => { const [, l1, icn, tone] = BOX_TYPES[b[1]]; return `<article class="cb-card"><header><span class="cb-type" data-tone="${tone}"><span class="ic">${ic(icn, 'i i-sm')}<span class="sd ${b[12] === 'open' ? 'open' : 'closed'}"></span></span></span><div><b>صندوق ${b[0]}</b><small>${l1}، أسبوع 9–15 تشرين الثاني</small></div></header><div class="own"><span class="av3">${b[2][0]}</span><span>${b[2]}، ${b[3]} حركة</span></div><div class="amt"><small>إجمالي الحركات السارية</small><b class="n">₪ ${money(b[5])}</b>${b[6] || b[7] ? `<small>و${[b[6] ? `${b[6]} دولار` : '', b[7] ? `${b[7]} دينار` : ''].filter(Boolean).join('، ')}</small>` : ''}</div><footer><div class="cb-st">${cbState(b)}</div><small>${b[9] ? `أُغلق ${b[9]}` : `فُتح ${b[8]}`}</small></footer>${cbAct(b).replace('btn-sm', 'btn-sm cb-full')}</article>`; }).join('')}</div>`;
  $('#cbTotals').innerHTML = `<span>المعروض <b>${list.length}</b> من <b>${CBOXES.filter((b) => CB.tab === 'open' ? b[12] === 'open' : b[12] !== 'open').length}</b> صندوقًا</span><span class="grow"></span><span>مجموع الصناديق المعروضة: <b>${money(tot[0])}</b> شيكل${tot[1] ? `، <b>${tot[1]}</b> دولار` : ''}${tot[2] ? `، <b>${tot[2]}</b> دينار` : ''}</span>`;
  $$('[data-cbtype]').forEach((t) => t.setAttribute('aria-pressed', String(t.dataset.cbtype === CB.type)));
}
VIEWS['cash-boxes'] = (p) => {
  const open = CBOXES.filter((b) => b[12] === 'open'), closed = CBOXES.filter((b) => b[12] !== 'open');
  const src = CB.tab === 'open' ? open : closed, audited = closed.filter((b) => b[12] === 'audited').length;
  const tile = (k) => { const [l, , icn, tone] = BOX_TYPES[k], bs = src.filter((b) => b[1] === k); return `<button type="button" class="card surf cb-tile" data-cbtype="${k}" aria-pressed="false" data-tone="${tone}"><span class="ic">${ic(icn, 'i')}</span><small>${l}</small><b class="n">₪ ${money(bs.reduce((t, b) => t + b[5], 0))}</b><span>${bs.length} ${CB.tab === 'open' ? 'صناديق مفتوحة' : 'صناديق مغلقة في الفترة'}</span></button>`; };
  setTimeout(cbDraw, 0);
  return `${header(p, 'الصناديق المالية', 'الفرع الشمالي')}${tabs(p)}
    <div class="cb-top"><div class="seg cb-tabs" role="tablist">${[['entries', 'الحركات', 128], ['open', 'الصناديق المفتوحة', open.length], ['closed', 'الصناديق المغلقة', closed.length]].map(([k, l, n]) => `<button type="button" role="tab" aria-pressed="${CB.tab === k}" data-cbtab="${k}">${l} <span class="cnt2">${n}</span></button>`).join('')}</div>
      <p class="muted cb-info">${CB.tab === 'open' ? 'صناديق المحصّلين التي ما زالت تستقبل حركات. راجع الصندوق وأكّد إغلاقه فينتقل إلى «المغلقة».' : 'كل الصناديق المغلقة متاحة للتدقيق تلقائيًا. اختر الفترة الأسبوعية لعرض الصناديق حسب تاريخ إغلاقها.'}</p></div>
    ${CB.tab === 'closed' ? `<section class="card surf cb-period"><span class="ic">${ic('calendar-range', 'i')}</span><div><b>فترة الصناديق المغلقة</b><p>دُقّق ${audited} من ${closed.length} صندوقًا في الفترة المختارة.</p></div>${audited === closed.length ? chipStatus('اكتمل تدقيق الفترة') : '<span class="chip2x st-warning"><span class="dot"></span>لم يكتمل تدقيق الفترة</span>'}<span class="grow"></span>${pickBtn('cbPeriod', '8 تشرين الثاني — 14 تشرين الثاني', ['8 تشرين الثاني — 14 تشرين الثاني', '1 تشرين الثاني — 7 تشرين الثاني', '25 تشرين الأول — 31 تشرين الأول'], { cls: 'select', icon: 'calendar' })}<button type="button" class="btn btn-primary" data-form="auditApproval">${ic('badge-check', 'i i-sm')}اعتماد الفترة كاملة</button></section>
      <div class="seg" role="tablist" aria-label="مساحة التدقيق" style="align-self:flex-start"><button type="button" aria-pressed="true">الصناديق</button><button type="button" aria-pressed="false" data-form="auditTransferSearch">البحث عن حوالة</button></div>` : ''}
    <div class="cb-tiles">${['cash', 'bank', 'clear'].map(tile).join('')}</div>
    <section class="card surf dt2"><div class="dt2-bar"><label class="dt2-search">${ic('search', 'i i-sm')}<input id="cbQ" placeholder="ابحث بالصندوق أو المشترك أو السند أو مرجع الحوالة" aria-label="بحث"></label>
      ${pickBtn('cbOwner', '', ['كل الموظفين', 'سامي النجار', 'رائد قديح', 'منى الفرا', 'أحمد شعث'], { cls: 'select', icon: 'user', ph: 'الموظف' })}
      ${pickBtn('cbSort', CB.tab === 'open' ? 'فتح الصندوق، الأحدث أولًا' : 'الإضافة للتدقيق، الأحدث أولًا', [CB.tab === 'open' ? 'فتح الصندوق، الأحدث أولًا' : 'الإضافة للتدقيق، الأحدث أولًا', 'رقم الصندوق، الأكبر أولًا', 'الإجمالي، الأعلى أولًا', 'الحالة، تصاعديًا'], { cls: 'select', icon: 'arrow-down-up' })}
      ${CB.tab === 'closed' ? pickBtn('cbAudit', '', ['كل حالات التدقيق', 'بانتظار التدقيق', 'تم التدقيق'], { cls: 'select', icon: 'badge-check', ph: 'حالة التدقيق' }) : ''}
      <span class="grow"></span><div class="seg" aria-label="طريقة العرض"><button type="button" data-cbview="table" aria-pressed="${CB.view === 'table'}">${ic('table', 'i i-sm')}جدول</button><button type="button" data-cbview="cards" aria-pressed="${CB.view === 'cards'}">${ic('layout-grid', 'i i-sm')}بطاقات</button></div></div>
      <div id="cbList"></div><div class="dt2-foot" id="cbTotals"></div></section>`;
};
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-cbtab]'); if (t) { if (t.dataset.cbtab === 'entries') return toast('صفحة الحركات تُعرض من «الحركات»', 'list'); CB.tab = t.dataset.cbtab; CB.type = ''; CB.audit = ''; return PC.go('cash-boxes'); }
  const y = e.target.closest('[data-cbtype]'); if (y) { CB.type = CB.type === y.dataset.cbtype ? '' : y.dataset.cbtype; return cbDraw(); }
  const v = e.target.closest('[data-cbview]'); if (v) { CB.view = v.dataset.cbview; $$('[data-cbview]').forEach((b) => b.setAttribute('aria-pressed', String(b === v))); return cbDraw(); }
});
document.addEventListener('input', (e) => { if (e.target.id === 'cbQ') { CB.q = e.target.value.trim(); cbDraw(); } });
document.addEventListener('pick', (e) => { if (e.detail.key === 'cbOwner') { CB.owner = e.detail.value.split(' ')[0] === 'كل' ? '' : e.detail.value; cbDraw(); } if (e.detail.key === 'cbAudit') { CB.audit = e.detail.value.startsWith('كل') ? '' : e.detail.value; cbDraw(); } });
