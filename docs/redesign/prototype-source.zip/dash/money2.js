/* ── 4. تحميل حركة — ChargeModal.jsx ── */
const CHARGE_TYPES = [['gavel', 'غرامة مالية', 'مخالفة أو عبث بالعداد', [50, 100, 200], null, 'اكتب سبب الغرامة، مثال: توصيل خط بدون عداد'], ['unplug', 'رسوم قطع الخدمة', 'قطع الكهرباء أو إعادتها', [25, 50], 20, 'مثال: فصل بسبب تراكم الدين'], ['file-plus', 'رسوم اشتراك', 'تحميل رسوم الاشتراك على الحساب', [50, 100, 200], null, 'مثال: رسوم اشتراك المشترك الجديد'], ['scale', 'تحميل الحد الأدنى على المشترك', 'تحميل الحد الأدنى المحدد لهذا المشترك', [], 'min', '']];
function sheetModal(cls, icon, title, sub, s, body, ctaId, tone) {
  return mount('md sheet-modal ' + cls, `<div class="mh"><span class="tile-ic" ${tone ? `data-tone="${tone}" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)"` : ''}>${ic(icon, 'i i-lg')}</span><div><h2>${title}</h2><p>${sub}</p></div><div class="end">${closeBtn}</div></div><div class="mbody2">${body}</div><div class="mfoot"><span class="k"><span class="kbd">Esc</span> إغلاق</span><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-tone solid" data-tone="${tone || 'pay'}" id="${ctaId}" disabled></button></div></div>`);
}
/** Movement card (بطاقة الحركة): who, then «الرصيد الحالي» ± this line = «الرصيد بعده». */
const moveCard = (s, tag, tone, sign, afterId, midId, midLabel) => `<div class="move"><div class="move-who"><span class="av2">${s.n[0]}</span><div><b>${s.n}</b><small>حساب ${s.a}، ${s.box}، ${s.br}</small></div><span class="chip2x" data-tone="${tone}">${tag}</span></div><div class="move-eq"><div><small>الرصيد الحالي</small><b class="n">₪ ${money(s.bal)}</b><span>${s.bal > 0 ? 'عليه' : 'له'}</span></div><span class="op">${sign}</span><div><small>${midLabel}</small><b class="n" id="${midId}">₪ 0.00</b></div><span class="op">=</span><div><small>الرصيد بعده</small><b class="n" id="${afterId}">₪ ${money(s.bal)}</b><span id="${afterId}-d">${s.bal > 0 ? 'عليه' : 'له'}</span></div></div></div>`;
function openCharge(who) {
  const s = subBy(who), minC = s.min || 30;
  const el = sheetModal('', 'receipt', 'تحميل حركة', 'إضافة رسوم أو غرامة على حساب المشترك', null, `
    ${moveCard(s, 'تحميل', 'charge', '+', 'cAfter', 'cMid', 'التحميل')}
    <div class="ff w6"><label>نوع التحميل <span class="req">*</span></label><div class="rcs rcs-2" role="radiogroup">${CHARGE_TYPES.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="ch-type" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6"><div class="flab">مبلغ التحميل <span class="req">*</span><label class="lbl-sw" id="cLockSw" hidden><input type="checkbox" data-f="unlock">فتح القفل لتعديل المبلغ</label></div><div class="mini-amt" id="cAmtBox"><span>₪</span><input id="camt" inputmode="decimal" placeholder="0.00" aria-label="مبلغ التحميل"></div><div class="quick" id="cQuick" style="justify-content:flex-start;margin-top:4px"></div><span class="hint" id="cHint"></span></div>
    <div class="ff w6"><label id="cNoteL">سبب الغرامة <span class="req">*</span></label><div class="fc ta"><textarea data-f="note" id="cNote"></textarea></div><span class="hint">يظهر في كشف الحساب</span></div>`, 'cCta', 'charge');
  MO = { el, id: 'charge', s, k: 0, f: {}, discard: 'تجاهل التحميل؟' };
  const setType = (k) => {
    MO.k = k; const [, t, , quick, usual, ph] = CHARGE_TYPES[k], isMin = usual === 'min';
    $$('[data-act="ch-type"]', el).forEach((b) => b.setAttribute('aria-checked', String(+b.dataset.k === k)));
    $('#cQuick').innerHTML = quick.map((v) => `<button type="button" class="qchip" data-act="ch-quick" data-v="${v}">${v} ₪</button>`).join('');
    $('#cLockSw').hidden = !isMin; MO.f.unlock = false; $('[data-f="unlock"]').checked = false;
    if (isMin) $('#camt').value = money(minC); else if (!num($('#camt').value) || MO.autoFilled) { $('#camt').value = usual ? String(usual) : ''; }
    MO.autoFilled = isMin || !!usual;
    $('#cNoteL').innerHTML = k === 0 ? 'سبب الغرامة <span class="req">*</span>' : 'ملاحظات <span class="opt">اختياري</span>'; $('#cNote').placeholder = ph;
    upd();
  };
  const upd = () => {
    const a = num($('#camt').value), [, t, , , usual] = CHARGE_TYPES[MO.k], isMin = usual === 'min', locked = isMin && !MO.f.unlock;
    $('#camt').disabled = locked; $('#cAmtBox').classList.toggle('ro', locked);
    $('#cMid').textContent = `₪ ${money(a)}`; const after = s.bal + a; $('#cAfter').textContent = `₪ ${money(Math.abs(after))}`; $('#cAfter-d').textContent = after > 0 ? 'عليه' : 'له';
    $('#cHint').className = 'hint ' + (a > 500 ? 'warn' : ''); $('#cHint').textContent = isMin ? `الحد الأدنى للمشترك: ${money(minC)} ₪. يُسجّل كتحميل يدوي مستقل على الحساب.` : a > 500 ? 'مبلغ كبير. تأكد أنه صحيح قبل الحفظ، فهو يظهر في كشف الحساب.' : usual ? `المعتاد لهذا النوع ${usual} ₪` : '';
    const ok = a > 0 && (MO.k !== 0 || (MO.f.note || '').trim());
    $('#cCta').disabled = !ok; $('#cCta').innerHTML = !a ? 'أدخل مبلغ التحميل' : MO.k === 0 && !(MO.f.note || '').trim() ? 'اكتب سبب الغرامة' : `${ic('plus', 'i i-sm')}تحميل ${money(a)} ₪ على الحساب`;
    MO.a = a; MO.dirty = a > 0 && !MO.autoFilled || !!MO.f.note;
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k === 'unlock') { if (e.target.checked) { e.target.checked = false; return sheet(`<div class="cf"><div class="ic warn">${ic('lock-open', 'i i-lg')}</div></div><h3>تعديل مبلغ التحميل؟</h3><p>المبلغ مأخوذ من الحد الأدنى المحدد لهذا المشترك. هل تريد تعديله لهذه الحركة؟</p><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">إلغاء</button><button class="btn btn-primary" data-act="ch-unlock">نعم، عدّل</button></div>`); } MO.f.unlock = false; $('#camt').value = money(minC); } else if (k) MO.f[k] = e.target.value; if (e.target.id === 'camt') MO.autoFilled = false; upd(); });
  el.addEventListener('click', (e) => {
    const t = e.target.closest('[data-act="ch-type"]'); if (t) return setType(+t.dataset.k);
    const q = e.target.closest('[data-act="ch-quick"]'); if (q) { $('#camt').value = q.dataset.v; MO.autoFilled = false; return upd(); }
    if (e.target.closest('[data-act="ch-unlock"]')) { MO.f.unlock = true; $('[data-f="unlock"]').checked = true; MO.sheet = false; $('.sheet-host', el).innerHTML = ''; upd(); return $('#camt').focus(); }
  });
  $('#cCta').addEventListener('click', () => sheet(`<h3>تأكيد إضافة التحميل؟</h3><div class="sumbox"><div class="kv"><span>المشترك</span><b style="font-family:var(--f-body)">${s.n}</b></div><div class="kv"><span>النوع</span><b style="font-family:var(--f-body)">${CHARGE_TYPES[MO.k][1]}</b></div><div class="kv"><span>المبلغ</span><b>₪ ${money(MO.a)}</b></div><div class="kv"><span>الرصيد بعده</span><b>₪ ${money(s.bal + MO.a)}</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="charge" data-act="done" data-msg="تمت إضافة التحميل" data-amt="₪ ${money(MO.a)}">تأكيد</button></div>`));
  setType(0); $('#camt').focus();
}

/* ── 5. خصم — DiscountModal.jsx ── */
const DISC_KINDS = [['circle-dot', 'لمرة واحدة', 'مبلغ بالشيكل يُخصم الآن من الرصيد المستحق'], ['repeat', 'خصم القراءات الأسبوعية', 'من كل قراءة أسبوعية حتى تُوقفه']];
const DISC_METHODS = [['percent', 'نسبة', 'من قيمة كل قراءة'], ['zap', 'كيلوات', 'كيلوات مجانية كل أسبوع'], ['tag', 'شيكل من سعر الكيلو', 'يُنزل من سعر الكيلو']];
function openDiscount(who) {
  const s = subBy(who), price = 1.5, kwh = 139, bill = kwh * price;
  const el = sheetModal('', 'percent', 'إضافة خصم', 'لمرة واحدة، أو على كل قراءة أسبوعية حتى تُوقفه', null, `
    <div id="dMove"></div>
    <div class="ff w6"><label>نوع الخصم <span class="req">*</span></label><div class="rcs" role="radiogroup">${DISC_KINDS.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="dc-kind" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6" id="dMethodF" hidden><label>طريقة الخصم <span class="req">*</span></label><div class="rcs rcs-3" role="radiogroup">${DISC_METHODS.map(([i, t, d], k) => `<button class="rc" type="button" role="radio" aria-checked="${k === 0}" data-act="dc-method" data-k="${k}"><span class="ic">${ic(i, 'i i-sm')}</span><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div></div>
    <div class="ff w6"><label id="dValL"></label><div class="mini-amt"><span id="dUnit">₪</span><input id="dval" inputmode="decimal" placeholder="0" aria-label="قيمة الخصم"></div><div class="quick" id="dQuick" style="justify-content:flex-start;margin-top:4px"></div><span class="hint" id="dHint"></span></div>
    <div class="ff w6" id="dSegF" hidden><label>تصنيف الزبون <span class="opt">اختياري</span></label><div class="fc">${ic('tags', 'i i-sm')}<input data-f="seg" placeholder="مثال: موظفو أبو زايد"></div><div class="chips-pick" style="margin-top:4px">${['موظفو أبو زايد', 'مؤسسات', 'أسر محتاجة'].map((c) => `<button type="button" aria-pressed="false" data-act="dc-seg" data-v="${c}">${c}</button>`).join('')}</div></div>
    <div class="ff w6"><label>ملاحظات <span class="opt">اختياري</span></label><div class="fc ta"><textarea data-f="note" placeholder="مثال: خصم بموافقة المدير"></textarea></div></div>`, 'dCta', 'discount');
  MO = { el, id: 'discount', s, kind: 0, m: 0, f: {}, discard: 'تجاهل الخصم؟' };
  const upd = () => {
    const weekly = MO.kind === 1, v = num($('#dval').value);
    $('#dMethodF').hidden = !weekly; $('#dSegF').hidden = !weekly;
    const mode = weekly ? ['pct', 'kw', 'ils'][MO.m] : 'once';
    $('#dValL').innerHTML = { once: 'المبلغ (بالشيكل)', pct: 'النسبة من كل قراءة (من 1 إلى 100)', kw: `الكيلوات المجانية كل أسبوع (الكيلو بـ ${price.toFixed(2)} ₪)`, ils: `الخصم من سعر الكيلو (سعر الكيلو ${price.toFixed(2)} ₪)` }[mode] + ' <span class="req">*</span>';
    $('#dUnit').textContent = { once: '₪', pct: '%', kw: 'ك.و', ils: '₪' }[mode];
    const quick = { once: [10, 20, 50], pct: [5, 10, 20], kw: [5, 10, 20], ils: [0.5, 1] }[mode];
    $('#dQuick').innerHTML = quick.map((q) => `<button type="button" class="qchip" data-act="dc-quick" data-v="${q}">${q}</button>`).join('') + (mode === 'once' && s.bal > 0 ? `<button type="button" class="qchip" data-act="dc-quick" data-v="${s.bal}">كل ما عليه</button>` : '');
    const off = mode === 'once' ? v : Math.min(bill, mode === 'pct' ? bill * v / 100 : mode === 'kw' ? v * price : v * kwh);
    const bad = mode === 'pct' && (v < 1 || v > 100) && v !== 0;
    $('#dHint').className = 'hint ' + (bad ? 'bad' : ''); $('#dHint').textContent = bad ? 'النسبة من 1 إلى 100' : weekly && v ? `يوفّر ₪ ${money(off)} في الأسبوع، قرابة ₪ ${money(off * 4.3)} في الشهر` : '';
    $('#dMove').innerHTML = weekly
      ? `<div class="move"><div class="move-who"><span class="av2">${s.n[0]}</span><div><b>${s.n}</b><small>حساب ${s.a}، ${s.box}</small></div><span class="chip2x" data-tone="discount">كل أسبوع</span></div><div class="move-eq"><div><small>فاتورة الأسبوع المعتادة</small><b class="n">₪ ${money(bill)}</b><span>${kwh} كيلو × ${price.toFixed(2)} ₪</span></div><span class="op">−</span><div><small>الخصم</small><b class="n">₪ ${money(off)}</b><span>${['نسبة', 'كيلوات', 'شيكل من سعر الكيلو'][MO.m]}</span></div><span class="op">=</span><div><small>يدفع عن آخر قراءة</small><b class="n">₪ ${money(bill - off)}</b></div></div></div>`
      : moveCard(s, 'مرة واحدة', 'discount', '−', 'dAfter', 'dMid', 'الخصم');
    if (!weekly) { $('#dMid').textContent = `₪ ${money(v)}`; const after = s.bal - v; $('#dAfter').textContent = `₪ ${money(Math.abs(after))}`; $('#dAfter-d').textContent = after > 0 ? 'عليه' : 'له'; }
    $('#dCta').disabled = !v || bad; $('#dCta').innerHTML = !v ? 'أدخل قيمة الخصم' : weekly ? `${ic('repeat', 'i i-sm')}تفعيل خصم القراءات الأسبوعية` : `${ic('check', 'i i-sm')}خصم ${money(v)} ₪`;
    MO.off = off; MO.v = v; MO.dirty = v > 0;
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { if (e.target.dataset.f) MO.f[e.target.dataset.f] = e.target.value; upd(); });
  el.addEventListener('click', (e) => {
    const k = e.target.closest('[data-act="dc-kind"]'); if (k) { MO.kind = +k.dataset.k; $$('[data-act="dc-kind"]', el).forEach((b) => b.setAttribute('aria-checked', String(b === k))); $('#dval').value = ''; return upd(); }
    const m = e.target.closest('[data-act="dc-method"]'); if (m) { MO.m = +m.dataset.k; $$('[data-act="dc-method"]', el).forEach((b) => b.setAttribute('aria-checked', String(b === m))); $('#dval').value = ''; return upd(); }
    const q = e.target.closest('[data-act="dc-quick"]'); if (q) { $('#dval').value = q.dataset.v; return upd(); }
    const g = e.target.closest('[data-act="dc-seg"]'); if (g) { const on = g.getAttribute('aria-pressed') !== 'true'; $$('[data-act="dc-seg"]', el).forEach((b) => b.setAttribute('aria-pressed', 'false')); g.setAttribute('aria-pressed', String(on)); $('[data-f="seg"]').value = on ? g.dataset.v : ''; MO.f.seg = $('[data-f="seg"]').value; }
  });
  $('#dCta').addEventListener('click', () => sheet(`<h3>تأكيد إضافة الخصم؟</h3><div class="sumbox"><div class="kv"><span>النوع</span><b style="font-family:var(--f-body)">${DISC_KINDS[MO.kind][1]}</b></div>${MO.kind ? `<div class="kv"><span>الطريقة</span><b style="font-family:var(--f-body)">${DISC_METHODS[MO.m][1]}</b></div>` : ''}<div class="kv"><span>القيمة</span><b>${MO.v} ${$('#dUnit').textContent}</b></div><div class="kv"><span>${MO.kind ? 'يوفّر في الأسبوع' : 'يُخصم من الرصيد'}</span><b>− ₪ ${money(MO.off)}</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="discount" data-act="done" data-msg="تمت إضافة الخصم" data-amt="− ₪ ${money(MO.off)}">تأكيد</button></div>`));
  upd(); $('#dval').focus();
}

/* ── 6. دفعة مقسّمة — SplitPaymentModal.jsx: one window, the transfer on top and its allocation below ── */
const COLORS = ['oklch(0.62 0.19 254)', 'oklch(0.7 0.17 152)', 'oklch(0.75 0.15 72)', 'oklch(0.62 0.2 300)', 'oklch(0.65 0.2 25)'];
function openSplit() {
  const el = mount('md sheet-modal split2', `<div class="mh"><span class="tile-ic" data-tone="split" style="background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)">${ic('split', 'i i-lg')}</span><div><h2>دفعة مقسّمة على عدة مشتركين</h2><p>حوالة واحدة توزَّع على مشتركين، ولو بهويات مختلفة</p></div><div class="end">${closeBtn}</div></div>
    <div class="mbody2">
      <div class="ff w6"><label>المبلغ المحوَّل (الإجمالي) <span class="req">*</span></label><div class="mini-amt" style="height:76px"><span>₪</span><input data-f="total" id="spTotal" inputmode="decimal" placeholder="0.00" style="font-size:34px" aria-label="المبلغ المحوَّل"></div></div>
      <section class="xcard"><h4>بيانات التحويل</h4>
        <div class="ff w6"><label>البنك المستلم <span class="req">*</span></label><div class="banks">${BANKS.map(([n, c, col]) => `<button class="bank" type="button" role="radio" aria-checked="false" data-act="sp2-bank" data-bank="${n}"><span class="lg" style="background:${col}">${c}</span>${n}</button>`).join('')}</div></div>
        <div class="fg"><div class="ff"><label>البنك المرسل</label>${pickBtn('sbank', '', ['غير محدد', ...BANKS.map((b) => b[0])], { icon: 'landmark', ph: 'اختر البنك أو المحفظة المحوّل منها' })}</div>
          <div class="ff"><label>تاريخ وصول الحوالة إلى البنك <span class="opt">اختياري</span></label>${dateBtn('date', '')}</div>
          <div class="ff"><label>اسم المحوِّل <span class="req">*</span></label><div class="fc">${ic('user', 'i i-sm')}<input data-f="sender" placeholder="اسم صاحب الحساب الذي حُوّل منه المبلغ"></div></div>
          <div class="ff"><label>الرقم المرجعي <span class="req">*</span></label><div class="fc" id="spRefBox">${ic('hash', 'i i-sm')}<input data-f="ref" placeholder="مثال: TRX-48213" data-ltr></div><span class="hint" id="spRefHint">من إشعار الحوالة</span></div></div>
        <label class="ack" id="spDup" hidden><input type="checkbox" class="cb" data-f="dupOk"><span>أؤكد أن هذا الرقم المرجعي مسجَّل على دفعة أخرى وأريد المتابعة</span></label>
        <span class="hint">اتركه فارغًا إن لم تتأكد من تاريخ الوصول. تُسجّل الحركة بتاريخ تسجيلها في النظام.</span></section>
      <section class="xcard"><div style="display:flex;align-items:center;gap:8px"><h4 style="margin:0">توزيع المبلغ على المشتركين</h4><button type="button" class="btn btn-secondary btn-sm" data-act="sp2-all" style="margin-inline-start:auto">${ic('users', 'i i-sm')}كل اشتراكات هذه الهوية</button></div>
        <div><div class="alloc-bar" id="aBar"></div><div class="alloc-sum" id="aSum"></div></div>
        <div id="aRows"></div>
        <div class="ff w6"><label>إضافة مشترك إلى هذه الدفعة</label>${pickBtn('spAdd', '', SUBS.map((x) => x.n), { icon: 'user-plus', ph: 'ابحث بالاسم أو الحساب أو الجوال' })}</div>
        <label class="ack" id="spOver" hidden><input type="checkbox" class="cb" data-f="overOk"><span>أؤكد أن المبالغ صحيحة</span></label>
        <div class="ff w6"><label>ملاحظة <span class="opt">تظهر في كشف كل مشترك</span></label><div class="fc">${ic('sticky-note', 'i i-sm')}<input data-f="note" placeholder="أي تفصيل يُحفظ مع الدفعة"></div></div></section>
    </div><div class="mfoot"><span class="k" id="spK"></span><div class="end"><button class="btn btn-secondary" data-act="close">إلغاء</button><button class="btn btn-tone solid" data-tone="split" id="spCta" disabled></button></div></div>`);
  MO = { el, id: 'split', f: {}, bank: null, rows: [], discard: 'تجاهل التغييرات؟' };
  const rowsHTML = () => { $('#aRows').innerHTML = MO.rows.map((r, i) => `<div class="arow"><span class="sw3" style="background:${COLORS[i % 5]}"></span><span><b>${r.n}</b><small>حساب ${r.a}، عليه ₪ ${money(r.owe)}</small></span><div class="mini-amt"><span>₪</span><input data-row="${i}" value="${r.v}" inputmode="decimal" aria-label="مبلغ ${r.n}"></div><button class="btn btn-ghost btn-icon btn-sm" data-act="sp2-del" data-i="${i}" aria-label="إزالة ${r.n}">${ic('x', 'i i-sm')}</button></div>`).join('') || '<div class="hint" style="padding:8px 0">لم تُضف أي مشترك بعد.</div>'; };
  const upd = () => {
    const total = num(MO.f.total), alloc = MO.rows.reduce((t, r) => t + num(r.v), 0), left = Math.round((total - alloc) * 100) / 100;
    $('#aBar').innerHTML = MO.rows.map((r, i) => `<i style="width:${total ? Math.min(100, num(r.v) / total * 100) : 0}%;background:${COLORS[i % 5]}"></i>`).join('');
    const msg = !total ? 'أدخل المبلغ المحوَّل ثم وزّعه على المشتركين' : MO.rows.length < 2 ? 'أضف مشتركَين على الأقل' : MO.rows.some((r) => !num(r.v)) ? 'أدخل مبلغ كل مشترك' : left === 0 ? '✓ وُزّع المبلغ كاملًا' : left > 0 ? `بقي ${money(left)} ₪ لم يُوزَّع` : `الموزَّع يزيد ${money(-left)} ₪ على المحوَّل`;
    const tone = msg.startsWith('✓') ? 'ok' : left < 0 ? 'over' : 'left';
    $('#aSum').innerHTML = `<span class="n" style="font-weight:700">${money(alloc)} من ${money(total)} ₪</span><span class="pill ${tone}">${msg}</span>`;
    const ref = (MO.f.ref || '').trim(), used = /^TRX-48213$/i.test(ref);
    $('#spRefHint').className = 'hint ' + (ref ? (used ? 'warn' : 'ok') : ''); $('#spRefHint').textContent = ref ? (used ? 'الرقم المرجعي مكرر: مسجَّل مسبقًا في السند V-08790، سعاد ناصر. يمكنك المتابعة بعد التأكيد.' : '✓ الرقم المرجعي متاح.') : 'من إشعار الحوالة';
    $('#spDup').hidden = !used; $('#spRefBox').classList.toggle('warnb', used);
    const over = MO.rows.some((r) => num(r.v) > r.owe); $('#spOver').hidden = !over;
    const ok = total > 0 && MO.bank && (MO.f.sender || '').trim() && ref && (!used || MO.f.dupOk) && MO.rows.length >= 2 && left === 0 && (!over || MO.f.overOk);
    $('#spCta').disabled = !ok; $('#spCta').innerHTML = `${ic('check', 'i i-sm')}${MO.rows.length >= 2 ? `تسجيل الدفعة على ${MO.rows.length} مشتركين` : 'تسجيل الدفعة'}`;
    $('#spK').textContent = MO.rows.length ? `${MO.rows.length} مشتركين` : '';
    MO.dirty = total > 0 || MO.rows.length > 0;
  };
  MO.upd = upd;
  const add = (s) => { if (!MO.rows.some((r) => r.a === s.a)) MO.rows.push({ n: s.n, a: s.a, owe: s.bal, v: '' }); rowsHTML(); upd(); };
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) MO.f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; if (e.target.dataset.row) MO.rows[+e.target.dataset.row].v = e.target.value; upd(); });
  el.addEventListener('pick', (e) => { if (e.detail.key === 'spAdd') { add(subBy(e.detail.value)); const pv = $('[data-pick="spAdd"] .pkv'); pv.textContent = 'ابحث بالاسم أو الحساب أو الجوال'; pv.classList.add('ph'); } else MO.f[e.detail.key] = e.detail.value; });
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act="sp2-bank"]'); if (b) { MO.bank = b.dataset.bank; $$('[data-act="sp2-bank"]', el).forEach((x) => x.setAttribute('aria-checked', String(x === b))); return upd(); }
    if (e.target.closest('[data-act="sp2-all"]')) { [['منصور للتجارة، المخزن', '202600149', 520], ['منصور للتجارة، المكتب', '202600150', 410]].forEach(([n, a, o]) => add({ n, a, bal: o })); return; }
    const d = e.target.closest('[data-act="sp2-del"]'); if (d) { MO.rows.splice(+d.dataset.i, 1); rowsHTML(); return upd(); }
  });
  $('#spCta').addEventListener('click', () => sheet(`<h3>تسجيل الدفعة المقسّمة؟</h3><div class="sumbox"><div class="kv"><span>الرقم المرجعي</span><b>${esc2(MO.f.ref)}</b></div><div class="kv"><span>المبلغ</span><b>₪ ${money(num(MO.f.total))}</b></div><div class="kv"><span>على</span><b style="font-family:var(--f-body)">${MO.rows.length} مشتركين</b></div></div><div class="btns"><button class="btn btn-secondary" data-act="sheet-back">رجوع</button><button class="btn btn-tone solid" data-tone="split" data-act="done" data-msg="تم تسجيل الدفعة المقسّمة" data-amt="₪ ${money(num(MO.f.total))}">تأكيد</button></div>`));
  add(SUBS[0]); $('#spTotal').focus();
}

