function openPayment(who) {
  const s = subBy(who);
  const RECV = BANKS.filter((b) => b[3] !== 'sender');
  const el = mount('co', `<div class="co-grid">
    <section class="co-main">
      <div class="co-top"><span class="tile-ic" data-tone="pay" style="width:46px;height:46px;border-radius:16px;display:grid;place-items:center;background:color-mix(in oklab,var(--tone) 14%,transparent);color:var(--tone-ink)">${ic('hand-coins', 'i i-lg')}</span><div><h2>تسجيل دفعة</h2><p>${s.n}، حساب ${s.a}</p></div><div class="end">${closeBtn}</div></div>
      <div class="amount"><small>المبلغ المستلم</small>
        <div class="amount-row"><div class="cur" id="cur"><button type="button" data-act="cur-toggle" aria-label="عملة الدفع"><span id="curSym">₪</span>${ic('chevron-down', 'i i-sm')}</button><div class="cur-menu">${Object.entries(CUR).map(([k, [sym, name]]) => `<button type="button" data-act="cur" data-cur="${k}"><span>${name} (${k})</span><b>${sym}</b></button>`).join('')}</div></div><input id="amt" inputmode="decimal" placeholder="0.00" autocomplete="off" aria-label="المبلغ المستلم"></div>
        <div class="conv" id="conv"></div>
        <div class="quick">${s.bal > 0 ? `<button type="button" class="fill-link" data-act="fill">تسديد كامل الدين، ₪ ${money(s.bal)}</button>` : ''}${[50, 100, 200].map((v) => `<button type="button" class="qchip" data-act="pm-quick" data-v="${v}">${v}</button>`).join('')}</div>
        <div class="notice" id="over" hidden></div>
      </div>
      <div><div class="fs"><h4>طريقة الدفع</h4></div>
        <div class="methods" role="radiogroup">
          <button class="method" role="radio" aria-checked="true" data-act="method" data-m="transfer"><span class="art bank">${ic('landmark', 'i i-lg')}</span><span><b>تحويل بنكي أو محفظة</b><small>${RECV.slice(0, 3).map((b) => b[0]).join('، ')}…</small></span><span class="tick">${ic('check', 'i i-sm')}</span><span class="kbd key">1</span></button>
          <button class="method" role="radio" aria-checked="false" data-act="method" data-m="cash"><span class="art cash">${ic('banknote', 'i i-lg')}</span><span><b>نقد</b><small>استُلم المبلغ نقدًا</small></span><span class="tick">${ic('check', 'i i-sm')}</span><span class="kbd key">2</span></button>
        </div></div>
      <div class="reveal on" id="xfer"><div><div class="inner">
        <div class="ff w6"><label>البنك المستلم <span class="req">*</span></label><div class="banks">${RECV.map(([n, c, col]) => `<button class="bank" type="button" role="radio" aria-checked="false" data-act="bank" data-bank="${n}"><span class="lg" style="background:${col}">${c}</span>${n}</button>`).join('')}</div></div>
        <div class="fg">
          <div class="ff"><label>البنك المرسل</label>${pickBtn('sbank', '', ['غير محدد', ...BANKS.map((b) => b[0])], { icon: 'landmark', ph: 'اختر البنك أو المحفظة المحوّل منها' })}</div>
          <div class="ff"><label>تاريخ وصول الحوالة إلى البنك <span class="opt">اختياري</span></label>${dateBtn('xdate', '')}<span class="hint">اتركه فارغًا إن لم تتأكد منه. تُسجّل الحركة بتاريخ تسجيلها في النظام.</span></div>
          <div class="ff"><div class="flab">اسم المحوِّل <span class="req">*</span><label class="lbl-sw"><input type="checkbox" data-f="self" checked>المشترك نفسه</label></div><div class="fc ro" id="senderBox">${ic('user', 'i i-sm')}<input data-f="sender" value="${s.n}" disabled aria-label="اسم المحوِّل"></div></div>
          <div class="ff"><label>الرقم المرجعي <span class="req">*</span></label><div class="fc" id="refBox">${ic('hash', 'i i-sm')}<input data-f="ref" placeholder="مثال: TRX-48213" data-ltr aria-label="الرقم المرجعي"></div><span class="hint" id="refHint">من إشعار الحوالة</span></div>
        </div>
        <label class="ack" id="dupAck" hidden><input type="checkbox" class="cb" data-f="dupOk"><span>أؤكد تسجيل الدفعة بالرقم نفسه</span></label>
      </div></div></div>
      <div><div class="extras"><button class="extra on" data-act="extra" data-x="paper">${ic('plus', 'i i-sm')}رقم السند اليدوي</button><button class="extra on" data-act="extra" data-x="note">${ic('plus', 'i i-sm')}ملاحظة</button></div>
        <div class="reveal" id="x-paper"><div><div class="inner"><div class="ff w6"><div class="flab">رقم السند اليدوي <span class="opt">رقم الوصل الورقي، اختياري</span><button type="button" class="lbl-act" data-act="extra-hide" data-x="paper" aria-label="إخفاء الحقل">${ic('eye-off', 'i i-sm')}إخفاء</button></div><div class="fc">${ic('receipt', 'i i-sm')}<input data-f="paper" placeholder="مثال: 00412" data-ltr maxlength="50"></div></div></div></div></div>
        <div class="reveal on" id="x-note"><div><div class="inner"><div class="ff w6"><div class="flab">ملاحظة <span class="opt">اختياري</span><button type="button" class="lbl-act" data-act="extra-hide" data-x="note" aria-label="إخفاء الحقل">${ic('eye-off', 'i i-sm')}إخفاء</button></div><div class="fc">${ic('sticky-note', 'i i-sm')}<input data-f="note" placeholder="أي تفصيل يُحفظ مع الدفعة" maxlength="1000"></div></div></div></div></div>
      </div>
      <button class="btn btn-tone solid cta" data-tone="pay" id="cta" data-act="pay-review" disabled>${ic('lock', 'i i-sm')}<span id="ctaT">أدخل المبلغ المستلم</span></button>
      <div class="cta-sub">${ic('shield-check', 'i i-sm')}يُسجّل في صندوقك C-418 ويُطبع الوصل بعد التأكيد، <span class="kbd">Ctrl</span><span class="kbd">↵</span></div>
    </section>
    <aside class="co-receipt">
      <div class="paper"><div class="pt"><span class="mk">${MA}</span><div class="co"><b>مصعب العجل وأحمد الكفارنة</b><small>للتجارة العامة</small></div><div class="no"><b>وصل قبض</b><span class="n">V-08813، 16/11/2026</span></div></div>
        <div class="who"><b>${s.n}</b><small>حساب ${s.a}، ${s.box}</small></div>
        <div class="ln"><span>الرصيد الحالي</span><b>₪ ${money(s.bal)} <small class="dir">${s.bal > 0 ? 'عليه' : 'له'}</small></b></div>
        <div class="ln pay"><span>هذه الدفعة <small id="rMethod" class="dir">تحويل</small></span><b id="rPay">− ₪ 0.00</b></div>
        <div class="tot"><span>الرصيد بعدها</span><b id="rAfter">₪ ${money(s.bal)}</b></div>
        <div class="cover"><div class="kv"><span>تغطية المستحق</span><b class="n" id="rCov">0%</b></div><span class="bar"><i id="rCovBar" style="width:0"></i></span></div>
        <div class="qr"></div>
        <div class="stamp"><span>C-418، أحمد سالم</span><span>${s.br}</span></div></div>
      <div class="rc-meta"><div>${ic('clock', 'i i-sm')}آخر دفعة: ${s.last}</div><div>${ic('printer', 'i i-sm')}يُطبع تلقائيًا بعد التسجيل</div></div>
    </aside></div>`);
  MO = { el, id: 'payment', s, cur: 'ILS', method: 'transfer', bank: null, f: { self: true, sender: s.n }, discard: 'تجاهل الدفعة؟' };
  const upd = () => {
    const a = num($('#amt').value), [sym, name, rate] = CUR[MO.cur], ils = a * rate, after = s.bal - ils, xfer = MO.method === 'transfer';
    $('#curSym').textContent = sym;
    $('#conv').textContent = MO.cur !== 'ILS' ? `سعر الصرف المعتمد: 1 ${name} = ${rate} شيكل${a ? `، القيمة المسجلة على حساب المشترك: ${money(ils)} شيكل.` : ''}` : '';
    // Overpayment: a credit note when a little above, a required confirmation when far above.
    const far = s.bal >= 0 && ils > s.bal * 2 + 200, over = ils > s.bal && a > 0;
    $('#over').hidden = !over;
    $('#over').className = 'notice ' + (far ? 'bad' : 'warn');
    $('#over').innerHTML = far ? `${ic('triangle-alert', 'i i-sm')}<div><b>المبلغ أكبر بكثير من المستحق (₪ ${money(s.bal)}). تأكد أنك لم تكتب رقمًا زائدًا بالخطأ.</b><label class="ack" style="margin-top:8px"><input type="checkbox" class="cb" data-f="overOk" ${MO.f.overOk ? 'checked' : ''}><span>أؤكد أن المبلغ ${money(a)} ${name} صحيح</span></label></div>` : `${ic('info', 'i i-sm')}<div>المبلغ أكبر من المستحق على المشترك (₪ ${money(s.bal)})، وسيبقى له رصيد دائن قدره ₪ ${money(ils - s.bal)}.</div>`;
    $('#x-paper').classList.toggle('on', !xfer && !MO.paperHidden); $$('[data-x="paper"].extra', el).forEach((b) => b.classList.toggle('on', xfer || !MO.paperHidden));
    $('#rPay').textContent = `− ₪ ${money(ils)}`;
    $('#rMethod').textContent = xfer ? (MO.bank ? `تحويل، ${MO.bank}` : 'تحويل') : 'نقد';
    $('#rAfter').textContent = after < 0 ? `₪ ${money(-after)} له` : after === 0 ? 'مسدّد ✓' : `₪ ${money(after)} عليه`;
    $('#rAfter').classList.toggle('ok', after <= 0);
    const cov = s.bal > 0 ? Math.min(100, Math.round(ils / s.bal * 100)) : 100; $('#rCov').textContent = cov + '%'; $('#rCovBar').style.width = cov + '%';
    // Sender: the subscriber by default; switching «المشترك نفسه» off makes the name editable and empty.
    const sb = $('[data-f="sender"]'); sb.disabled = !!MO.f.self; $('#senderBox').classList.toggle('ro', !!MO.f.self); if (MO.f.self) sb.value = s.n;
    const ref = (MO.f.ref || '').trim(), used = /^TRX-48213$/i.test(ref);
    $('#refHint').className = 'hint ' + (ref ? (used ? 'warn' : 'ok') : ''); $('#refHint').textContent = ref ? (used ? 'الرقم المرجعي مكرر: مسجَّل مسبقًا في السند V-08790، سعاد ناصر' : '✓ الرقم المرجعي متاح.') : 'من إشعار الحوالة';
    $('#dupAck').hidden = !used; $('#refBox').classList.toggle('warnb', used);
    const sender = MO.f.self ? s.n : (MO.f.sender || '').trim();
    const ok = a > 0 && (!far || MO.f.overOk) && (!xfer || (MO.bank && ref && sender && (!used || MO.f.dupOk)));
    $('#cta').disabled = !ok;
    $('#ctaT').textContent = !a ? 'أدخل المبلغ المستلم' : far && !MO.f.overOk ? 'أكّد المبلغ أولًا' : xfer && !MO.bank ? 'اختر البنك المستلم' : xfer && !sender ? 'أدخل اسم المحوِّل' : xfer && !ref ? 'أدخل الرقم المرجعي' : xfer && used && !MO.f.dupOk ? 'أكّد الرقم المكرر أولًا' : `تسجيل ${money(a)} ${MO.cur === 'ILS' ? '₪' : MO.cur}`;
    MO.dirty = a > 0 || ['ref', 'paper', 'note'].some((k) => MO.f[k]);
  };
  MO.upd = upd;
  el.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) MO.f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; if (k === 'self' && !e.target.checked) { MO.f.sender = ''; $('[data-f="sender"]').value = ''; setTimeout(() => $('[data-f="sender"]').focus(), 0); } upd(); });
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'amt' && !$('#cta').disabled) $('#cta').click(); if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !$('#cta').disabled) { e.preventDefault(); $('#cta').click(); } if (!e.target.closest('input, textarea') && (e.key === '1' || e.key === '2')) $(`[data-m="${e.key === '1' ? 'transfer' : 'cash'}"]`, el).click(); });
  upd(); $('#amt').focus();
}
