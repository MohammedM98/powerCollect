/* Ledger rows: eight calm columns (# · التاريخ · البيان · النوع · عليه · له · الرصيد · ⋯).
   Every other field of the line is one click away in its detail row — nothing is dropped, nothing shouts. */
const AR_MONTH = (iso) => { const [y, m] = iso.split('-').map(Number); return `${MONTHS[m - 1]} ${y}`; };
const ST_OPEN = new Set();
function stRow({ l, bal, net }) {
  const [n, box, vch, ref, bank, d, t, desc, amt, side, type, method, user, x] = l;
  const tone = txTone(type), owe = side === '+', open = ST_OPEN.has(n);
  const dot = x.chain ? `<span class="chain" style="background:${CHAIN[x.chain]}" title="الحركات المرتبطة بنفس اللون"></span>` : '';
  const meta = [vch !== '—' ? `سند ${vch}` : '', method !== '—' ? method : '', x.split ? 'دفعة مقسّمة' : '', x.late ? 'متأخرة' : ''].filter(Boolean).join('، ');
  const amtCell = (on) => on ? `<span class="mv" dir="ltr">${money(net)}</span>${x.disc ? `<small dir="ltr">${money(amt)} − ${money(x.disc)}</small>` : ''}` : '';
  const kv = [['رقم الصندوق', box], ['رقم السند', vch], ['الرقم المرجعي', ref], ['البنك', bank || '—'], ['العملة', 'شيكل'], ['طريقة الدفع', method], ['سعر الصرف', '1'], ['اسم المستخدم', user], ['وقت التسجيل', t], ...(x.bankArrive ? [['وصول البنك', x.bankArrive.split('-').reverse().join('/')]] : []), ...(x.late ? [['الدفع الفعلي', x.late.split('-').reverse().join('/')]] : []), ...(x.note ? [['ملاحظة الحركة', x.note]] : [])];
  return `<tr class="st-r ${x.cancelled ? 'cancelled' : ''} ${x.reversal ? 'rev' : ''} ${open ? 'open' : ''}" data-chain="${x.chain || ''}">
    <td class="st-x"><button type="button" class="exp" data-stexp="${n}" aria-expanded="${open}" aria-label="تفاصيل الحركة #${n}">${ic('chevron-down', 'i i-sm')}</button></td>
    <td class="st-n">${dot}<span>#${n}</span>${x.fold ? `<small>+ #${x.fold}</small>` : ''}</td>
    <td class="st-d">${d.split('-').reverse().join('/')}</td>
    <td class="st-desc">${x.reversal ? '<span class="muted">↲ </span>' : ''}<span class="t">${desc}</span>${meta ? `<small>${meta}</small>` : ''}</td>
    <td class="st-type">${tone ? `<span class="chip2x" data-tone="${tone}">${ic(TX_ICON[tone], 'i')}${type}</span>` : `<span class="chip2x st-default">${type}</span>`}${x.cancelled ? '<span class="chip2x st-default">ملغاة</span>' : ''}</td>
    <td class="c-money st-owe">${amtCell(owe)}</td><td class="c-money st-paid">${amtCell(!owe)}</td>
    <td class="c-money st-bal">${x.cancelled || x.reversal ? '<span class="muted" title="أُلغيت مع قيدها العكسي، فلم تغيّر الرصيد">—</span>' : `<span class="mv" dir="ltr">${money(Math.abs(bal))}</span><small>${bal > 0 ? 'عليه' : bal < 0 ? 'له' : 'مسدّد'}</small>`}</td>
    <td class="c-act"><button type="button" class="row-menu" data-stmenu="${n}" aria-label="إجراءات الحركة #${n}" aria-haspopup="menu" aria-expanded="false">${ic('ellipsis-vertical', 'i i-sm')}</button></td></tr>
    ${open ? `<tr class="st-detail"><td></td><td colspan="8"><dl>${kv.map(([k, v]) => `<div><dt>${k}</dt><dd ${/TRX|^\d|C-|T-/.test(v) ? 'dir="ltr"' : ''}>${esc2(v)}</dd></div>`).join('')}</dl></td></tr>` : ''}`;
}
function stDraw() {
  const all = stLines();
  let rows = all.filter(({ l }) => ST.view === 'all' || !(l[13].cancelled || l[13].reversal));
  if (ST.q) rows = rows.filter(({ l }) => l.join(' ').includes(ST.q));
  if (ST.type !== 'الكل') rows = rows.filter(({ l }) => ST.type.startsWith('كل ما عليه') ? l[9] === '+' : ST.type.startsWith('كل ما له') ? l[9] === '-' : l[10] === ST.type);
  if (ST.method !== 'الكل') rows = rows.filter(({ l }) => l[11] === ST.method);
  if (/الأحدث/.test(ST.sort)) rows = [...rows].reverse();
  const hidden = all.length - all.filter(({ l }) => !(l[13].cancelled || l[13].reversal)).length;
  // Month bands: a quiet header with that month's charges, payments and closing balance.
  let html = '', month = '';
  rows.forEach((r, i) => {
    const m = AR_MONTH(r.l[5]);
    if (m !== month) { month = m; const inM = rows.filter((x) => AR_MONTH(x.l[5]) === m && !x.l[13].cancelled && !x.l[13].reversal); const o = inM.filter((x) => x.l[9] === '+').reduce((t, x) => t + x.net, 0), pd = inM.filter((x) => x.l[9] === '-').reduce((t, x) => t + x.net, 0);
      html += `<tr class="st-month"><td colspan="5"><b>${m}</b><span>${inM.length} حركة</span></td><td class="c-money"><small>عليه</small> ${money(o)}</td><td class="c-money"><small>له</small> ${money(pd)}</td><td colspan="2"></td></tr>`; }
    html += stRow(r);
  });
  $('#stBody').innerHTML = rows.length ? html : `<tr><td colspan="9" style="border:0"><div class="dt2-empty"><div class="ic">${ic('search-x', 'i i-lg')}</div><b>لا توجد حركات تطابق البحث والتصفية.</b><p></p><button type="button" class="btn btn-secondary btn-sm" data-stclear>مسح عوامل التصفية</button></div></td></tr>`;
  const filtered = ST.q || ST.type !== 'الكل' || ST.method !== 'الكل';
  $('#stFoot').innerHTML = `<span>الحركات المعروضة: <b>${rows.length}</b> من <b>${all.length}</b>، الأقدم أولًا، والرصيد بعد كل حركة${ST.view === 'compact' && hidden ? `، أُخفيت ${hidden} حركة ملغاة مع قيودها العكسية (مجموعها صفر)` : ''}</span><span class="grow"></span>${ST.view === 'compact' && hidden ? `<button type="button" class="btn btn-ghost btn-sm" data-stview="all">عرض كل الحركات</button>` : ''}${filtered ? `<button type="button" class="btn btn-ghost btn-sm" data-stclear>مسح عوامل التصفية</button>` : ''}`;
  $('#stViewHint').textContent = ST.view === 'compact' ? 'دون الحركات الملغاة وقيودها العكسية، وخصم القراءة الأسبوعية داخل قراءتها' : 'كل حركة كما سُجّلت، ومنها الملغاة وقيودها العكسية';
  $$('[data-stview]').forEach((b) => b.closest('.seg') && b.setAttribute('aria-pressed', String(b.dataset.stview === ST.view)));
}
document.addEventListener('click', (e) => { const x = e.target.closest('[data-stexp]'); if (!x) return; const n = +x.dataset.stexp; ST_OPEN.has(n) ? ST_OPEN.delete(n) : ST_OPEN.add(n); stDraw(); $(`[data-stexp="${n}"]`)?.focus(); });
