
/* ── كشف حساب المشترك — Statement.jsx / AccountStatement.jsx / StatementRow.jsx ── */
const ST_LINES = [
  // [#, box, voucher, ref, bank, date, time, desc, amount, side(+ owed / - paid), type, method, user, extra]
  [1, '—', '—', '—', '', '2026-09-04', '09:12', 'رسوم اشتراك', 150, '+', 'رسوم اشتراك', '—', 'أحمد الكحلوت', {}],
  [2, 'C-418', '000412', 'TRX-48213', 'من: بنك فلسطين، إلى: جوال باي', '2026-09-10', '13:40', 'دفعة، تحويل من محمد أبو زايد', 150, '-', 'دفعة', 'تحويل بنكي', 'سماح عودة', { bankArrive: '2026-09-09' }],
  [3, '—', '—', '—', '', '2026-10-17', '08:05', 'قراءة أسبوعية 10/10 ← 16/10، 139 ك.و', 208.5, '+', 'قراءة أسبوعية', '—', 'قارئ: خالد سالم', { fold: 4, disc: 10.43 }],
  [5, 'C-418', '00418', '—', '', '2026-10-20', '11:00', 'مقاصة، صيانة المولد في شهر 10', 20, '-', 'مقاصة', '—', 'سماح عودة', { chain: 1 }],
  [6, 'C-421', '000433', '—', '', '2026-10-24', '10:15', 'دفعة نقدية', 100, '-', 'دفعة', 'نقد', 'رامي خليل', { cancelled: true, chain: 2, note: 'أُلغيت: مبلغ خاطئ، رامي خليل، 24/10' }],
  [7, 'C-421', '—', '—', '', '2026-10-24', '10:22', 'إلغاء الدفعة #6', 100, '+', 'إلغاء', '—', 'رامي خليل', { reversal: true, chain: 2, note: 'يُلغي الحركة #6 ↑' }],
  [8, '—', '—', '—', '', '2026-10-24', '08:00', 'قراءة أسبوعية 17/10 ← 23/10، 151 ك.و', 226.5, '+', 'قراءة أسبوعية', '—', 'قارئ: خالد سالم', {}],
  [9, 'T-112', '000447', 'TRX-50021', 'من: البنك الإسلامي العربي، إلى: بنك فلسطين', '2026-10-30', '12:48', 'دفعة مقسّمة، شركة منصور للتجارة', 320, '-', 'دفعة', 'تحويل بنكي', 'سماح عودة', { split: true, late: '2026-10-26' }],
  [10, '—', '—', '—', '', '2026-11-02', '09:30', 'غرامة مالية، توصيل خط بدون عداد', 100, '+', 'غرامة مالية', '—', 'محمد الأحمد', {}],
  [11, 'C-418', '000461', '—', '', '2026-11-07', '14:05', 'خصم، بموافقة المدير', 25, '-', 'خصم', '—', 'محمد الأحمد', {}],
  [12, '—', '—', '—', '', '2026-11-14', '08:10', 'قراءة أسبوعية 7/11 ← 13/11، 139 ك.و', 208.5, '+', 'قراءة أسبوعية', '—', 'قارئ: خالد سالم', {}],
  [13, '—', '—', '—', '', '2026-11-15', '08:00', 'تحميل الحد الأدنى على المشترك', 30, '+', 'تحميل الحد الأدنى على المشترك', '—', 'النظام', {}],
];
const ST_TYPES = ['الكل', 'كل ما عليه (تحميل)', 'كل ما له (تسديد وخصم)', 'فاتورة', 'قراءة أسبوعية', 'رسوم اشتراك', 'غرامة مالية', 'رسوم قطع الخدمة', 'تحميل الحد الأدنى على المشترك', 'دفعة', 'رصيد دائن', 'خصم', 'خصم القراءة الأسبوعية', 'مقاصة', 'قيد عكسي', 'إلغاء', 'إرجاع', 'حركة تصحيح'];
const ST_SORTS = ['تسلسل كشف الحساب', 'وصول البنك: الأقدم أولًا', 'وصول البنك: الأحدث أولًا', 'تاريخ الحركة: الأقدم أولًا', 'تاريخ الحركة: الأحدث أولًا'];
const CHAIN = ['oklch(0.62 0.15 254)', 'oklch(0.66 0.15 40)', 'oklch(0.6 0.14 300)'];
const ST = { view: 'compact', q: '', type: 'الكل', method: 'الكل', sort: ST_SORTS[0] };
function stLines() {
  let bal = 0; const out = [];
  ST_LINES.forEach((l) => { const [, , , , , , , , amt, side, , , , x] = l; const net = x.disc ? amt - x.disc : amt; bal += side === '+' ? net : -net; out.push({ l, bal: Math.round(bal * 100) / 100, net }); });
  return out;
}
/* Ledger rows: eight calm columns (# · التاريخ · البيان · النوع · عليه · له · الرصيد · ⋯).
   Every other field of the line is one click away in its detail row — nothing is dropped, nothing shouts. */
const AR_MONTH = (iso) => { const [y, m] = iso.split('-').map(Number); return `${MONTHS[m - 1]} ${y}`; };
const ST_OPEN = new Set();
function stRow({ l, bal, net }) {
  const [n, box, vch, ref, bank, d, t, desc, amt, side, type, method, user, x] = l;
  const tone = txTone(type), owe = side === '+', open = ST_OPEN.has(n);
  const dot = x.chain ? `<span class="chain" style="background:${CHAIN[x.chain]}" title="الحركات المرتبطة بنفس اللون"></span>` : '';
  const meta = [vch !== '—' ? `سند ${vch}` : '', method !== '—' ? method : '', x.split ? 'دفعة مقسّمة' : '', x.late ? 'متأخرة' : ''].filter(Boolean).join('، ');
  const amtCell = (on) => on ? `<span class="mv" dir="ltr">${money(net)}</span>${x.disc ? `<small dir="ltr">${money(amt)} − ${money(x.disc)}</small>` : ''}` : '';
  const kv = [['رقم الصندوق', box], ['رقم السند', vch], ['الرقم المرجعي', ref], ['البنك', bank || '—'], ['العملة', 'شيكل'], ['طريقة الدفع', method], ['سعر الصرف', '1'], ['اسم المستخدم', user], ['وقت التسجيل', t], ...(x.bankArrive ? [['وصول البنك', x.bankArrive.split('-').reverse().join('/')]] : []), ...(x.late ? [['الدفع الفعلي', x.late.split('-').reverse().join('/')]] : []), ...(x.note ? [['ملاحظة الحركة', x.note]] : [])];
  return `<tr class="st-r ${x.cancelled ? 'cancelled' : ''} ${x.reversal ? 'rev' : ''} ${open ? 'open' : ''}" data-chain="${x.chain || ''}">
    <td class="st-x"><button type="button" class="exp" data-stexp="${n}" aria-expanded="${open}" aria-label="تفاصيل الحركة #${n}">${ic('chevron-down', 'i i-sm')}</button></td>
    <td class="st-n">${dot}<span>#${n}</span>${x.fold ? `<small>+ #${x.fold}</small>` : ''}</td>
    <td class="st-d">${d.split('-').reverse().join('/')}</td>
    <td class="st-desc">${x.reversal ? '<span class="muted">↲ </span>' : ''}<span class="t">${desc}</span>${meta ? `<small>${meta}</small>` : ''}</td>
    <td class="st-type">${tone ? `<span class="chip2x" data-tone="${tone}">${ic(TX_ICON[tone], 'i')}${type}</span>` : `<span class="chip2x st-default">${type}</span>`}${x.cancelled ? '<span class="chip2x st-default">ملغاة</span>' : ''}</td>
    <td class="c-money st-owe">${amtCell(owe)}</td><td class="c-money st-paid">${amtCell(!owe)}</td>
    <td class="c-money st-bal">${x.cancelled || x.reversal ? '<span class="muted" title="أُلغيت مع قيدها العكسي، فلم تغيّر الرصيد">—</span>' : `<span class="mv" dir="ltr">${money(Math.abs(bal))}</span><small>${bal > 0 ? 'عليه' : bal < 0 ? 'له' : 'مسدّد'}</small>`}</td>
    <td class="c-act"><button type="button" class="row-menu" data-stmenu="${n}" aria-label="إجراءات الحركة #${n}" aria-haspopup="menu" aria-expanded="false">${ic('ellipsis-vertical', 'i i-sm')}</button></td></tr>
    ${open ? `<tr class="st-detail"><td></td><td colspan="8"><dl>${kv.map(([k, v]) => `<div><dt>${k}</dt><dd ${/TRX|^\d|C-|T-/.test(v) ? 'dir="ltr"' : ''}>${esc2(v)}</dd></div>`).join('')}</dl></td></tr>` : ''}`;
}
function stDraw() {
  const all = stLines();
  let rows = all.filter(({ l }) => ST.view === 'all' || !(l[13].cancelled || l[13].reversal));
  if (ST.q) rows = rows.filter(({ l }) => l.join(' ').includes(ST.q));
  if (ST.type !== 'الكل') rows = rows.filter(({ l }) => ST.type.startsWith('كل ما عليه') ? l[9] === '+' : ST.type.startsWith('كل ما له') ? l[9] === '-' : l[10] === ST.type);
  if (ST.method !== 'الكل') rows = rows.filter(({ l }) => l[11] === ST.method);
  if (/الأحدث/.test(ST.sort)) rows = [...rows].reverse();
  const hidden = all.length - all.filter(({ l }) => !(l[13].cancelled || l[13].reversal)).length;
  // Month bands: a quiet header with that month's charges, payments and closing balance.
  let html = '', month = '';
  rows.forEach((r, i) => {
    const m = AR_MONTH(r.l[5]);
    if (m !== month) { month = m; const inM = rows.filter((x) => AR_MONTH(x.l[5]) === m && !x.l[13].cancelled && !x.l[13].reversal); const o = inM.filter((x) => x.l[9] === '+').reduce((t, x) => t + x.net, 0), pd = inM.filter((x) => x.l[9] === '-').reduce((t, x) => t + x.net, 0);
      html += `<tr class="st-month"><td colspan="5"><b>${m}</b><span>${inM.length} حركة</span></td><td class="c-money"><small>عليه</small> ${money(o)}</td><td class="c-money"><small>له</small> ${money(pd)}</td><td colspan="2"></td></tr>`; }
    html += stRow(r);
  });
  $('#stBody').innerHTML = rows.length ? html : `<tr><td colspan="9" style="border:0"><div class="dt2-empty"><div class="ic">${ic('search-x', 'i i-lg')}</div><b>لا توجد حركات تطابق البحث والتصفية.</b><p></p><button type="button" class="btn btn-secondary btn-sm" data-stclear>مسح عوامل التصفية</button></div></td></tr>`;
  const filtered = ST.q || ST.type !== 'الكل' || ST.method !== 'الكل';
  $('#stFoot').innerHTML = `<span>الحركات المعروضة: <b>${rows.length}</b> من <b>${all.length}</b>، الأقدم أولًا، والرصيد بعد كل حركة${ST.view === 'compact' && hidden ? `، أُخفيت ${hidden} حركة ملغاة مع قيودها العكسية (مجموعها صفر)` : ''}</span><span class="grow"></span>${ST.view === 'compact' && hidden ? `<button type="button" class="btn btn-ghost btn-sm" data-stview="all">عرض كل الحركات</button>` : ''}${filtered ? `<button type="button" class="btn btn-ghost btn-sm" data-stclear>مسح عوامل التصفية</button>` : ''}`;
  $('#stViewHint').textContent = ST.view === 'compact' ? 'دون الحركات الملغاة وقيودها العكسية، وخصم القراءة الأسبوعية داخل قراءتها' : 'كل حركة كما سُجّلت، ومنها الملغاة وقيودها العكسية';
  $$('[data-stview]').forEach((b) => b.closest('.seg') && b.setAttribute('aria-pressed', String(b.dataset.stview === ST.view)));
}
document.addEventListener('click', (e) => { const x = e.target.closest('[data-stexp]'); if (!x) return; const n = +x.dataset.stexp; ST_OPEN.has(n) ? ST_OPEN.delete(n) : ST_OPEN.add(n); stDraw(); $(`[data-stexp="${n}"]`)?.focus(); });

VIEWS.statement = (p) => {
  const s = subBy('خالد منصور'), lines = stLines(), bal = lines[lines.length - 1].bal;
  const sum = (f) => lines.filter(({ l }) => f(l) && !l[13].cancelled && !l[13].reversal).reduce((t, { net }) => t + net, 0);
  const owed = sum((l) => l[9] === '+'), paid = sum((l) => l[10] === 'دفعة'), disc = sum((l) => l[10] === 'خصم') + lines.reduce((t, { l }) => t + (l[13].disc || 0), 0), clr = sum((l) => l[10] === 'مقاصة');
  setTimeout(stDraw, 0);
  return `<div class="st-head">
    <a class="back" href="#subscriptions" data-go="subscriptions">${ic('arrow-right', 'i i-sm')}المشتركون</a>
    <div class="st-title"><div><small class="kicker">كشف حساب</small><h1>${s.n} <span class="chip2x st-success" style="vertical-align:middle"><span class="dot"></span>نشط</span></h1><p>حساب ${s.a}، منزلي (عادي)، طبلون 14، ${s.br}</p>
      <div class="standing"><span class="chip2x" data-tone="discount">${ic('repeat', 'i')}خصم القراءات الأسبوعية: 5% من كل قراءة، موظفو أبو زايد</span><button type="button" class="pill-danger" data-confirm-t="إلغاء خصم القراءات الأسبوعية؟">إلغاء الخصم</button></div></div>
      <div class="st-tools"><button type="button" class="btn btn-secondary">${ic('file-spreadsheet', 'i i-sm')}Excel</button><button type="button" class="btn btn-secondary">${ic('printer', 'i i-sm')}طباعة</button></div></div>
    <div class="st-actions" role="group" aria-label="إضافة حركة"><span class="lab">إضافة حركة</span>${toneBtn('تسجيل دفعة', 'pay', { solid: true, attrs: 'data-modal="payment" data-who="خالد منصور"' })}${toneBtn('دفعة مقسّمة', 'split', { attrs: 'data-modal="split"' })}${toneBtn('تحميل حركة', 'charge', { attrs: 'data-modal="charge" data-who="خالد منصور"' })}${toneBtn('خصم', 'discount', { attrs: 'data-modal="discount" data-who="خالد منصور"' })}${toneBtn('مقاصة', 'clearing', { attrs: 'data-form="clearing"' })}</div></div>
  <div class="kpis st-kpis">
    <section class="card surf kpi bal ${bal > 0 ? 'owe' : bal < 0 ? 'credit' : ''}"><small>الرصيد الحالي</small><b class="n">₪ ${money(Math.abs(bal))}</b><span>${bal > 0 ? 'عليه' : bal < 0 ? 'له' : 'مسدّد'}</span></section>
    <section class="card surf kpi"><small>مجموع ما عليه (تحميل)</small><b class="n">₪ ${money(owed)}</b><span>القراءات المعتمدة والرسوم والغرامات</span></section>
    <section class="card surf kpi"><small>مجموع ما دفعه (تسديد)</small><b class="n">₪ ${money(paid)}</b><span>عدد الدفعات: ${lines.filter(({ l }) => l[10] === 'دفعة' && !l[13].cancelled).length}</span></section>
    <section class="card surf kpi"><small>مجموع الخصومات</small><b class="n">₪ ${money(disc)}</b><span>عدد الخصومات: 2</span></section>
    <section class="card surf kpi"><small>مجموع المقاصات</small><b class="n">₪ ${money(clr)}</b><span>عدد المقاصات: 1</span></section></div>
  <section class="card surf st-subs"><div class="card-h"><div><h3>اشتراكات المشترك <span class="chip2x st-default">2 اشتراكات</span></h3><p class="muted" style="margin:2px 0 0;font-size:13px">اضغط على بطاقة الاشتراك لعرض كشفه.</p></div><div class="end"><small class="muted">الرصيد الإجمالي للاشتراكات</small><b class="n" style="font-size:18px">₪ ${money(Math.abs(bal) + 120)}</b></div></div>
    <div class="sub-cards">${[[s.a, 'منزلي (عادي)', 'الطبلون 14', 'حي الزيتون', bal, true], ['202600231', 'تجاري', 'الطبلون 9', 'السوق', 120, false]].map(([a, c, bx, ar2, v, cur]) => `<button type="button" class="sub-card ${cur ? 'cur' : ''}" ${cur ? 'aria-current="true"' : ''}><span class="l1"><b class="n">${a}</b>${cur ? `<span class="chip2x st-default" style="height:22px">${ic('check', 'i')}المعروض الآن</span>` : ''}<span class="bal n">₪ ${money(Math.abs(v))}</span></span><span class="l2">${c}، ${bx}، ${ar2}${cur ? '' : `<span class="go">عرض كشفه ${ic('arrow-left', 'i i-sm')}</span>`}</span></button>`).join('')}</div></section>
  <section class="card surf dt2 st-ledger">
    <div class="dt2-bar"><div style="margin-inline-end:auto"><h3 style="margin:0;font-size:18px">الحركات</h3><p class="muted" id="stViewHint" style="margin:2px 0 0;font-size:13px"></p></div>
      <div class="seg" role="tablist" aria-label="طريقة العرض"><button type="button" data-stview="compact" aria-pressed="true">عرض مختصر</button><button type="button" data-stview="all" aria-pressed="false">كل الحركات</button></div></div>
    <div class="dt2-bar" style="padding-top:0"><label class="dt2-search">${ic('search', 'i i-sm')}<input id="stQ" placeholder="البيان، رقم السند، المبلغ أو البنك" aria-label="بحث"></label>
      ${pickBtn('stType', '', ST_TYPES, { cls: 'select', icon: 'list-filter', ph: 'نوع الحركة' })}${pickBtn('stMethod', '', ['الكل', 'نقد', 'تحويل بنكي'], { cls: 'select', icon: 'wallet', ph: 'طريقة الدفع' })}
      <span class="st-dates">${dateBtn('stFrom', '')}${dateBtn('stTo', '')}</span>${pickBtn('stSort', ST.sort, ST_SORTS, { cls: 'select', icon: 'arrow-down-up' })}</div>
    <div class="dt2-scroll"><table class="st-table"><thead><tr><th class="st-x"><span class="sr-only">تفاصيل</span></th>${['#', 'التاريخ', 'البيان', 'النوع', 'عليه (تحميل)', 'له (تسديد)', 'الرصيد'].map((h, i) => `<th class="${i >= 4 ? 'c-money' : ''}">${h}</th>`).join('')}<th class="c-act"><span class="sr-only">إجراءات</span></th></tr></thead><tbody id="stBody"></tbody></table></div>
    <div class="dt2-foot" id="stFoot"></div></section>`;
};
/* Line actions, in the order the server sends them; each item says what it does. */
const ST_ACTS = (l) => {
  const pay = l[10] === 'دفعة', noun = pay ? 'الدفعة' : l[10];
  const items = [{ head: `${l[10]}، ${l[5].split('-').reverse().join('/')}` }, { label: 'تعديل المبلغ', desc: 'تعديل مبلغ آخر حركة مؤهلة وإعادة احتساب رصيدها', icon: 'pencil', form: 'editAmount' }];
  if (pay) items.push({ label: l[13].split ? 'تعديل الحوالة المقسّمة' : 'تعديل بيانات الدفعة', desc: l[13].split ? 'بيانات الحوالة لجميع المشتركين، المبلغ والحصص ثابتة' : 'البنك والمرجع والمرسل والملاحظات، الرصيد لا يتغيّر', icon: 'file-pen', form: 'amend' });
  items.push('sep', { label: pay ? 'إرجاع الدفعة' : `إلغاء ${noun}`, desc: pay ? 'إرجاع كامل الدفعة بحركة مرتبطة، ثم تسجيل الدفعة الصحيحة إن شئت' : `إضافة حركة إلغاء مرتبطة بـ${noun} في نهاية السجل`, icon: 'undo-2', form: 'deleteTx' });
  if (/قراءة/.test(l[10])) items.push({ label: 'تصحيح القراءة', desc: 'القراءة الأسبوعية', icon: 'gauge', form: 'lastReadingEdit' });
  if (pay) items.push({ label: 'طباعة سند القبض', icon: 'printer' });
  items.push('sep', { label: pay ? 'حذف الدفعة والإرجاع معًا' : `حذف ${noun} والإلغاء معًا`, desc: 'حذف الحركة الأصلية وكل الحركات المرتبطة بها وإعادة موازنة السجل', icon: 'trash-2', danger: true, form: 'forceDeleteTx' });
  return items;
};
document.addEventListener('input', (e) => { if (e.target.id === 'stQ') { ST.q = e.target.value.trim(); stDraw(); } });
document.addEventListener('pick', (e) => { const k = e.detail.key; if (k === 'stType') ST.type = e.detail.value; else if (k === 'stMethod') ST.method = e.detail.value; else if (k === 'stSort') ST.sort = e.detail.value; else return; stDraw(); });
document.addEventListener('click', (e) => {
  const v = e.target.closest('[data-stview]'); if (v) { ST.view = v.dataset.stview; return stDraw(); }
  if (e.target.closest('[data-stclear]')) { Object.assign(ST, { q: '', type: 'الكل', method: 'الكل' }); const q = $('#stQ'); if (q) q.value = ''; return PC.go('statement'); }
  const c = e.target.closest('[data-confirm-t]'); if (c) { e.stopPropagation(); return openConfirm(SP.confirms.find((x) => x.title === c.dataset.confirmT) || { title: c.dataset.confirmT, tone: 'warning' }); }
  const m = e.target.closest('[data-stmenu]'); if (m) {
    e.stopPropagation(); if (POP?.btn === m) return closePop();
    const l = ST_LINES.find((x) => String(x[0]) === m.dataset.stmenu);
    return openMenu(m, ST_ACTS(l), (it) => it.form ? openForm(it.form) : toast(it.label, it.icon));
  }
}, true);
document.addEventListener('mouseover', (e) => { const r = e.target.closest('.st-table tr[data-chain]'); $$('.st-table tr.hl').forEach((x) => x.classList.remove('hl')); if (r?.dataset.chain) $$(`.st-table tr[data-chain="${r.dataset.chain}"]`).forEach((x) => x.classList.add('hl')); });
